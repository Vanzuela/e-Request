// ==========================================
// PART 1: CALENDAR & BOOKING LOGIC
// ==========================================
(function () {
    function pad(n) { return n < 10 ? '0' + n : '' + n; }
    function formatISO(y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); }
    function isPastDate(dateObj) {
        const t = new Date(); t.setHours(0, 0, 0, 0);
        const c = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());
        return c < t;
    }

    function waitForInit() {
        // Only initialize if the calendar element exists on this page
        if (!document.getElementById('calendar')) return;
        
        if (typeof window.bookedDates === 'undefined') {
            return setTimeout(waitForInit, 120);
        }
        initCalendar();
    }

    function initCalendar() {
        const calendar = document.getElementById('calendar');
        const monthYearEl = document.getElementById('monthYear');
        const prevBtn = document.getElementById('prevMonth');
        const nextBtn = document.getElementById('nextMonth');
        const modal = document.getElementById('modal');
        const cancelBtn = document.getElementById('cancelBtn');
        const modalMessage = document.getElementById('modalMessage');
        const selectedDateInput = document.getElementById('selectedDate');
        const selectedTimeSlotInput = document.getElementById('selectedTimeSlot');
        const timeSlotSelect = document.getElementById('timeSlotSelect');

        const bookingCounts = window.bookedDates || {};
        const MAX = window.maxPerSlot || 25;

        let today = new Date(); today.setHours(0, 0, 0, 0);
        let currentMonth = today.getMonth();
        let currentYear = today.getFullYear();

        function buildGrid(month, year) {
            calendar.innerHTML = '';
            const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            dayLabels.forEach(lbl => {
                const div = document.createElement('div');
                div.className = 'day-label';
                div.textContent = lbl;
                calendar.appendChild(div);
            });

            const firstDayIndex = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();

            for (let i = 0; i < firstDayIndex; i++) {
                const blank = document.createElement('div');
                blank.style.visibility = 'hidden';
                calendar.appendChild(blank);
            }

            for (let d = 1; d <= daysInMonth; d++) {
                const dateObj = new Date(year, month, d);
                const iso = formatISO(year, month, d);
                const cell = document.createElement('div');
                cell.className = 'calendar-day';
                const amCount = bookingCounts[iso] && bookingCounts[iso].AM ? bookingCounts[iso].AM : 0;
                const pmCount = bookingCounts[iso] && bookingCounts[iso].PM ? bookingCounts[iso].PM : 0;

                cell.innerHTML = '<div class="day-number">' + d + '</div>' +
                    '<div class="slot-info">AM: ' + amCount + '/' + MAX + '<br>PM: ' + pmCount + '/' + MAX + '</div>';

                const weekday = dateObj.getDay();
                if (weekday === 0 || weekday === 6 || isPastDate(dateObj)) {
                    cell.classList.add('disabled');
                    calendar.appendChild(cell);
                    continue;
                }

                const bothFull = (amCount >= MAX && pmCount >= MAX);
                if (bothFull) {
                    cell.classList.add('booked');
                    calendar.appendChild(cell);
                    continue;
                }

                cell.addEventListener('click', function () {
                    const amAvailable = amCount < MAX;
                    const pmAvailable = pmCount < MAX;
                    selectedDateInput.value = iso;

                    if (amAvailable && pmAvailable) {
                        timeSlotSelect.disabled = false;
                        timeSlotSelect.value = 'AM';
                        selectedTimeSlotInput.value = 'AM';
                    } else if (amAvailable) {
                        timeSlotSelect.disabled = true;
                        timeSlotSelect.value = 'AM';
                        selectedTimeSlotInput.value = 'AM';
                    } else {
                        timeSlotSelect.disabled = true;
                        timeSlotSelect.value = 'PM';
                        selectedTimeSlotInput.value = 'PM';
                    }

                    timeSlotSelect.onchange = function () {
                        selectedTimeSlotInput.value = timeSlotSelect.value;
                    };

                    modalMessage && (modalMessage.textContent = "Confirm booking for " + iso + ".");
                    modal.classList.add('show');
                    modal.setAttribute('aria-hidden', 'false');
                });
                calendar.appendChild(cell);
            }
            monthYearEl.textContent = new Date(year, month).toLocaleString('default', { month: 'long', year: 'numeric' });
        }

        prevBtn && prevBtn.addEventListener('click', () => { currentMonth--; if (currentMonth < 0) { currentMonth = 11; currentYear--; } buildGrid(currentMonth, currentYear); });
        nextBtn && nextBtn.addEventListener('click', () => { currentMonth++; if (currentMonth > 11) { currentMonth = 0; currentYear++; } buildGrid(currentMonth, currentYear); });
        cancelBtn && cancelBtn.addEventListener('click', () => { modal.classList.remove('show'); modal.setAttribute('aria-hidden', 'true'); });
        
        buildGrid(currentMonth, currentYear);
    }
    waitForInit();
})();

// ==========================================
// PART 2: DASHBOARD MODALS & LOG HISTORY
// ==========================================

function openRequestModal(studentNo) {
    const modalBody = document.getElementById("modalTableBody");
    if (!modalBody) return;
    modalBody.innerHTML = "<tr><td colspan='6'>Loading...</td></tr>";

    fetch("getStudentRequests.php?studentNo=" + encodeURIComponent(studentNo))
        .then(res => res.json())
        .then(data => {
            if (!data || data.length === 0) {
                modalBody.innerHTML = "<tr><td colspan='6'>No pending requests.</td></tr>";
            } else {
                modalBody.innerHTML = data.map(req => `
                    <tr>
                        <td>${req.requestID}</td>
                        <td>${escapeHtml(req.studentName)}</td>
                        <td>${escapeHtml(req.studentNo)}</td>
                        <td>${escapeHtml(req.requestDocument)}</td>
                        <td>${req.requestStatus}</td>
                        <td>
                            <form method="POST" action="admindashboard.php">
                                <input type="hidden" name="requestID" value="${req.requestID}">
                                ${req.requestStatus === "Pending" 
                                    ? `<button type="submit" name="markProcessing" class="ready-btn">Mark as Processing</button>` 
                                    : req.requestStatus === "Processing" 
                                        ? `<button type="submit" name="markReady" class="ready-btn">Mark as Ready</button>` 
                                        : ""}
                            </form>
                        </td>
                    </tr>`).join("");
            }
            document.getElementById("requestModal").style.display = "block";
        })
        .catch(err => {
            console.error(err);
            modalBody.innerHTML = "<tr><td colspan='6'>Error loading data.</td></tr>";
        });
}

function openBookingModal(bookingID) {
    const modalBody = document.getElementById("bookingModalBody");
    if (!modalBody) return;
    modalBody.innerHTML = "<tr><td colspan='6'>Loading...</td></tr>";
    document.getElementById("bookingModal").style.display = "block";

    fetch("getBookingDetails.php?bookingID=" + bookingID)
        .then(res => res.json())
        .then(data => {
            if (!data) {
                modalBody.innerHTML = "<tr><td colspan='6'>No booking details found.</td></tr>";
                return;
            }
            modalBody.innerHTML = data.documents.map(doc => `
                <tr>
                    <td>${doc.requestID}</td>
                    <td>${escapeHtml(data.studentName)}</td>
                    <td>${escapeHtml(data.studentNo)}</td>
                    <td>${escapeHtml(doc.requestDocument)}</td>
                    <td>${doc.requestDate}</td>
                    <td>
                        <form method="POST" action="admindashboard.php">
                            <input type="hidden" name="requestID" value="${doc.requestID}">
                            <button type="submit" name="markDone" class="done-btn">Mark as Done</button>
                        </form>
                    </td>
                </tr>`).join("");
        })
        .catch(() => {
            modalBody.innerHTML = "<tr><td colspan='6'>Error loading booking.</td></tr>";
        });
}

function closeModal() {
    const rModal = document.getElementById("requestModal");
    const bModal = document.getElementById("bookingModal");
    if (rModal) rModal.style.display = "none";
    if (bModal) bModal.style.display = "none";
}

window.addEventListener("click", function (e) {
    if (e.target.classList.contains("modal")) closeModal();
});

function escapeHtml(str) {
    if (!str && str !== 0) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

// ==========================================
// PART 3: TRANSACTION HISTORY (AJAX)
// ==========================================

function loadLogs(page = 1) {
    const tbody = document.getElementById("logTableBody");
    if (!tbody) return; // Exit if the table isn't on this page

    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">Loading...</td></tr>`;

    const search = encodeURIComponent(document.getElementById("logSearch")?.value || "");
    const doc    = encodeURIComponent(document.getElementById("logDocument")?.value || "");
    const admin  = encodeURIComponent(document.getElementById("logAdmin")?.value || "");
    const from   = encodeURIComponent(document.getElementById("logFrom")?.value || "");
    const to     = encodeURIComponent(document.getElementById("logTo")?.value || "");

    fetch(`getLogs.php?page=${page}&search=${search}&document=${doc}&admin=${admin}&from=${from}&to=${to}`)
        .then(r => r.json())
        .then(data => {
            if (!data.logs || data.logs.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">No logs found</td></tr>`;
            } else {
                tbody.innerHTML = data.logs.map(log => {
                    const ts = log.readyTime ? new Date(log.readyTime) : null;
                    let formattedDate = "-";
                    if (ts && !isNaN(ts.getTime())) {
                        formattedDate = ts.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) +
                                       " • " + ts.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
                    }
                    return `
                        <tr>
                            <td>${escapeHtml(log.requestID)}</td>
                            <td>${escapeHtml(log.requestDocument)}</td>
                            <td>${escapeHtml(log.studentName)}</td>
                            <td>${escapeHtml(log.approvedBy)}</td>
                            <td>${escapeHtml(formattedDate)}</td>
                        </tr>`;
                }).join("");
            }

            const pag = document.getElementById("logPagination");
            if (pag) {
                const total = Number(data.totalPages) || 1;
                pag.innerHTML = `
                    <button onclick="loadLogs(${page - 1})" ${page <= 1 ? "disabled" : ""} style="padding:6px 16px; margin:4px; border:none; border-radius:20px; font-weight:600; background:${page <= 1 ? '#e5e7eb' : 'linear-gradient(0deg, rgb(1,116,34), rgb(32,186,45))'}; color:${page <= 1 ? '#999' : '#fff'}; cursor:${page <= 1 ? 'not-allowed' : 'pointer'};">◀ Previous</button>
                    <span style="margin:0 12px;font-weight:700;">Page ${page} of ${total}</span>
                    <button onclick="loadLogs(${page + 1})" ${page >= total ? "disabled" : ""} style="padding:6px 16px; margin:4px; border:none; border-radius:20px; font-weight:600; background:${page >= total ? '#e5e7eb' : 'linear-gradient(0deg, rgb(1,116,34), rgb(32,186,45))'}; color:${page >= total ? '#999' : '#fff'}; cursor:${page >= total ? 'not-allowed' : 'pointer'};">Next ▶</button>`;
            }
        })
        .catch(err => {
            console.error("Log loading error:", err);
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">Error loading logs</td></tr>`;
        });
}

// ==========================================
// PART 4: TRANSACTION DETAILS 
// ==========================================

// ==========================================
// SAFE HTML ESCAPE
// ==========================================
function escapeHtml(text) {
    if (text === null || text === undefined) return "";
    return text.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// ==========================================
// TRANSACTION HISTORY (LOGS)
// ==========================================
function loadLogs(page = 1) {
    const tbody = document.getElementById("logTableBody");
    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">Loading...</td></tr>`;

    const search = encodeURIComponent(document.getElementById("logSearch")?.value || "");
    const doc    = encodeURIComponent(document.getElementById("logDocument")?.value || "");
    const admin  = encodeURIComponent(document.getElementById("logAdmin")?.value || "");
    const from   = encodeURIComponent(document.getElementById("logFrom")?.value || "");
    const to     = encodeURIComponent(document.getElementById("logTo")?.value || "");

    fetch(`getLogs.php?page=${page}&search=${search}&document=${doc}&admin=${admin}&from=${from}&to=${to}`)
        .then(r => r.json())
        .then(data => {
            if (!data.logs || data.logs.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">No logs found</td></tr>`;
            } else {
                tbody.innerHTML = data.logs.map(log => {
                    const ts = log.readyTime ? new Date(log.readyTime) : null;
                    let formattedDate = "-";
                    if (ts && !isNaN(ts.getTime())) {
                        formattedDate = ts.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) +
                                        " • " + ts.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
                    }
                    return `
                        <tr>
                            <td>${escapeHtml(log.requestID)}</td>
                            <td>${escapeHtml(log.requestDocument)}</td>
                            <td>${escapeHtml(log.studentName)}</td>
                            <td>${escapeHtml(log.approvedBy)}</td>
                            <td>${escapeHtml(formattedDate)}</td>
                        </tr>`;
                }).join("");
            }

            const pag = document.getElementById("logPagination");
            if (pag) {
                const total = Number(data.totalPages) || 1;
                pag.innerHTML = `
                    <button onclick="loadLogs(${page - 1})" ${page <= 1 ? "disabled" : ""}>◀ Previous</button>
                    <span style="margin:0 12px;">Page ${page} of ${total}</span>
                    <button onclick="loadLogs(${page + 1})" ${page >= total ? "disabled" : ""}>Next ▶</button>`;
            }
        })
        .catch(err => {
            console.error("Log loading error:", err);
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">Error loading logs</td></tr>`;
        });
}

function openRequestModal(studentNo) {
    fetch(`fetch_request_items.php?studentNo=${studentNo}`)
    .then(res => res.json())
    .then(data => {
        let html = '';
        data.forEach(item => {
            html += `
            <tr>
                <td>${item.requestID}</td>
                <td>${item.documentName}</td>
                <td>${item.requestStatus}</td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="requestID" value="${item.requestID}">
                        <button name="markProcessing" class="ready-btn">Mark Processing</button>
                    </form>
                </td>
            </tr>`;
        });
        document.getElementById('modalTableBody').innerHTML = html;
        document.getElementById('requestModal').style.display = 'block';
    });
}


// ==========================================
// TRANSACTION DETAILS (SALES)
// ==========================================
function loadSales(page = 1) {
    const tbody = document.getElementById("salesTableBody");
    const pag   = document.getElementById("salesPagination");
    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;">Loading...</td></tr>`;
    if(pag) pag.innerHTML = "";

    const search = encodeURIComponent(document.getElementById("searchSales")?.value || "");
    const from   = encodeURIComponent(document.getElementById("dateFrom")?.value || "");
    const to     = encodeURIComponent(document.getElementById("dateTo")?.value || "");

    fetch(`getSales.php?page=${page}&search=${search}&from=${from}&to=${to}`)
        .then(res => res.json())
        .then(data => {
            if (!data.sales || data.sales.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;">No sales found</td></tr>`;
                if(pag) pag.innerHTML = "";
                return;
            }

            // Populate sales table
            tbody.innerHTML = data.sales.map(sale => {
                const ts = sale.saleDate ? new Date(sale.saleDate) : null;
                const formattedDate = ts ? ts.toLocaleDateString() + " " + ts.toLocaleTimeString() : "-";
                return `
                    <tr>
                        <td>${escapeHtml(sale.requestID)}</td>
                        <td>${escapeHtml(sale.requestDocument)}</td>
                        <td>${escapeHtml(sale.studentName)}</td>
                        <td>${sale.quantity || "-"}</td>
                        <td>₱${sale.totalPrice || 0}</td>
                        <td>${formattedDate}</td>
                    </tr>`;
            }).join("");

            // Pagination
            if (pag) {
                const total = data.totalPages || 1;
                pag.innerHTML = `
                    <button onclick="loadSales(${page - 1})" ${page <= 1 ? "disabled" : ""}>◀ Previous</button>
                    <span style="margin:0 12px;">Page ${page} of ${total}</span>
                    <button onclick="loadSales(${page + 1})" ${page >= total ? "disabled" : ""}>Next ▶</button>`;
            }

            // Update summary if provided
            if (data.summary) {
                document.getElementById('todaySales').textContent = `₱${data.summary.today || 0}`;
                document.getElementById('weekSales').textContent = `₱${data.summary.week || 0}`;
                document.getElementById('monthSales').textContent = `₱${data.summary.month || 0}`;
                document.getElementById('totalSales').textContent = `₱${data.summary.total || 0}`;
            }
        })
        .catch(err => {
            console.error(err);
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;">Error loading sales</td></tr>`;
            if(pag) pag.innerHTML = "";
        });
}

// ==========================================
// MODAL HANDLERS
// ==========================================
function openRequestModal(studentNo) {
    const modalBody = document.getElementById("modalTableBody");
    if (!modalBody) return;
    modalBody.innerHTML = "<tr><td colspan='6'>Loading...</td></tr>";

    fetch("getStudentRequests.php?studentNo=" + encodeURIComponent(studentNo))
        .then(res => res.json())
        .then(data => {
            if (!data || data.length === 0) {
                modalBody.innerHTML = "<tr><td colspan='6'>No pending requests.</td></tr>";
            } else {
                modalBody.innerHTML = data.map(req => `
                    <tr>
                        <td>${req.requestID}</td>
                        <td>${escapeHtml(req.studentName)}</td>
                        <td>${escapeHtml(req.studentNo)}</td>
                        <td>${escapeHtml(req.requestDocument)}</td>
                        <td>${req.requestStatus}</td>
                        <td>
                            <form method="POST" action="admindashboard.php">
                                <input type="hidden" name="requestID" value="${req.requestID}">
                                ${req.requestStatus === "Pending" 
                                    ? `<button type="submit" name="markProcessing" class="ready-btn">Mark as Processing</button>` 
                                    : req.requestStatus === "Processing" 
                                        ? `<button type="submit" name="markReady" class="ready-btn">Mark as Ready</button>` 
                                        : ""}
                            </form>
                        </td>
                    </tr>`).join("");
            }
            document.getElementById("requestModal").style.display = "block";
        })
        .catch(() => {
            modalBody.innerHTML = "<tr><td colspan='6'>Error loading data.</td></tr>";
        });
}

function closeModal() {
    const rModal = document.getElementById("requestModal");
    const bModal = document.getElementById("bookingModal");
    if (rModal) rModal.style.display = "none";
    if (bModal) bModal.style.display = "none";
}

window.addEventListener("click", function(e) {
    if(e.target.classList.contains("modal")) closeModal();
});

// ==========================================
// AUTO LOAD ON PAGE
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
    if(document.getElementById("logTableBody")) loadLogs(1);
    if(document.getElementById("salesTableBody")) loadSales(1);

    const filterBtn = document.getElementById("filterBtn");
    if(filterBtn) filterBtn.addEventListener("click", () => loadSales(1));
});


function filterLogs() {
    const searchInput = document.getElementById('logSearch').value.toLowerCase();
    const docSelect = document.getElementById('logDocument').value.toLowerCase();
    const fromInput = document.getElementById('logFrom').value; // YYYY-MM-DDTHH:MM
    const toInput = document.getElementById('logTo').value;

    const rows = document.querySelectorAll('#logTableBody tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length < 5) return;

        const requestID = cells[0].textContent.toLowerCase();
        const docName   = cells[1].textContent.toLowerCase();
        const student   = cells[2].textContent.toLowerCase();
        const rowDateTime = cells[4].dataset.datetime; // full timestamp

        // Compare date + time
        let matchDate = true;
        if (fromInput && rowDateTime < fromInput) matchDate = false;
        if (toInput && rowDateTime > toInput) matchDate = false;

        // Search + Document match
        const matchSearch = requestID.includes(searchInput) || student.includes(searchInput);
        const matchDoc = docSelect === "" || docName.includes(docSelect);

        // Show/hide row
        row.style.display = (matchSearch && matchDoc && matchDate) ? "" : "none";
    });
}

// Live search
document.getElementById('logSearch').addEventListener('keyup', filterLogs);

// Filter button
document.querySelector('.apply-btn').addEventListener('click', filterLogs);

// Page load
window.onload = () => filterLogs();









/* =========================
   SAFE HTML ESCAPE
   ========================= */
function escapeHtml(text) {
    if (text === null || text === undefined) return "";
    return text.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/* =========================
   AUTO LOAD
   ========================= */
document.addEventListener("DOMContentLoaded", () => {
    loadSales(1);
});
</script>


// Auto-run loadLogs if we are on the history page
document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("logTableBody")) {
        loadLogs();
    }
});