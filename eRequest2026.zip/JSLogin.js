const container = document.querySelector('.container');
const registerBtn = document.querySelector('.register-btn');
const loginBtn = document.querySelector('.login-btn');

registerBtn.addEventListener('click', () => {
    container.classList.add('active');
});

loginBtn.addEventListener('click', () => {
    container.classList.remove('active');
});


document.getElementById('studentCourse').addEventListener('change', function() {
    const course = this.value;
    const yearSelect = document.getElementById('studentYear');
    
  
    const associateCourses = [
        'Associate in Business Administration',
        'Associate in Accounting Information System',
        'Associate in Human Resource Development',
        'Associate in Hotel and Restaurant Technology'
    ];

   
    yearSelect.innerHTML = '<option value="" disabled selected>Select Year Level</option>';

    if (associateCourses.includes(course)) {
     
        yearSelect.innerHTML += `
            <option value="1st Year">1st Year</option>
            <option value="2nd Year">2nd Year</option>
        `;
    } else {
      
        yearSelect.innerHTML += `
            <option value="1st Year">1st Year</option>
            <option value="2nd Year">2nd Year</option>
            <option value="3rd Year">3rd Year</option>
            <option value="4th Year">4th Year</option>
        `;
    }
});