<?php
include("php/config.php");

// Ensure user is logged in
if (!isset($_SESSION['studentNo'])) {
    header("Location: login.php");
    exit;
}

$studentID = $_SESSION['studentNo'];

/* ------------------------------------------
   1. GET LATEST REQUEST BATCH
------------------------------------------- */
$latestQuery = "
    SELECT MAX(requestDate) AS latestDate 
    FROM request 
    WHERE studentNo = '$studentID'
";
$latestResult = mysqli_query($con, $latestQuery);
$latestRow = mysqli_fetch_assoc($latestResult);
$latestDate = $latestRow['latestDate'];

if (!$latestDate) {
    echo "<div class='step-content' style='text-align:center; padding: 50px;'><p>No request found.</p></div>";
    return;
}

/* ------------------------------------------
   2. FETCH ALL DOCUMENTS
------------------------------------------- */
$query = "
    SELECT requestDocument AS document_name, requestStatus AS status 
    FROM request 
    WHERE studentNo = '$studentID' 
      AND requestDate = '$latestDate'
";
$result = mysqli_query($con, $query);
?>

<style>
    .status-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        padding: 25px;
        margin-top: 20px;
    }
    .success-banner {
        background: #e8f5e9;
        color: #2e7d32;
        padding: 15px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 25px;
        font-weight: 500;
    }
    .styled-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 0.95rem;
    }
    .styled-table thead tr {
        background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
        color: #ffffff;
        text-align: left;
    }
    .styled-table th, .styled-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #eee;
    }
    .status-badge {
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        display: inline-block;
    }
    /* SYNCED COLORS WITH HISTORY.PHP */
    .status-pending { background: #fff3e0; color: #ef6c00; }
    .status-processing { background: #e3f2fd; color: #1565c0; }
    .status-readytopickup { background: #e8f5e9; color: #2e7d32; }
    .status-ready { background: #e8f5e9; color: #2e7d32; }
    .status-booked { background: #f3e5f5; color: #7b1fa2; }
    .status-done { background: #eeeeee; color: #616161; }
    .status-cancelled { background: #ffebee; color: #d32f2f; }

    .cancel-btn {
        padding: 6px 18px;
        border-radius: 6px;
        font-size: 12px;
        cursor: pointer;
        background: white; 
        color: #d32f2f; 
        border: 1px solid #d32f2f;
        transition: 0.2s;
        font-weight: 600;
    }
    .cancel-btn:hover { background: #d32f2f; color: white; }

    .request-meta {
        font-size: 13px;
        color: #666;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
</style>

<div class="step-content">
    <div class="status-card">
        <div class="success-banner">
            <i class='bx bxs-check-circle' style="font-size: 24px;"></i>
            <span>Request Submitted Successfully! Your documents are now in queue.</span>
        </div>

        <div class="request-meta">
            <div><strong>Request Date:</strong> <?= date("F j, Y, g:i a", strtotime($latestDate)) ?></div>
        </div>

        <table class="styled-table">
            <thead>
                <tr>
                    <th>Document Name</th>
                    <th style="text-align: center;">Status</th>
                    <th style="text-align: center;">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $doc = htmlspecialchars($row['document_name']);
                    $status = $row['status'];

                    // Logic to handle spaces in status names like "Ready to Pickup"
                    $colorClass = "status-" . strtolower(str_replace(' ', '', $status));

                    echo "<tr>";
                    echo "<td>
                            <div style='font-weight: 600; color: #333;'>$doc</div>
                            <div style='font-size: 11px; color: #999;'>Reference Batch: ".date("Y-m-d", strtotime($latestDate))."</div>
                          </td>";
                    echo "<td style='text-align: center;'><span class='status-badge $colorClass'>$status</span></td>";

                    echo "<td style='text-align: center;'>";
                    if ($status === 'Pending') {
                        echo "
                            <form method='POST' action='cancel_single.php' style='display:inline-block;' onsubmit='return confirm(\"Are you sure you want to cancel this document request?\")'>
                                <input type='hidden' name='docName' value='". htmlspecialchars($row['document_name'], ENT_QUOTES) ."'>
                                <button type='submit' class='cancel-btn'>Cancel</button>
                            </form>
                        ";
                    } else {
                        echo "<span style='color: #bbb; font-size: 12px;'>Locked</span>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3' style='text-align:center; padding: 30px; color: #999;'>No active requests found.</td></tr>";
            }
            ?>
            </tbody>
        </table>

        <div style="margin-top: 25px; border-top: 1px dashed #ddd; padding-top: 15px; font-size: 12px; color: #777; line-height: 1.5;">
            <p><i class='bx bx-info-circle'></i> <strong>Policy:</strong> You may only cancel a request while the status is <b>Pending</b>. Once the status changes to <b>Processing</b>, the document is already being prepared by the Registrar and cannot be canceled online.</p>
        </div>
    </div>
</div>