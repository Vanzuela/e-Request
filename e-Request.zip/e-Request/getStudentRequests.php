<?php
include("php/config.php");

header('Content-Type: application/json');

if (isset($_GET['studentNo'])) {
    $studentNo = mysqli_real_escape_string($con, $_GET['studentNo']);
    
    // Updated WHERE clause to include 'Ready to Pickup'
    $query = "
        SELECT 
            request.requestID, 
            request.requestDocument,
            request.requestStatus,
            login.studentName,
            login.studentNo
        FROM request 
        INNER JOIN login ON request.studentNo = login.studentNo 
        WHERE request.studentNo = '$studentNo' 
          AND request.requestStatus IN ('Pending', 'Processing', 'Ready to Pickup')
        ORDER BY request.requestDate DESC";
    
    $result = mysqli_query($con, $query);
    
    $requests = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row;
    }
    
    echo json_encode($requests);
} else {
    echo json_encode([]);
}
?>