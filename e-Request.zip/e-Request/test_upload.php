<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>PHP Environment Check:</h3>";

// 1. Check if files exist
$files = [
    'php/config.php',
    'PHPMailer/src/Exception.php',
    'PHPMailer/src/PHPMailer.php',
    'PHPMailer/src/SMTP.php'
];

foreach ($files as $file) {
    if (file_exists($file)) {
        echo "✅ FOUND: $file <br>";
    } else {
        echo "❌ MISSING: $file <br>";
    }
}

// 2. Check Database Connection
include("php/config.php");
if ($con) {
    echo "✅ Database Connected.<br>";
} else {
    echo "❌ Database Connection Failed: " . mysqli_connect_error() . "<br>";
}

// 3. Check PHPMailer Class
try {
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    echo "✅ PHPMailer Classes Loaded Successfully.<br>";
} catch (Exception $e) {
    echo "❌ PHPMailer Error: " . $e->getMessage() . "<br>";
}
?>