<?php
include("php/config.php");
session_start();

if (!isset($_SESSION['adminID'])) {
    header("Location: adminLogin.php");
    exit();
}

// Only SuperAdmin can access
$sessionRole = str_replace(' ', '', $_SESSION['adminRole']);
if ($sessionRole !== 'SuperAdmin') {
    echo "<script>alert('Access denied. Super Admin only.'); window.location='admindashboard.php';</script>";
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);

// ADD OR EDIT PROCESS
if (isset($_POST['saveAdmin'])) {
    $action = $_POST['action'];
    $full = mysqli_real_escape_string($con, $_POST['adminFullname']);
    $user = mysqli_real_escape_string($con, $_POST['adminUsername']);
    $role = mysqli_real_escape_string($con, $_POST['adminRole']);
    
    if ($action === "add") {
        $pass_plain = $_POST['adminPassword'] ?? '';
        $pass = password_hash($pass_plain, PASSWORD_DEFAULT);
        
        $check = mysqli_query($con, "SELECT adminID FROM admin WHERE adminUsername='$user'");
        if (mysqli_num_rows($check) > 0) {
            echo "<script>alert('Username already exists.');</script>";
        } else {
            // No ID mentioned here; Database handles it via AUTO_INCREMENT
            mysqli_query($con, "INSERT INTO admin(adminFullname, adminUsername, adminPassword, adminRole) VALUES('$full','$user','$pass','$role')");
            echo "<script>alert('Admin added successfully!'); window.location='manageAdmin.php';</script>";
            exit();
        }
    } else if ($action === "edit") {
        $id = intval($_POST['adminID']); 
        
        if ($id > 0) {
            $checkUser = mysqli_query($con, "SELECT adminID FROM admin WHERE adminUsername='$user' AND adminID != $id");
            if (mysqli_num_rows($checkUser) > 0) {
                echo "<script>alert('Error: Username is already taken by another admin.');</script>";
            } else {
                $updateQuery = "UPDATE admin SET adminFullname='$full', adminUsername='$user', adminRole='$role'";
                if (!empty($_POST['adminPassword'])) {
                    $pass = password_hash($_POST['adminPassword'], PASSWORD_DEFAULT);
                    $updateQuery .= ", adminPassword='$pass'";
                }
                $updateQuery .= " WHERE adminID=$id"; // This only works if IDs are UNIQUE
                
                if (mysqli_query($con, $updateQuery)) {
                    echo "<script>alert('Admin updated successfully!'); window.location='manageAdmin.php';</script>";
                    exit();
                }
            }
        } else {
            echo "<script>alert('Error: ID was 0. Make sure your database table has AUTO_INCREMENT enabled on adminID.'); window.location='manageAdmin.php';</script>";
            exit();
        }
    }
}

// DELETE ADMIN
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($id === intval($_SESSION['adminID'])) {
        echo "<script>alert('Error: You cannot delete your own account.'); window.location='manageAdmin.php';</script>";
        exit();
    }
    mysqli_query($con, "DELETE FROM admin WHERE adminID=$id");
    header("Location: manageAdmin.php");
}

$admins_arr = [];
$admins_q = mysqli_query($con, "SELECT adminID, adminFullname, adminUsername, adminRole FROM admin ORDER BY adminID DESC");
while ($r = mysqli_fetch_assoc($admins_q)) { $admins_arr[] = $r; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Manage Admins</title>
<link rel="stylesheet" href="adminCSS.css">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<style>
    .main-actions { display:flex; justify-content:space-between; margin: 20px 0; }
    .search-input { width:320px; padding:12px; border-radius:10px; border:1px solid #ccc; }
    .add-admin-btn { padding:10px 20px; background: #038c2a; color:#fff; border:none; border-radius:10px; cursor:pointer; font-weight:700; }
    .admins-table { width:100%; border-collapse: separate; border-spacing: 0 8px; }
    .admins-table thead th { background: #038c2a; color: #fff; padding:15px; text-align: left; }
    .admins-table tbody tr { background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,0.08); }
    .admins-table td { padding:15px; }
    .role-badge { padding: 5px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; }
    .role-super { background: #e3f2fd; color: #1976d2; }
    .role-admin { background: #e8f5e9; color: #038c2a; }
    .action-btn { width:32px; height:32px; border-radius:8px; border:none; cursor:pointer; }
</style>
</head>
<body>

<header>
  <div class="header-left">
    <img src="images/ptclogo.png" alt="PTC">
    <span>Pateros Technological College</span>
  </div>
</header>

<div class="container">
    <aside class="sidebar">
        <nav class="side-menu">
            <a href="admindashboard.php" class="side-btn <?= $current_page == 'admindashboard.php' ? 'active' : '' ?>">
                <span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard
            </a>
            <a href="manage_requests.php" class="side-btn">
                <span class="icon"><i class='bx bx-spreadsheet'></i></span> Manage Requests
            </a>
            <a href="transaction_history.php" class="side-btn">
                <span class="icon"><i class='bx bx-history'></i></span> Transaction History
            </a>
             <a href="transaction.php" class="side-btn">
                <span class="icon"><i class='bx bx-money'></i></span> Transaction Details
            </a>
            <a href="announcement.php" class="side-btn">
                <span class="icon"><i class='bx bxs-megaphone'></i></span> Announcement
            </a>
            <?php if (str_replace(' ', '', $_SESSION['adminRole']) === 'SuperAdmin') : ?>
                <a href="users.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Students</a>
                <a href="manageAdmin.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Manage Users</a>
            <?php endif; ?>
        </nav>
        <div class="logout-container">
            <a href="php/logoutA.php" class="logout"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </div>
    </aside>

    <main style="padding-top:100px;">
        <div class="main-actions">
            <input id="searchInput" class="search-input" placeholder="Search admins..." />
            <button id="openAddAdmin" class="add-admin-btn">+ Add New Admin</button>
        </div>

        <table class="admins-table">
            <thead>
                <tr>
                    <th style="width: 60px;">ID</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th style="text-align:center;">Action</th>
                </tr>
            </thead>
            <tbody id="adminsTableBody">
                <?php foreach($admins_arr as $a): ?>
                <tr>
                    <td><?php echo $a['adminID']; ?></td>
                    <td><?php echo $a['adminFullname']; ?></td>
                    <td><?php echo $a['adminUsername']; ?></td>
                    <td>
                        <span class="role-badge <?php echo strpos($a['adminRole'], 'Super') !== false ? 'role-super' : 'role-admin'; ?>">
                            <?php echo $a['adminRole']; ?>
                        </span>
                    </td>
                    <td style="text-align:center;">
                        <button class="action-btn" style="background:#038c2a; color:white;" onclick='openEditModal(<?php echo json_encode($a); ?>)'>
                            <i class='bx bx-edit-alt'></i>
                        </button>
                        <?php if($a['adminID'] != $_SESSION['adminID']): ?>
                        <button class="action-btn" style="background:#c62828; color:white;" onclick="deleteAdmin(<?php echo $a['adminID']; ?>)">
                            <i class='bx bx-trash'></i>
                        </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</div>

<div class="modal" id="adminModal" style="display:none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);">
    <div class="modal-content" style="margin: 8% auto; background:#fff; width: 400px; padding: 25px; border-radius: 15px; position: relative;">
        <h3 id="modalTitle">Add Admin</h3>
        <form method="POST">
            <input type="hidden" name="action" id="modalAction" value="add">
            <input type="hidden" name="adminID" id="modalAdminID">
            
            <label>Full Name</label>
            <input type="text" name="adminFullname" id="modalFullname" required style="width:100%; padding:10px; margin:10px 0;">
            
            <label>Username</label>
            <input type="text" name="adminUsername" id="modalUsername" required style="width:100%; padding:10px; margin:10px 0;">
            
            <label>Role</label>
            <select name="adminRole" id="modalRole" required style="width:100%; padding:10px; margin:10px 0;">
                <option value="Admin">Admin</option>
                <option value="Super Admin">Super Admin</option>
            </select>

            <label>Password</label>
            <input type="password" name="adminPassword" id="modalPassword" style="width:100%; padding:10px; margin:10px 0;">
            
            <div style="text-align:right; margin-top:15px;">
                <button type="button" onclick="closeAdminModal()">Cancel</button>
                <button type="submit" name="saveAdmin" class="add-admin-btn">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(admin) {
    document.getElementById('modalTitle').innerText = "Edit Admin";
    document.getElementById('modalAction').value = "edit";
    document.getElementById('modalAdminID').value = admin.adminID;
    document.getElementById('modalFullname').value = admin.adminFullname;
    document.getElementById('modalUsername').value = admin.adminUsername;
    document.getElementById('modalRole').value = admin.adminRole;
    document.getElementById('modalPassword').required = false;
    document.getElementById('adminModal').style.display = 'block';
}

document.getElementById('openAddAdmin').onclick = () => {
    document.getElementById('modalTitle').innerText = "Add Admin";
    document.getElementById('modalAction').value = "add";
    document.getElementById('modalAdminID').value = "";
    document.getElementById('modalFullname').value = "";
    document.getElementById('modalUsername').value = "";
    document.getElementById('modalPassword').required = true;
    document.getElementById('adminModal').style.display = 'block';
};

function closeAdminModal() { document.getElementById('adminModal').style.display = 'none'; }
function deleteAdmin(id) { if(confirm('Delete this admin?')) window.location = 'manageAdmin.php?delete=' + id; }
</script>
</body>
</html>