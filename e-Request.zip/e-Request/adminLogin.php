<?php
session_start();

header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
header("Pragma: no-cache"); 

include("php/config.php");


// If already logged in, redirect to dashboard
if (!empty($_SESSION['adminID'])) {
    header("Location: admindashboard.php");
    exit();
}
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'login') {

    $adminUsername = mysqli_real_escape_string($con, trim($_POST['adminUsername'] ?? ''));
    $adminPassword = $_POST['adminPassword'] ?? '';

    if ($adminUsername === '' || $adminPassword === '') {
        $_SESSION['admin_error'] = "Invalid username or password.";
        header("Location: adminLogin.php");
        exit();
    }

    // Get account
    $query = "SELECT * FROM admin WHERE adminUsername = '$adminUsername' LIMIT 1";
    $result = mysqli_query($con, $query);

    if ($row = mysqli_fetch_assoc($result)) {

        $storedHash = $row['adminPassword'];

        // ❗ ACCEPT ONLY HASHED PASSWORDS
        if (!password_verify($adminPassword, $storedHash)) {
            $_SESSION['admin_error'] = "Invalid username or password.";
            header("Location: adminLogin.php");
            exit();
        }

        $_SESSION['adminID']    = $row['adminID'];
        $_SESSION['adminName']  = $row['adminFullname'] ?? $row['adminUsername'];
        $_SESSION['adminRole']  = $row['adminRole'] ?? 'Admin';

        header("Location: admindashboard.php");
        exit();
    }

    $_SESSION['admin_error'] = "Invalid username or password.";
    header("Location: adminLogin.php");
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>e-Request | Admin Login</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" media="screen" href="adminLCSS.css?v=1000">
</head>
<body>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC">
        <span>Pateros Technological College</span>
    </div>
</header>

<div class="container">

    <div class="form-box login">
        <?php
        // Show error from session (set by POST handler) and then clear it.
        if (!empty($_SESSION['admin_error'])) {
            $err = htmlspecialchars($_SESSION['admin_error'], ENT_QUOTES, 'UTF-8');
            echo "<script>alert('{$err}');</script>";
            unset($_SESSION['admin_error']);
        }
        if (!empty($_SESSION['admin_error'])) {
    echo "<script>alert('{$err}');</script>";
}

        ?>
            <form id="loginForm" action="adminLogin.php" method="POST">
            <h1>Admin Login</h1>

            <input type="hidden" name="action" value="login">

            <div class="input-box">
                <input type="text" name="adminUsername" placeholder="Username" autocomplete="off" required>
                <i class='bx bx-user'></i>
            </div>

            <div class="input-box">
                <input type="password" name="adminPassword" placeholder="Password" autocomplete="off" required>
                <i class='bx bx-lock-alt'></i>
            </div>

            <button type="submit" class="btn">Login</button>
        </form>
    </div>

</div>

</body>
</html>
