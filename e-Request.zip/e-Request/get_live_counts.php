<?php
include("php/config.php");

function getCount($con, $status = null) {
    if ($status) {
        $stmt = $con->prepare("SELECT COUNT(*) FROM request WHERE requestStatus = ?");
        $stmt->bind_param("s", $status);
    } else {
        $stmt = $con->prepare("SELECT COUNT(*) FROM request");
    }
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count ?? 0;
}

$studentQuery = "SELECT COUNT(*) as total FROM login WHERE status != 'archived' OR status IS NULL OR status = ''";
$studentResult = mysqli_query($con, $studentQuery);
$totalStudents = ($row = mysqli_fetch_assoc($studentResult)) ? $row['total'] : 0;

$data = [
    'total'      => getCount($con),
    'pending'    => getCount($con, 'Pending'),
    'processing' => getCount($con, 'Processing'),
    'ready'      => getCount($con, 'Ready to Pickup'),
    'done'       => getCount($con, 'Done'),
    'students'   => $totalStudents
];

header('Content-Type: application/json');
echo json_encode($data);
?>