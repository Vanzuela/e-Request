<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['studentNo'])) {
    header("Location: login.php");
    exit;
}
include("php/config.php");

$studentNo = $_SESSION['studentNo'];

/* ================= PAGINATION LOGIC ================= */
$limit = 10; 
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$total_query = "SELECT COUNT(*) FROM request WHERE studentNo = '$studentNo'";
$total_result = mysqli_query($con, $total_query);
$total_rows = mysqli_fetch_array($total_result)[0];
$total_pages = ceil($total_rows / $limit);

$query = "
    SELECT requestID, requestDocument, requestDate, requestStatus, readyTime
    FROM request
    WHERE studentNo = '$studentNo'
    ORDER BY requestDate DESC
    LIMIT $limit OFFSET $offset
";

$result = mysqli_query($con, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-Request: Request History</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashCSS.css?v=<?php echo time(); ?>">

    <style>
        .history-title {
            font-family: "Poppins", sans-serif;
            font-size: 26px;
            font-weight: 600;
            margin-bottom: 18px;
            color: #222;
        }
        .history-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0px 3px 10px rgba(0,0,0,0.1);
        }
        .history-table thead th {
            background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
            color: white;
            padding: 14px;
            text-align: center;
        }
        .history-table td {
            padding: 14px;
            text-align: center;
            border-bottom: 1px solid #eaeaea;
        }

        /* UPDATED STATUS COLORS TO MATCH STEP2.PHP */
        .status-badge { 
            padding: 5px 12px; 
            border-radius: 20px; 
            font-size: 11px;
            font-weight: 700; 
            text-transform: uppercase;
            display: inline-block; 
        }
        .status-pending { background: #fff3e0; color: #ef6c00; }
        .status-processing { background: #e3f2fd; color: #1565c0; }
        .status-readytopickup { background: #e8f5e9; color: #2e7d32; }
        .status-ready { background: #e8f5e9; color: #2e7d32; }
        .status-booked { background: #f3e5f5; color: #7b1fa2; }
        .status-done { background: #eeeeee; color: #616161; }
        .status-cancelled { background: #ffebee; color: #d32f2f; }

        /* PAGINATION STYLING */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
            gap: 10px;
        }
        .pagination a, .pagination span {
            padding: 8px 16px;
            text-decoration: none;
            background: white;
            color: #2e7d32;
            border-radius: 5px;
            border: 1px solid #2e7d32;
            font-weight: 600;
            transition: 0.3s;
        }
        .pagination a:hover {
            background: #2e7d32;
            color: white;
        }
        .pagination .active {
            background: #2e7d32;
            color: white;
            border: 1px solid #2e7d32;
        }
        .pagination .disabled {
            color: #ccc;
            border-color: #ccc;
            pointer-events: none;
        }

        @media (max-width: 768px) {
            .history-table thead { display: none; }
            .history-table, .history-table tbody, .history-table tr, .history-table td { display: block; width: 100%; }
            .history-table tr { margin-bottom: 15px; border: 1px solid #ddd; border-radius: 10px; padding: 10px; background: #fff; }
            .history-table td { text-align: right; padding-left: 50%; position: relative; border-bottom: 1px solid #eee; display: flex; align-items: center; justify-content: flex-end; min-height: 40px;}
            .history-table td:last-child { border-bottom: none; }
            .history-table td::before { content: attr(data-label); position: absolute; left: 10px; width: 45%; text-align: left; font-weight: 700; color: #2e7d32; }
            .pagination a { padding: 6px 12px; font-size: 14px; }
        }
    </style>
</head>
<body>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span class="school-name">Pateros Technological College</span>
    </div>
    <button id="mobileMenuBtn" class="mobile-menu-btn"><i class='bx bx-menu'></i></button>
</header>

<div class="container">
    <aside class="sidebar">
        <div class="profile">
            <div class="name"><?php echo htmlspecialchars($_SESSION['studentName']); ?></div>
            <div class="role">Student</div>
        </div>
        <nav class="side-menu">
            <a href="dashboard.php"><span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard </a>
            <a href="history.php" style="background: rgba(255,255,255,0.12);"><span class="icon"><i class='bx bx-history'></i></span> Request History </a>
            <a href="request.php"><span class="icon"><i class='bx bx-task'></i></span> Request a Document </a>
            <a href="account.php"><span class="icon"><i class='bx bx-user'></i></span> Account </a>
            <a href="php/logout.php" class="mobile-logout"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </nav>
        <div class="logout-container">
            <a href="php/logout.php" class="logout"><i class='bx bx-log-out'></i> Log Out</a>
        </div>
    </aside>

    <main>
        <div class="history-table-wrapper">
            <table class="history-table">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Document</th>
                        <th>Date Requested</th>
                        <th>Status</th>
                        <th>Pickup Schedule</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            // PHP logic to handle spaces in status names like "Ready to Pickup"
                            $rawStatus = $row['requestStatus'];
                            $statusClass = "status-" . strtolower(str_replace(' ', '', $rawStatus));
                            
                            echo "<tr>
                                    <td data-label='Request ID'>{$row['requestID']}</td>
                                    <td data-label='Document'>{$row['requestDocument']}</td>
                                    <td data-label='Date'>".date("M d, Y", strtotime($row['requestDate']))."</td>
                                    <td data-label='Status'><span class='status-badge $statusClass'>{$row['requestStatus']}</span></td>
                                    <td data-label='Pickup'>" . ($row['readyTime'] ?: '—') . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' style='text-align:center;'>No history records found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <a href="?page=<?php echo $page - 1; ?>" class="<?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                <i class='bx bx-chevron-left'></i> Prev
            </a>
            
            <span>Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>

            <a href="?page=<?php echo $page + 1; ?>" class="<?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                Next <i class='bx bx-chevron-right'></i>
            </a>
        </div>
        <?php endif; ?>

    </main>
</div>

<script>
document.getElementById("mobileMenuBtn").addEventListener("click", function() {
    document.querySelector(".sidebar").classList.toggle("show-sidebar");
});
</script>

</body>
</html>