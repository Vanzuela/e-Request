<?php
// getStats.php
header('Content-Type: application/json');
include("php/config.php");
date_default_timezone_set('Asia/Manila');

$response = [
    'dailyCount' => 0,
    'weeklyCount' => 0,
    'monthlyCount' => 0,
    'chart' => [
        'labels' => [],
        'counts' => []
    ]
];

if (!isset($con)) {
    echo json_encode(['error' => 'Database connection not found']);
    exit;
}

$mode = $_GET['mode'] ?? 'month';
$year = isset($_GET['year']) ? intval($_GET['year']) : intval(date('Y'));
$month = isset($_GET['month']) ? intval($_GET['month']) : intval(date('n'));

/* NOTE: I am using 'Done' status. 
   If you want to include 'Ready to Pickup' in these stats, 
   change 'Done' to IN('Done', 'Ready to Pickup') below.
*/

// 1. Daily count (Specific to today)
$dailySql = "SELECT COUNT(*) AS cnt FROM request WHERE requestStatus = 'Done' AND DATE(readyTime) = DATE(NOW())";
$dailyRes = mysqli_query($con, $dailySql);
$response['dailyCount'] = intval(mysqli_fetch_assoc($dailyRes)['cnt'] ?? 0);

// 2. Weekly count (Specific to current week)
$weeklySql = "SELECT COUNT(*) AS cnt FROM request WHERE requestStatus = 'Done' AND YEARWEEK(readyTime, 1) = YEARWEEK(NOW(), 1)";
$weeklyRes = mysqli_query($con, $weeklySql);
$response['weeklyCount'] = intval(mysqli_fetch_assoc($weeklyRes)['cnt'] ?? 0);

// 3. Monthly count (Filtered by the dropdown selection)
$monthlySql = "SELECT COUNT(*) AS cnt FROM request WHERE requestStatus = 'Done' AND YEAR(readyTime) = $year AND MONTH(readyTime) = $month";
$monthlyRes = mysqli_query($con, $monthlySql);
$response['monthlyCount'] = intval(mysqli_fetch_assoc($monthlyRes)['cnt'] ?? 0);


// ====== Chart Logic ======
$chartLabels = [];
$chartCounts = [];

if ($mode === 'month') {
    $lastDay = intval(date('t', strtotime("$year-$month-01")));
    for ($d = 1; $d <= $lastDay; $d++) {
        $chartLabels[] = (string)$d;
        $chartCounts[$d] = 0;
    }

    $sql = "SELECT DAY(readyTime) AS daynum, COUNT(*) AS cnt FROM request 
            WHERE requestStatus = 'Done' AND YEAR(readyTime) = $year AND MONTH(readyTime) = $month 
            GROUP BY DAY(readyTime)";
    $res = mysqli_query($con, $sql);
    while ($r = mysqli_fetch_assoc($res)) {
        $chartCounts[intval($r['daynum'])] = intval($r['cnt']);
    }
    $response['chart']['counts'] = array_values($chartCounts);
    $response['chart']['labels'] = $chartLabels;

} elseif ($mode === 'week') {
    // Current week Monday to Sunday
    $monday = date('Y-m-d', strtotime('monday this week'));
    $days_map = [];
    for ($i = 0; $i < 7; $i++) {
        $timestamp = strtotime("$monday +$i days");
        $dateStr = date('Y-m-d', $timestamp);
        $days_map[$dateStr] = 0;
        $chartLabels[] = date('D j', $timestamp);
    }

    $from = $monday;
    $to = date('Y-m-d', strtotime("$monday +6 days"));
    $sql = "SELECT DATE(readyTime) AS thedate, COUNT(*) AS cnt FROM request 
            WHERE requestStatus = 'Done' AND DATE(readyTime) BETWEEN '$from' AND '$to' 
            GROUP BY DATE(readyTime)";
    $res = mysqli_query($con, $sql);
    while ($r = mysqli_fetch_assoc($res)) {
        $days_map[$r['thedate']] = intval($r['cnt']);
    }
    $response['chart']['counts'] = array_values($days_map);
    $response['chart']['labels'] = $chartLabels;

} else { // 'daily' mode
    // Last 7 days including today
    $days_map = [];
    for ($i = 6; $i >= 0; $i--) {
        $timestamp = strtotime("-$i days");
        $dateStr = date('Y-m-d', $timestamp);
        $days_map[$dateStr] = 0;
        $chartLabels[] = date('M j', $timestamp);
    }

    $from = date('Y-m-d', strtotime("-6 days"));
    $to = date('Y-m-d');
    $sql = "SELECT DATE(readyTime) AS thedate, COUNT(*) AS cnt FROM request 
            WHERE requestStatus = 'Done' AND DATE(readyTime) BETWEEN '$from' AND '$to' 
            GROUP BY DATE(readyTime) ORDER BY DATE(readyTime) ASC";
    $res = mysqli_query($con, $sql);
    while ($r = mysqli_fetch_assoc($res)) {
        if(isset($days_map[$r['thedate']])) {
            $days_map[$r['thedate']] = intval($r['cnt']);
        }
    }
    $response['chart']['counts'] = array_values($days_map);
    $response['chart']['labels'] = $chartLabels;
}

echo json_encode($response);
exit;