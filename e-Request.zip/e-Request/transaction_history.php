<?php
date_default_timezone_set('Asia/Manila');
session_start();
include("php/config.php");

// Validate session
if (!isset($_SESSION['adminID'])) {
    header("Location: adminLogin.php");
    exit();
}

// Fetch the logs (Initial load for 50 records)
$logQuery = "
    SELECT 
        r.requestID, 
        r.requestDocument, 
        COALESCE(l.studentName, 'Deleted Account') AS studentName,
        r.approvedBy, 
        r.readyTime
    FROM request r
    LEFT JOIN login l ON r.studentNo = l.studentNo
    WHERE r.requestStatus IN ('Ready to Pickup', 'Done') AND r.approvedBy IS NOT NULL
    ORDER BY r.readyTime DESC 
    LIMIT 50";

$logResult = mysqli_query($con, $logQuery);
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="adminCSS.css">
    <style>
        header { font-size: 1.2em; padding: 10px; }
        .log-history { padding: 15px; background: #f9f9f9; border-radius: 6px; width: 100%; margin-top: 15px; }
        .log-history h3 { text-align: center; color: #000; margin-bottom: 10px; font-size: 16px; }
        
        .styled-table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 13px; text-align: center; background: white; }
        .styled-table thead tr { background: linear-gradient(0deg, rgb(1, 116, 34) 0%, rgb(32, 186, 45) 100%); color: #ffffff; }
        .styled-table th, .styled-table td { border: 1px solid #ddd; padding: 8px; }
        .styled-table tbody tr:hover { background-color: #f1f1f1; }

        .log-filter-container { display: flex; flex-wrap: wrap; gap: 12px; background: #ffffff; padding: 12px; border-radius: 6px; border: 1px solid #e0e0e0; margin-bottom: 12px; align-items: flex-end; }
        .log-filter-item { display: flex; flex-direction: column; gap: 4px; }
        .log-filter-item label { font-size: 12px; font-weight: bold; color: #333; }
        .log-filter-item input, .log-filter-item select { padding: 6px; border: 1px solid #ccc; border-radius: 4px; }
        
        .apply-btn { padding: 8px 16px; background: #16a34a; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; }
        .apply-btn:hover { background: #128f3c; }

        @media (max-width: 768px) {
            .log-filter-container { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>
<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span>Pateros Technological College</span>
    </div>
</header>

<div class="container">
    <aside class="sidebar">
        <nav class="side-menu">
            <a href="admindashboard.php" class="side-btn <?= $current_page == 'admindashboard.php' ? 'active' : '' ?>">
                <span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard
            </a>
            <a href="manage_requests.php" class="side-btn">
                <span class="icon"><i class='bx bx-spreadsheet'></i></span> Manage Requests
            </a>
            <a href="transaction_history.php" class="side-btn <?= $current_page == 'transaction_history.php' ? 'active' : '' ?>">
                <span class="icon"><i class='bx bx-history'></i></span> Transaction History
            </a>
             <a href="transaction.php" class="side-btn">
                <span class="icon"><i class='bx bx-money'></i></span> Transaction Details
            </a>
            <a href="announcement.php" class="side-btn">
                <span class="icon"><i class='bx bxs-megaphone'></i></span> Announcement
            </a>
            <?php if (str_replace(' ', '', $_SESSION['adminRole']) === 'SuperAdmin') : ?>
                <a href="users.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Students</a>
                <a href="manageAdmin.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Manage Users</a>
            <?php endif; ?>
        </nav>
        <div class="logout-container">
            <a href="php/logoutA.php" class="logout"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </div>
    </aside>

    <main style="padding-top: 60px;">
        <div class="log-history">
            <h3>Transaction History</h3>

            <div class="log-filter-container">
                <div class="log-filter-item">
                    <label>Search Name/ID</label>
                    <input type="text" id="logSearch" placeholder="Search...">
                </div>

                <div class="log-filter-item">
                    <label>Document</label>
                    <select id="logDocument">
                        <option value="">All Documents</option>
                        <option value="Certified True Copy">Certified True Copy (CTC)</option>
                        <option value="Certificate of Grades">Certificate of Grades (COG)</option>
                        <option value="Transcript of Records (TOR)">Transcript of Records (TOR)</option>
                        <option value="Honorable Dismissal">Honorable Dismissal</option>
                        <option value="Certificate as Student">Certificate as Student</option>
                        <option value="Certificate of Graduation">Certificate of Graduation</option>
                    </select>
                </div>

                <div class="log-filter-item">
                    <label>From</label>
                    <input type="date" id="logFrom">
                </div>

                <div class="log-filter-item">
                    <label>To</label>
                    <input type="date" id="logTo">
                </div>

                <div class="log-filter-item">
                    <button onclick="filterLogs()" class="apply-btn">Apply Filter</button>
                </div>
            </div>

            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Document</th>
                        <th>Student</th>
                        <th>Approved By</th>
                        <th>Ready Time</th>
                    </tr>
                </thead>
                <tbody id="logTableBody">
                    <?php
                    if (mysqli_num_rows($logResult) > 0) {
                        while ($row = mysqli_fetch_assoc($logResult)) {
                            echo "<tr>";
                            echo "<td>#" . $row['requestID'] . "</td>";
                            echo "<td>" . htmlspecialchars($row['requestDocument']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['studentName']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['approvedBy']) . "</td>";
                            echo "<td>" . date('M d, Y h:i A', strtotime($row['readyTime'])) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No transactions found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <div id="logPagination" style="text-align:center; margin-top:10px;"></div>
        </div>
    </main>
</div>

<script>
function parseReadyTime(text) {
    // Example input: "Jan 17, 2025 11:45 AM"
    const parts = text.match(/(\w+) (\d{1,2}), (\d{4}) (\d{1,2}):(\d{2}) (AM|PM)/);
    if (!parts) return null;

    const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const month = monthNames.indexOf(parts[1]);
    const day = parseInt(parts[2]);
    const year = parseInt(parts[3]);
    let hour = parseInt(parts[4]);
    const minute = parseInt(parts[5]);
    const ampm = parts[6];

    if (ampm === "PM" && hour !== 12) hour += 12;
    if (ampm === "AM" && hour === 12) hour = 0;

    return new Date(year, month, day, hour, minute);
}

function filterLogs() {
    const searchInput = document.getElementById('logSearch').value.toLowerCase();
    const docSelect = document.getElementById('logDocument').value.toLowerCase();
    const fromDate = document.getElementById('logFrom').value;
    const toDate = document.getElementById('logTo').value;
    const table = document.getElementById('logTableBody');
    const rows = table.getElementsByTagName('tr');

    const from = fromDate ? new Date(fromDate + "T00:00:00") : null;
    const to = toDate ? new Date(toDate + "T23:59:59") : null;

    for (let i = 0; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        if (cells.length < 5) continue;

        const requestID = cells[0].textContent.toLowerCase();
        const docName = cells[1].textContent.toLowerCase();
        const studentName = cells[2].textContent.toLowerCase();
        const readyTimeText = cells[4].textContent.trim();

        const readyTime = parseReadyTime(readyTimeText);

        const matchesSearch = requestID.includes(searchInput) || studentName.includes(searchInput);
        const matchesDoc = docSelect === "" || docName.includes(docSelect);
        const matchesFrom = !from || (readyTime && readyTime >= from);
        const matchesTo = !to || (readyTime && readyTime <= to);

        if (matchesSearch && matchesDoc && matchesFrom && matchesTo) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
}

// Live Search & Filters
document.getElementById('logSearch').addEventListener('keyup', filterLogs);
document.getElementById('logDocument').addEventListener('change', filterLogs);
document.getElementById('logFrom').addEventListener('change', filterLogs);
document.getElementById('logTo').addEventListener('change', filterLogs);
</script>


<script src="JSDash.js"></script>
</body>
</html>