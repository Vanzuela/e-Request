<?php
session_start();
include("php/config.php");

// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer
require __DIR__ . '/phpmailer/vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = mysqli_real_escape_string($con, $_POST['email']);

    // Check if email exists
    $check = mysqli_query($con, "SELECT * FROM login WHERE studentEmail='$email'");
    if (mysqli_num_rows($check) === 0) {
        $_SESSION['message'] = "Email not found.";
        header("Location: forgot_password.php");
        exit();
    }

    // Generate token
    $token   = bin2hex(random_bytes(32));
    $expires = date("Y-m-d H:i:s", strtotime("+30 minutes"));

    // Store token in the database
    $updateQuery = "UPDATE login SET reset_token='$token', reset_expires='$expires' WHERE studentEmail='$email'";
    
    if (mysqli_query($con, $updateQuery)) {
        
        $resetLink = "https://ptc.erequest.online/reset_password.php?token=$token";

        $mail = new PHPMailer(true);

        try {
            // SMTP Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'paterosrequest@gmail.com';
            $mail->Password = 'iuio hkyh yimn zckp'; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('paterosrequest@gmail.com', 'MIS');
            $mail->addAddress($email);

            // Email Content
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            
            // REDESIGNED EMAIL BODY START
            $mail->Body = "
            <div style='font-family: Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; border: 1px solid #eee; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1);'>
                <div style='background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%); padding: 25px; text-align: center;'>
                    <h1 style='color: white; margin: 0; font-size: 24px;'>e-Request System</h1>
                </div>
                <div style='padding: 30px; background-color: #ffffff;'>
                    <h2 style='color: #038c2a; margin-top: 0;'>Reset Your Password</h2>
                    <p style='font-size: 16px;'>You requested a password reset for your <strong>Online Document Request and Scheduling System</strong> account.</p>
                    
                    <p>Click the button below to set a new password. This link will expire in <strong>30 minutes</strong>.</p>
                    
                    <div style='text-align: center; margin: 35px 0;'>
                        <a href='$resetLink' style='background-color: #017422; color: #ffffff; padding: 14px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; font-size: 16px;'>Reset Password</a>
                    </div>

                    <div style='background-color: #f9f9f9; padding: 15px; border-radius: 8px; border: 1px solid #eee; margin: 25px 0;'>
                        <p style='margin: 0; font-size: 12px; color: #777;'>If the button above does not work, copy and paste this link into your browser:</p>
                        <p style='margin: 10px 0 0 0; font-size: 12px; color: #017422; word-break: break-all;'>$resetLink</p>
                    </div>

                    <hr style='border: 0; border-top: 1px solid #eee; margin: 25px 0;'>
                    <p style='font-size: 12px; color: #999; text-align: center;'>If you did not request this change, please ignore this email.</p>
                </div>
                <div style='background-color: #f1f1f1; padding: 15px; text-align: center; font-size: 11px; color: #888;'>
                    &copy; " . date("Y") . " Pateros Technological College | MIS Department
                </div>
            </div>";
            // REDESIGNED EMAIL BODY END

            $mail->AltBody = "To reset your password, please visit this link: $resetLink";

            $mail->send();
            
            // Set success flag to show the success message UI
            $_SESSION['success_state'] = true;
            header("Location: forgot_password.php");
            exit();

        } catch (Exception $e) {
            $_SESSION['message'] = "Email could not be sent. Error: {$mail->ErrorInfo}";
        }
    } else {
        $_SESSION['message'] = "Failed to update database. Please try again.";
    }

    header("Location: forgot_password.php");
    exit();
}

// Determine which UI to show
$showSuccess = isset($_SESSION['success_state']);
unset($_SESSION['success_state']); // Clear it so it doesn't show again on refresh
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Forget Password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="loginCSS.css?v=<?php echo time(); ?>">

    <style>
        .forgot-wrapper {
            min-height: 100vh;
            padding: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .forgot-card {
            width: 100%;
            max-width: 420px;
            background: #fff;
            padding: 32px 28px;
            border-radius: 6px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center; /* Mimics Android gravity="center" */
        }

        .back-btn {
            align-self: flex-start;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 20px;
            color: #000;
            text-decoration: none;
            font-size: 14px;
        }

        .back-btn i { font-size: 28px; }

        .forgot-icon, .success-icon {
            display: block;
            margin: 20px auto;
            width: 100px; /* Matching Android 100dp */
        }

        .forgot-title, .success-title {
            text-align: center;
            font-size: 30px;
            font-weight: 800;
            line-height: 1.2;
            text-transform: uppercase;
            color: #000;
        }

        .forgot-desc, .success-desc {
            text-align: center;
            font-size: 16px;
            margin-top: 15px;
            color: #000;
            line-height: 1.6;
        }

        .forgot-form { width: 100%; margin-top: 30px; }

        .forgot-form input {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            border: 1.5px solid #000;
            border-radius: 4px;
            outline: none;
            box-sizing: border-box;
        }

        .forgot-form button, .login-btn {
            width: 100%;
            margin-top: 20px;
            padding: 14px;
            background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            font-weight: bold;
        }

        /* Success Specific Button (Matching Android Black Background) */
        .login-btn-black {
            background: #000;
            width: 200px; /* Matching Android 200dp */
        }

        .alert-box {
            position: fixed; top: 20px; right: 20px; background: #333;
            color: #fff; padding: 15px 25px; border-radius: 4px;
            z-index: 1000; transition: opacity 0.5s ease;
            display: flex; align-items: center; gap: 15px;
        }
        .alert-close { cursor: pointer; font-size: 20px; }

        @media (max-width: 480px) { .forgot-wrapper { padding: 20px; } }
    </style>
</head>
<body>

<?php if (isset($_SESSION['message'])): ?>
<div class="alert-box" id="alertBox">
    <span class="alert-text"><?= $_SESSION['message']; ?></span>
    <span class="alert-close" onclick="document.getElementById('alertBox').style.opacity='0'">&times;</span>
</div>
<script>
setTimeout(() => { document.getElementById("alertBox").style.opacity = "0"; }, 4000);
</script>
<?php unset($_SESSION['message']); endif; ?>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span>Pateros Technological College</span>
    </div>
</header>

<div class="forgot-wrapper">
    <div class="forgot-card">

        <?php if (!$showSuccess): ?>
            <a href="login.php" class="back-btn">
                <i class='bx bx-left-arrow-alt'></i> Back to Login
            </a>

            <img src="images/forget_password_icon.png" class="forgot-icon" alt="Forgot Password">

            <div class="forgot-title">Forget<br>Password</div>

            <div class="forgot-desc">
                Enter your registered email address and we’ll send you
                a link to reset your password.
            </div>

            <form method="POST" class="forgot-form">
                <input type="email" name="email" placeholder="Enter your PTC email" required>
                <button type="submit">Send Reset Link</button>
            </form>

        <?php else: ?>
            <div class="success-title">Email Sent<br>Successfully</div>
            
            <img src="images/password_updated_icon.png" class="success-icon" alt="Success">

            <div class="success-desc">
                A password reset link has been sent to your PTC email. 
                Please check your inbox and follow the instructions.
            </div>
        <?php endif; ?>

    </div>
</div>

</body>
</html>