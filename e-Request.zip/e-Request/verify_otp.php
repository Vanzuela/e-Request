<?php
session_start();
include("php/config.php");

// If no OTP in session → user should not be here
if (!isset($_SESSION["otp"]) || !isset($_SESSION["otp_email"])) {
    header("Location: account.php");
    exit();
}

$error = "";

// When user submits OTP
if (isset($_POST["verify"])) {
    $inputOtp = trim($_POST["otp"]);
    $realOtp = $_SESSION["otp"];
    $expires = $_SESSION["otp_expiration"];
    $email = $_SESSION["otp_email"];

    if (time() > $expires) {
        $error = "Your OTP has expired. Please request a new one.";
    }
    elseif ($inputOtp == $realOtp) {
        // OTP correct → delete account
        mysqli_query($con, "DELETE FROM login WHERE studentEmail='$email'");

        session_destroy();
        header("Location: login.php");
        exit();
    } 
    else {
        $error = "Incorrect OTP. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Verify OTP</title>
<style>
body {
    font-family: Arial;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    background:#f0f0f0;
}
.box {
    background:white;
    padding:25px;
    border-radius:10px;
    width:350px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}
input {
    width:100%;
    padding:10px;
    margin-top:10px;
    border:1px solid #ccc;
    border-radius:6px;
    font-size:16px;
}
button {
    width:100%;
    margin-top:15px;
    padding:12px;
    border:none;
    background:#d62828;
    color:white;
    border-radius:6px;
    font-size:16px;
    cursor:pointer;
}
.error {
    color:red;
    margin-top:10px;
}
</style>
</head>
<body>

<div class="box">
    <h2>Email Verification</h2>
    <p>Enter the 6-digit OTP sent to your email.</p>

    <form method="POST">
        <input type="text" name="otp" placeholder="Enter OTP" required>
        <button type="submit" name="verify">Verify & Delete Account</button>
    </form>

    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
</div>

</body>
</html>
