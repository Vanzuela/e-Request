<?php
session_start();
if (!isset($_SESSION['adminID'])) {
    header("Location: adminLogin.php");
    exit();
}

include("php/config.php");

$limit = 5; 
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

if (isset($_POST['submit'])) {
    $title = mysqli_real_escape_string($con, $_POST['title']);
    $message = mysqli_real_escape_string($con, $_POST['message']);

    mysqli_query($con, "INSERT INTO announcements (title, message) VALUES ('$title', '$message')");
    header("Location: announcement.php?posted=1");
    exit();
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($con, "DELETE FROM announcements WHERE id=$id");
    header("Location: announcement.php?deleted=1");
    exit();
}

$editMode = false;
if (isset($_GET['edit'])) {
    $editMode = true;
    $id = intval($_GET['edit']);
    $editData = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM announcements WHERE id=$id"));
}

if (isset($_POST['update'])) {
    $id = intval($_POST['announcement_id']);
    $title = mysqli_real_escape_string($con, $_POST['title']);
    $message = mysqli_real_escape_string($con, $_POST['message']);

    mysqli_query($con, "UPDATE announcements SET title='$title', message='$message' WHERE id=$id");
    header("Location: announcement.php?updated=1");
    exit();
}

$fetch = mysqli_query($con, "SELECT * FROM announcements ORDER BY created_at DESC LIMIT $start, $limit");


$totalRecords = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) AS total FROM announcements"))['total'];
$totalPages = ceil($totalRecords / $limit);
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Announcements</title>
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<link rel="stylesheet" href="adminCSS.css">

<style>
body {
    margin: 0;
    background: #f4f4f4;
}

/* ✅ Center the announcement form */
.main-container {
    margin-left: 240px;
    padding: 110px 30px 30px 30px;

    display: flex;
    flex-direction: column;
    align-items: center;   /* <-- Centers horizontally */
    gap: 25px;
}
.list-container {
    width: 100%;
    max-width: 900px;
    margin-top: 20px;
}


.announcement-form {
    background: white;
    padding: 20px;
    border-radius: 15px;
    width: 600px;
    border: 1px solid #dcdcdc;
}
.announcement-form input,
.announcement-form textarea {
    width: 100%;
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #aaa;
    margin-bottom: 12px;
}
.announcement-form button {
    width: 100%;
    padding: 12px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    background: linear-gradient(0deg, #038c2aff 0%, #20ba2dff 100%);
    color: white;
    font-size: 16px;
}

.list-container {
    width: 100%;
    max-width: 900px;
}
.announcement-item {
    background: white;
    padding: 18px;
    border-radius: 10px;
    border: 1px solid #dcdcdc;
    margin-bottom: 12px;
}
.action-buttons a {
    padding: 6px 14px;
    text-decoration: none;
    border-radius: 6px;
    color: white;
    font-size: 14px;
}
.edit-btn { background: #038c2a; }
.delete-btn { background: #d32f2f; }

/* ✅ Pagination Style */
.pagination {
    margin-top: 15px;
    margin-bottom: 30px;
}
.pagination a {
    padding: 8px 15px;
    margin: 0 3px;
    background: #038c2a;
    color: white;
    border-radius: 6px;
    text-decoration: none;
}
.pagination a.active {
    background: #025c1c;
}
.pagination a:hover {
    background: #05a43d;
}
</style>
</head>

<body>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png">
        <span>Pateros Technological College</span>
    </div>
</header>

<div class="container">
    <aside class="sidebar">
        <nav class="side-menu">
            <a href="admindashboard.php" class="side-btn <?= $current_page == 'admindashboard.php' ? 'active' : '' ?>">
                <span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard
            </a>
            <a href="manage_requests.php" class="side-btn">
                <span class="icon"><i class='bx bx-spreadsheet'></i></span> Manage Requests
            </a>
            <a href="transaction_history.php" class="side-btn">
                <span class="icon"><i class='bx bx-history'></i></span> Transaction History
            </a>
             <a href="transaction.php" class="side-btn">
                <span class="icon"><i class='bx bx-money'></i></span> Transaction Details
            </a>
            <a href="announcement.php" class="side-btn">
                <span class="icon"><i class='bx bxs-megaphone'></i></span> Announcement
            </a>
            <?php if (str_replace(' ', '', $_SESSION['adminRole']) === 'SuperAdmin') : ?>
                <a href="users.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Students</a>
                <a href="manageAdmin.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Manage Users</a>
            <?php endif; ?>
        </nav>
        <div class="logout-container">
            <a href="php/logoutA.php" class="logout"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </div>
    </aside>
<div class="main-container">

    <div class="announcement-form">
        <h2><?= $editMode ? "Edit Announcement" : "Create Announcement" ?></h2>

        <?php
        if (isset($_GET['posted'])) echo "<p style='color:green;'> Announcement Posted!</p>";
        if (isset($_GET['deleted'])) echo "<p style='color:red;'> Announcement Deleted!</p>";
        if (isset($_GET['updated'])) echo "<p style='color:green;'> Announcement Updated!</p>";
        ?>

        <form method="POST">
            <?php if ($editMode): ?>
                <input type="hidden" name="announcement_id" value="<?= $editData['id'] ?>">
            <?php endif; ?>

            <input type="text" name="title" placeholder="Announcement Title"
                   value="<?= $editMode ? $editData['title'] : '' ?>" required>

            <textarea name="message" rows="5" placeholder="Announcement Message" required><?= $editMode ? $editData['message'] : '' ?></textarea>

            <button type="submit" name="<?= $editMode ? 'update' : 'submit' ?>">
                <?= $editMode ? 'Update Announcement' : 'Post Announcement' ?>
            </button>
        </form>
    </div>

    <div class="list-container">
        <?php while ($row = mysqli_fetch_assoc($fetch)): ?>
            <div class="announcement-item">
                <h3><?= $row['title']; ?></h3>
                <p><?= nl2br($row['message']); ?></p>

                <div class="action-buttons">
                    <a href="announcement.php?edit=<?= $row['id'] ?>" class="edit-btn">Edit</a>
                    <a href="announcement.php?delete=<?= $row['id'] ?>" class="delete-btn"
                       onclick="return confirm('Are you sure you want to delete this announcement?')">Delete</a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1 ?>">⬅ Previous</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>

        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1 ?>">Next ➤</a>
        <?php endif; ?>
    </div>

</div>

</body>
</html>
