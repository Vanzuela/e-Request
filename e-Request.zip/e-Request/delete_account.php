<?php
session_start();
include("php/config.php");

if (!isset($_SESSION["otp"])) {
    header("Location: account.php");
    exit();
}

$email = $_SESSION["otp_email"];

mysqli_query($con, "DELETE FROM login WHERE studentEmail='$email'");

session_destroy();

header("Location: login.php");
exit();
?>
