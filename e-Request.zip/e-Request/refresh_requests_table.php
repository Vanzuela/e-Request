<?php
include("php/config.php");
mysqli_query($con, "SET time_zone = '+08:00'");

// Get filters from the AJAX request
$filterYear = $_GET['year'] ?? '';
$filterCourse = $_GET['course'] ?? '';
$currentTab = $_GET['tab'] ?? 'pending';
$yearCondition = "";
$courseCondition = "";

if (!empty($filterYear)) {
    $filterYear = mysqli_real_escape_string($con, $filterYear);
    $yearCondition = " AND TRIM(l.studentYear) LIKE '%$filterYear%'"; 
}

if (!empty($filterCourse)) {
    $filterCourse = mysqli_real_escape_string($con, $filterCourse);
    $courseCondition = " AND l.studentCourse LIKE '%$filterCourse%'"; 
}

// Status Logic
if ($currentTab == 'pending') {
    $statusFilter = "'Pending'";
} elseif ($currentTab == 'processing') {
    $statusFilter = "'Processing'";
} else {
    $statusFilter = "'Ready to Pickup'";
}

// 1. Fetch Request Table HTML
$requestQuery = "
    SELECT 
        r.studentNo, l.studentName, l.studentCourse, l.studentYear,
        MAX(r.requestDate) AS latestTimestamp
    FROM request r
    JOIN login l ON r.studentNo = l.studentNo
    WHERE r.requestStatus = $statusFilter $yearCondition $courseCondition
    GROUP BY r.studentNo, l.studentName, l.studentCourse, l.studentYear
    ORDER BY latestTimestamp ASC
";
$requestResult = mysqli_query($con, $requestQuery);

$requestHTML = '<table class="styled-table">
                <thead>
                    <tr>
                        <th style="width: 55%;">Student Details</th>
                        <th style="width: 30%;">Activity Date</th>
                        <th style="width: 15%;">Action</th>
                    </tr>
                </thead>
                <tbody>';

if (mysqli_num_rows($requestResult) > 0) {
    while ($row = mysqli_fetch_assoc($requestResult)) {
        $formattedDate = date("M j, Y • g:i A", strtotime($row['latestTimestamp']));
        $requestHTML .= "<tr>
            <td>
                <div style='font-size: 14px;'><strong>" . htmlspecialchars($row['studentName']) . "</strong></div>
                <div style='font-size: 11px; color: #777;'>" . htmlspecialchars($row['studentCourse']) . " | Year " . htmlspecialchars($row['studentYear']) . "</div>
            </td>
            <td style='text-align:center; font-size:12px;'>$formattedDate</td>
            <td style='text-align:center;'>
                <button onclick=\"openRequestModal('" . htmlspecialchars($row['studentNo']) . "')\" class='ready-btn'>View</button>
            </td>
        </tr>";
    }
} else {
    $requestHTML .= "<tr><td colspan='3' style='text-align:center; padding:50px; color:#999;'>No $currentTab requests found.</td></tr>";
}
$requestHTML .= '</tbody></table>';

// 2. Fetch Booking Table HTML (Only if on Ready tab)
$bookingHTML = '';
if ($currentTab == 'ready') {
    $bookingQuery = "
        SELECT b.bookingID, b.bookingDate, l.studentName, l.studentCourse, l.studentYear, COUNT(rb.requestID) AS docCount
        FROM booking b
        INNER JOIN login l ON b.studentNo = l.studentNo
        LEFT JOIN request_booking rb ON rb.bookingID = b.bookingID
        LEFT JOIN request r ON rb.requestID = r.requestID
        WHERE (r.requestStatus != 'Done' OR r.requestStatus IS NULL) 
        $yearCondition $courseCondition
        GROUP BY b.bookingID HAVING docCount > 0 ORDER BY b.bookingID DESC
    ";
    $bookingResult = mysqli_query($con, $bookingQuery);

    $bookingHTML = '<table class="styled-table">
                    <thead>
                        <tr>
                            <th style="width: 55%;">Student Details</th>
                            <th style="width: 30%;">Scheduled Date</th>
                            <th style="width: 15%;">Action</th>
                        </tr>
                    </thead>
                    <tbody>';
    
    if (mysqli_num_rows($bookingResult) > 0) {
        while ($row = mysqli_fetch_assoc($bookingResult)) {
            $bDate = date("M j, Y • g:i A", strtotime($row['bookingDate']));
            $bookingHTML .= "<tr>
                <td>
                    <div style='font-size: 14px;'><strong>" . htmlspecialchars($row['studentName']) . "</strong></div>
                    <div style='font-size: 11px; color: #777;'>" . htmlspecialchars($row['studentCourse']) . " • Yr " . htmlspecialchars($row['studentYear']) . "</div>
                </td>
                <td style='text-align:center; font-size:12px;'>$bDate</td>
                <td style='text-align:center;'>
                    <button onclick=\"openBookingModal('" . htmlspecialchars($row['bookingID']) . "')\" class='ready-btn' style='background:#bfa181;'>Review</button>
                </td>
            </tr>";
        }
    } else {
        $bookingHTML .= "<tr><td colspan='3' style='text-align:center; padding:20px; color:#999;'>No pickup schedules found.</td></tr>";
    }
    $bookingHTML .= '</tbody></table>';
}

// 3. Get Fresh Pending Count for the Bell
$notifQuery = mysqli_query($con, "SELECT COUNT(*) as total FROM request WHERE requestStatus = 'Pending'");
$notifData = mysqli_fetch_assoc($notifQuery);

// Return everything as JSON
echo json_encode([
    'requestTable' => $requestHTML,
    'bookingTable' => $bookingHTML,
    'pendingCount' => $notifData['total'] ?? 0
]);
?>