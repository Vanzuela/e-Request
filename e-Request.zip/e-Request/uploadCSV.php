<?php
ob_start(); 
session_start();
include("php/config.php"); 

// 1. PHPMailer Loading (Using the same method as your dashboard)
require __DIR__ . '/phpmailer/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

// 2. Security Check
if (!isset($_SESSION['adminID'])) {
    ob_clean();
    echo json_encode(["status" => "error", "message" => "Unauthorized access"]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csvFile'])) {
    $file = $_FILES['csvFile']['tmp_name'];
    
    if (!is_uploaded_file($file)) {
        ob_clean();
        echo json_encode(["status" => "error", "message" => "Temp file not found on server."]);
        exit();
    }

    $handle = fopen($file, "r");
    $insertedCount = 0;
    $errors = [];

    // Skip CSV header
    fgetcsv($handle); 

    $line = 2; 
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        if (empty(array_filter($data))) continue;

        if (count($data) < 6) {
            $errors[] = "Line $line: Insufficient columns.";
            $line++;
            continue;
        }

        // 3. Data Cleaning
        $studentNo     = mysqli_real_escape_string($con, $data[0]);
        $studentName   = mysqli_real_escape_string($con, $data[1]);
        $studentEmail  = mysqli_real_escape_string($con, $data[2]);
        $studentCourse = mysqli_real_escape_string($con, $data[3]);
        $studentYear   = mysqli_real_escape_string($con, $data[4]);
        $tempPass      = mysqli_real_escape_string($con, $data[5]);

        // 4. Database Check
        $check = mysqli_query($con, "SELECT studentNo FROM login WHERE studentNo = '$studentNo'");
        
        if (mysqli_num_rows($check) == 0) {
            $query = "INSERT INTO login (studentNo, studentName, studentEmail, studentCourse, studentYear, studentPassword, first_login) 
                      VALUES ('$studentNo', '$studentName', '$studentEmail', '$studentCourse', '$studentYear', '$tempPass', 1)";
            
            if (mysqli_query($con, $query)) {
                
                // 5. Professional HTML Email Construction
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'paterosrequest@gmail.com';
                    $mail->Password = 'iuio hkyh yimn zckp';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->setFrom('paterosrequest@gmail.com', 'e-Request System');
                    $mail->addAddress($studentEmail);

                    $mail->isHTML(true);
                    $mail->Subject = 'Account Created - e-Request System';

                    // UPDATE THIS LINK TO YOUR ACTUAL LOGIN PAGE URL
                    $loginUrl = "https://ptc.erequest.online/login.php"; 

                    $mail->Body = "
                    <div style='font-family: Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; border: 1px solid #eee; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1);'>
                        <div style='background: linear-gradient(0deg, #017422 0%, #20ba2d 100%); padding: 25px; text-align: center;'>
                            <h1 style='color: white; margin: 0; font-size: 24px;'>e-Request System</h1>
                        </div>
                        <div style='padding: 30px; background-color: #ffffff;'>
                            <p style='font-size: 16px;'>Dear <strong>$studentName</strong>,</p>
                            <p>An account has been created for you in the <strong>Online Document Request and Scheduling System</strong> of Pateros Technological College.</p>
                            
                            <div style='background-color: #f4fdf4; padding: 20px; border-radius: 8px; border: 1px solid #d4edda; margin: 25px 0;'>
                                <p style='margin: 0 0 10px 0;'><strong>Student Number:</strong> <span style='color: #333;'>$studentNo</span></p>
                                <p style='margin: 0;'><strong>Temporary Password:</strong> <span style='color: #d9534f; font-weight: bold;'>$tempPass</span></p>
                            </div>

                            <p>You can now log in using the button below. For security, we recommend changing your password after your first login.</p>
                            
                            <div style='text-align: center; margin: 35px 0;'>
                                <a href='$loginUrl' style='background-color: #017422; color: #ffffff; padding: 14px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; font-size: 16px;'>Log In to Student Portal</a>
                            </div>

                            <hr style='border: 0; border-top: 1px solid #eee; margin: 25px 0;'>
                            <p style='font-size: 12px; color: #888; text-align: center;'>This is an automated message, please do not reply directly to this email.</p>
                        </div>
                        <div style='background-color: #f9f9f9; padding: 15px; text-align: center; font-size: 11px; color: #999; border-top: 1px solid #eee;'>
                            &copy; " . date("Y") . " Pateros Technological College | e-Request System
                        </div>
                    </div>";

                    $mail->AltBody = "Hi $studentName, your e-Request account is ready. User: $studentNo, Pass: $tempPass. Login here: $loginUrl";

                    $mail->send();
                    $insertedCount++;
                } catch (Exception $e) {
                    $errors[] = "Saved $studentNo, but email failed: {$mail->ErrorInfo}";
                    $insertedCount++; 
                }
            } else {
                $errors[] = "Line $line: Database Error: " . mysqli_error($con);
            }
        } else {
            $errors[] = "Line $line: Student $studentNo already exists.";
        }
        $line++;
    }
    fclose($handle);

    // 6. Final JSON Output
    ob_clean(); 
    echo json_encode([
        "status" => "ok", 
        "message" => "Successfully processed $insertedCount student(s).",
        "details" => $errors
    ]);

} else {
    ob_clean();
    echo json_encode(["status" => "error", "message" => "No file received by the server."]);
}
?>