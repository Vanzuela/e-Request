<?php
session_start();
include("php/config.php");

if(!isset($_SESSION['adminID'])){
    echo json_encode(['Pending'=>[],'Processing'=>[],'Ready to Pickup'=>[],'Done'=>[]]);
    exit();
}

$statuses=['Pending','Processing','Ready to Pickup','Done'];
$output=[];
foreach($statuses as $status){
    $res=mysqli_query($con,"SELECT id, documentName, studentName, requestDate FROM request WHERE requestStatus='$status' ORDER BY requestDate DESC LIMIT 10");
    $requests=[];
    while($row=mysqli_fetch_assoc($res)){
        $requests[]=$row;
    }
    $output[$status]=$requests;
}
echo json_encode($output);
?>
