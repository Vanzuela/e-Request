<?php
session_start();
include("php/config.php");

if (isset($_GET['requestID'])) {
    $requestID = mysqli_real_escape_string($con, $_GET['requestID']);
    
    $query = "
        SELECT 
            request.requestID, 
            login.studentName, 
            login.studentNo, 
            request.requestDocument,
            request.requestStatus,
            request.requestDate
        FROM request 
        INNER JOIN login ON request.studentNo = login.studentNo 
        WHERE request.requestID = '$requestID'";
    
    $result = mysqli_query($con, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        // format date to a friendly string to avoid formatting in JS (optional)
        if (!empty($data['requestDate'])) {
            $data['requestDate'] = date('m/d/Y h:i A', strtotime($data['requestDate']));
        }
        echo json_encode($data);
    } else {
        echo json_encode(null);
    }
}
?>
