<?php 
if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 
} 

include("php/config.php"); 

$studentNo = $_SESSION['studentNo']; 
$studentName = $_SESSION['studentName']; 

/* Get latest booking */
$bookingQuery = "SELECT bookingID, bookingDate 
                 FROM booking 
                 WHERE studentNo = ? 
                 ORDER BY bookingID DESC 
                 LIMIT 1";
$stmt = $con->prepare($bookingQuery);
$stmt->bind_param('s', $studentNo);
$stmt->execute();
$bookingResult = $stmt->get_result();
$bookingRow = $bookingResult->fetch_assoc();

$bookingID = $bookingRow['bookingID'] ?? 'N/A';
$bookingDate = $bookingRow['bookingDate'] ?? 'N/A';

/* Get documents for this booking - Including price from the request table */
$requestQuery = "
    SELECT r.requestDocument, r.requestStatus, r.price
    FROM request AS r
    INNER JOIN request_booking AS rb ON r.requestID = rb.requestID
    WHERE rb.bookingID = ?
";

$stmt = $con->prepare($requestQuery);
$stmt->bind_param('i', $bookingID);
$stmt->execute();
$requestResult = $stmt->get_result();

$documents = []; 
$totalPrice = 0;

while ($row = $requestResult->fetch_assoc()) { 
    // Ensure price is treated as a number; fallback to 0 if null/empty
    $priceVal = (isset($row['price']) && $row['price'] != '') ? (float)$row['price'] : 0.00;
    
    $documents[] = [
        'name' => $row['requestDocument'],
        'price' => $priceVal
    ]; 
    $totalPrice += $priceVal;
} 
?>

<style>
    .step4-container {
        max-width: 700px;
        margin: 0 auto;
        padding: 20px;
        text-align: center;
    }

    .success-card {
        background: white;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        border-top: 5px solid #038c2a;
    }

    .check-icon {
        font-size: 60px;
        color: #20ba2d;
        margin-bottom: 20px;
    }

    .pickup-info {
        background: #f1f8e9;
        padding: 20px;
        border-radius: 10px;
        margin: 25px 0;
        border: 1px dashed #2e7d32;
    }

    .pickup-info h3 {
        color: #1b5e20;
        margin: 0 0 10px 0;
        font-size: 1.2rem;
    }

    .styled-table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 0.9rem;
        text-align: left;
    }

    .styled-table thead tr {
        background-color: #f8f9fa;
        border-bottom: 2px solid #eeeeee;
    }

    .styled-table th, .styled-table td {
        padding: 12px 15px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #eeeeee;
    }

    .status-booked-badge {
        background: #f3e5f5;
        color: #7b1fa2;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
    }

    .action-area {
        margin-top: 30px;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 15px;
    }

    #generateReceiptBtn {
        background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
        color: white;
        padding: 15px 30px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: 0.3s;
        box-shadow: 0 4px 12px rgba(46, 125, 50, 0.2);
    }

    #generateReceiptBtn:hover {
        background: #1b5e20;
        transform: translateY(-2px);
    }

    .notice {
        font-size: 13px;
        color: #666;
        line-height: 1.5;
    }
</style>

<div class="step4-container">
    <div class="success-card">
        <i class='bx bxs-badge-check check-icon'></i>
        <h2 style="margin:0; color:#333;">Booking Confirmed!</h2>
        <p style="color:#666;">Your pickup schedule has been successfully recorded.</p>

        <div class="pickup-info">
            <h3>Schedule: <?php echo date("F j, Y", strtotime($bookingDate)); ?></h3>
            <p style="margin:0; color:#555; font-size:14px;">Please visit the Registrar's Office during office hours.</p>
        </div>

        <table class="styled-table"> 
            <thead> 
                <tr> 
                    <th>Document Name</th> 
                    <th style="text-align: right;">Price</th>
                    <th style="text-align: center;">Status</th> 
                </tr> 
            </thead> 
            <tbody> 
                <?php if (count($documents) > 0) { 
                    foreach ($documents as $doc) { 
                        echo "<tr>"; 
                        echo "<td style='font-weight:600; color:#444;'>" . htmlspecialchars($doc['name']) . "</td>"; 
                        echo "<td style='text-align: right; color:#2e7d32; font-weight:bold;'>₱" . number_format($doc['price'], 2) . "</td>";
                        echo "<td style='text-align: center;'><span class='status-booked-badge'>Booked</span></td>"; 
                        echo "</tr>"; 
                    } 
                    // Grand Total Row
                    echo "<tr style='background:#f9f9f9; font-weight:bold;'>";
                    echo "<td style='text-align: right;'>TOTAL:</td>";
                    echo "<td style='text-align: right; color:#d32f2f;'>₱" . number_format($totalPrice, 2) . "</td>";
                    echo "<td></td>";
                    echo "</tr>";
                } else { 
                    echo "<tr><td colspan='3' style='text-align:center;'>No documents found.</td></tr>"; 
                } ?> 
            </tbody> 
        </table>

        <div class="action-area">
            <button id="generateReceiptBtn">
                <i class='bx bxs-file-pdf' style="font-size:20px;"></i>
                Download Booking Ticket
            </button>
            <p class="notice">
                <i class='bx bx-info-circle'></i> 
                Please present the printed or digital copy of the booking ticket along with your <b>Claim Stub</b> and <b>Valid ID</b> upon pickup.
            </p>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script> 
<script> 
document.getElementById("generateReceiptBtn").addEventListener("click", function() { 
    const { jsPDF } = window.jspdf; 
    const bookingID = "<?php echo htmlspecialchars($bookingID); ?>"; 
    const bookingDate = "<?php echo date('F j, Y', strtotime($bookingDate)); ?>"; 
    const documents = <?php echo json_encode($documents); ?>; 
    const totalPriceNum = <?php echo (float)$totalPrice; ?>;
    const totalAmount = totalPriceNum.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    const studentName = "<?php echo htmlspecialchars($studentName); ?>"; 
    const studentNo = "<?php echo htmlspecialchars($studentNo); ?>"; 

    // A6 size [105mm x 148mm]
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: [148, 105] }); 
    
    // Header
    doc.setFillColor(3, 140, 42);
    doc.rect(0, 0, 105, 25, 'F'); 

    doc.setTextColor(255, 255, 255); 
    doc.setFont('helvetica', 'bold'); 
    doc.setFontSize(14); 
    doc.text("E-REQUEST SYSTEM", 52.5, 12, { align: "center" });
    doc.setFontSize(10);
    doc.text("Booking Confirmation Ticket", 52.5, 18, { align: "center" });

    // Details Section
    doc.setTextColor(0, 0, 0); 
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text("STUDENT DETAILS", 10, 35);
    doc.line(10, 36, 95, 36);

    doc.setFont('helvetica', 'normal'); 
    doc.text(`Name: ${studentName}`, 10, 42);
    doc.text(`Student No: ${studentNo}`, 10, 48);
    doc.text(`Booking ID: #${bookingID}`, 10, 54);

    doc.setFont('helvetica', 'bold');
    doc.text(`PICKUP DATE: ${bookingDate}`, 10, 60);

    // Document List Header
    doc.setFont('helvetica', 'bold'); 
    doc.text("DOCUMENTS & FEES:", 10, 72); 
    doc.line(10, 73, 95, 73);
    doc.setFont('helvetica', 'normal'); 

    let yPosition = 78; 
    documents.forEach((docItem) => { 
        // Document Name
        doc.text(`• ${docItem.name}`, 12, yPosition); 
        // Individual Price aligned to right
        doc.text(`PHP ${docItem.price.toFixed(2)}`, 95, yPosition, { align: "right" });
        yPosition += 6; 
    }); 

    // Total Amount Section
    doc.line(10, yPosition, 95, yPosition);
    yPosition += 6;
    doc.setFont('helvetica', 'bold');
    doc.text("TOTAL AMOUNT:", 12, yPosition);
    doc.text(`PHP ${totalAmount}`, 95, yPosition, { align: "right" });

    // Footer
    doc.setDrawColor(200, 200, 200);
    doc.line(10, 132, 95, 132);
    doc.setFontSize(7);
    doc.setTextColor(100, 100, 100);
    doc.text("This serves as your proof of schedule.", 52.5, 138, { align: "center" }); 
    doc.text("Please bring your School ID or Valid ID.", 52.5, 142, { align: "center" }); 
    
    doc.save(`PTC_Booking_${bookingID}.pdf`); 
}); 
</script>