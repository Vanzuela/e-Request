 <?php
session_start();
include("php/config.php");

// Security: If the student is not logged in, send them back to login page
if (!isset($_SESSION['studentID'])) {
    header("Location: login.php");
    exit();
}

$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_password'])) {
    $studentNo = $_SESSION['studentID'];
    $newPass = mysqli_real_escape_string($con, $_POST['newPassword']);
    $confirmPass = mysqli_real_escape_string($con, $_POST['confirmPassword']);

    if ($newPass !== $confirmPass) {
        $message = "Passwords do not match!";
        $messageType = "error";
    } elseif (strlen($newPass) < 6) {
        $message = "Password must be at least 6 characters long.";
        $messageType = "error";
    } else {
        $updateQuery = "UPDATE login SET studentPassword = '$newPass', first_login = 0 WHERE studentNo = '$studentNo'";
        
        if (mysqli_query($con, $updateQuery)) {
            header("Location: dashboard.php");
            exit();
        } else {
            $message = "Database error. Please try again.";
            $messageType = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Set New Password - PTC</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="loginCSS.css?v=<?php echo time(); ?>">
    <style>
        .change-pass-wrapper {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .change-pass-card {
            width: 100%;
            max-width: 420px;
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            box-sizing: border-box;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
        }
        .instruction-text {
            font-size: 14px;
            color: #555;
            margin-bottom: 25px;
            line-height: 1.5;
        }
        .input-group {
            position: relative;
            margin-bottom: 15px;
            text-align: left;
        }
        .input-group input {
            width: 100%;
            padding: 14px;
            padding-right: 45px; /* Space for the icon */
            border: 1.5px solid #000;
            border-radius: 4px;
            outline: none;
            box-sizing: border-box;
        }
        /* Style for the eye icon */
        .input-group i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            cursor: pointer;
            color: #555;
        }
        .btn-update {
            width: 100%;
            padding: 14px;
            background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            text-transform: uppercase;
            margin-top: 10px;
        }
        .alert-msg {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 4px;
            font-size: 14px;
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC">
        <span>Pateros Technological College</span>
    </div>
</header>

<div class="change-pass-wrapper">
    <div class="change-pass-card">
        <h2 style="text-transform: uppercase; margin-bottom: 10px; font-weight: 800;">New Password</h2>
        <p class="instruction-text">
            Welcome, <strong><?php echo $_SESSION['studentName']; ?></strong>!<br>
            For security reasons, please change your temporary password before proceeding to your dashboard.
        </p>

        <?php if ($message): ?>
            <div class="alert-msg"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="input-group">
                <input type="password" name="newPassword" id="newPassword" placeholder="Create New Password" required minlength="6">
                <i class="bx bx-hide toggle-password" data-target="newPassword"></i>
            </div>
            <div class="input-group">
                <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm New Password" required minlength="6">
                <i class="bx bx-hide toggle-password" data-target="confirmPassword"></i>
            </div>
            <button type="submit" name="update_password" class="btn-update">Update Password</button>
        </form>
    </div>
</div>

<script>
// Logic to toggle password visibility
document.querySelectorAll(".toggle-password").forEach(icon => {
    icon.addEventListener("click", () => {
        const input = document.getElementById(icon.dataset.target);
        if (!input) return;

        if (input.type === "password") {
            input.type = "text";
            icon.classList.replace("bx-hide", "bx-show");
        } else {
            input.type = "password";
            icon.classList.replace("bx-show", "bx-hide");
        }
    });
});
</script>

</body>
</html>