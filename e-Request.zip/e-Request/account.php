<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['valid'])) {
    header("Location: login.php");
    exit();
}
include("php/config.php");

$studentEmail = $_SESSION['valid'];

// ✅ Fetch student data
$query = mysqli_query($con, "SELECT * FROM login WHERE studentEmail='$studentEmail'");
$student = mysqli_fetch_assoc($query);

// ✅ Handle delete account
if (isset($_POST['deleteAccount'])) {
    mysqli_query($con, "DELETE FROM login WHERE studentEmail='$studentEmail'");
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Account</title>

<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<link rel="stylesheet" href="dashCSS.css">

<style>
/* Page-specific layout tweaks - minimal, do not conflict with dashCSS */
.profile-page-main {
    margin-left: 220px; /* desktop reserve for sidebar */
    padding: 40px;
    min-height: calc(100vh - 95px);
    display: flex;
    justify-content: center;
    align-items: center;
}

/* central card */
.profile-wrapper {
    width: 100%;
    max-width: 520px;
    padding: 32px;
    background: #ffffff;
    border-radius: 15px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.08);
}

.profile-wrapper h2 {
    text-align: center;
    color: black;
    font-size: 24px;
    margin-bottom: 18px;
}

.profile-info {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.field-group {
    display: flex;
    flex-direction: column;
    text-align: left;
}

.field-group label {
    font-size: 13px;
    color: #333;
    font-weight: 600;
    margin-bottom: 6px;
}

.field-group input {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 10px 12px;
    width: 100%;
    font-size: 15px;
    color: #111;
    background: #fafafa;
}

/* delete button */
.delete-btn {
    margin-top: 12px;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: #c92a2a;
    color: white;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    transition: background 0.18s ease;
}
.delete-btn:hover { background: #d9534f; }
/* OTP Modal Styles */
.otp-modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0; top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.55);
    justify-content: center;
    align-items: center;
}

.otp-modal-content {
    background: white;
    padding: 25px;
    width: 90%;
    max-width: 420px;
    border-radius: 12px;
    text-align: center;
}

#otpInput {
    width: 80%;
    padding: 10px;
    font-size: 17px;
    margin-top: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    text-align: center;
    letter-spacing: 4px;
}

.otp-buttons {
    margin-top: 20px;
    display: flex;
    justify-content: space-around;
}

.verify-btn {
    background: #008f32;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

.cancel-btn {
    background: #c40000;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

.otp-error {
    margin-top: 10px;
    color: red;
    font-weight: bold;
}
/* Modern Confirmation Modal */
.confirm-modal {
    display: none;
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0,0,0,0.55);
    justify-content: center;
    align-items: center;
    z-index: 3000;
}

.confirm-modal-content {
    background: #fff;
    width: 90%;
    max-width: 420px;
    padding: 25px;
    border-radius: 14px;
    text-align: center;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    animation: fadeIn 0.3s ease;
}

.confirm-title {
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 10px;
    color: #222;
}

.confirm-text {
    font-size: 15px;
    color: #555;
    margin-bottom: 20px;
}

.confirm-buttons {
    display: flex;
    justify-content: space-between;
    gap: 15px;
}

.confirm-btn-ok {
    flex: 1;
    background: #2c7be5;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 15px;
}
.confirm-btn-ok:hover {
    background: #1a68d1;
}

.confirm-btn-cancel {
    flex: 1;
    background: #c92a2a;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 15px;
}
.confirm-btn-cancel:hover {
    background: #b31e1e;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}



/* Small screens (mobile) adjustments */
@media (max-width: 768px) {

    /* header shorter on mobile is handled by dashCSS */
    .profile-page-main {
        margin-left: 0 !important;
        padding: 20px;
        min-height: auto;
        justify-content: flex-start;
        align-items: stretch;
    }

    .profile-wrapper {
        margin-top: 12px;
        padding: 20px;
        max-width: 100%;
    }

    /* make sure inputs & text fit neatly */
    .field-group label { text-align: left; }
}

/* Very small screens */
@media (max-width: 420px) {
    .profile-wrapper { padding: 16px; }
    .profile-wrapper h2 { font-size: 20px; }
}
</style>

</head>
<body>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span class="school-name">Pateros Technological College</span>
    </div>

    <!-- Mobile hamburger (same class/id used by dashboard) -->
    <button id="mobileMenuBtn" class="mobile-menu-btn" aria-label="Open menu">
        <i class='bx bx-menu'></i>
    </button>
</header>

<div class="container">

    <!-- SIDEBAR (same structure as dashboard, keep id for JS toggling) -->
    <aside class="sidebar" id="sidebar">
        <div class="profile">
            <div class="name"><?= htmlspecialchars($_SESSION['studentName'] ?? 'Student', ENT_QUOTES, 'UTF-8') ?></div>
            <div class="role">Student</div>
        </div>

        <nav class="side-menu">
            <a href="dashboard.php"><span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard</a>
            <a href="history.php"><span class="icon"><i class='bx bx-history'></i></span> Request History</a>
            <a href="request.php"><span class="icon"><i class='bx bx-task'></i></span> Request a Document</a>
            <a href="account.php" class="active"><span class="icon"><i class='bx bx-user'></i></span> Account</a>

            <!-- mobile logout inside menu (dashCSS shows .mobile-logout on mobile) -->
            <a href="php/logout.php" class="mobile-logout desktop-hide"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </nav>

        <div class="logout-container desktop-only">
            <a href="php/logout.php" class="logout">
                <span class="icon"><i class='bx bx-log-out'></i></span>
                Log Out
            </a>
        </div>
    </aside>

    <!-- MAIN content -->
    <main class="profile-page-main" role="main">
        <div class="profile-wrapper" role="region" aria-labelledby="profile-heading">
            <h2 id="profile-heading">Account Information</h2>

            <div class="profile-content">
                <form method="POST" class="profile-info">
                    <div class="field-group">
                        <label>Student No.</label>
                        <input type="text" value="<?= htmlspecialchars($student['studentNo'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled>
                    </div>

                    <div class="field-group">
                        <label>Full Name</label>
                        <input type="text" value="<?= htmlspecialchars($student['studentName'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled>
                    </div>

                    <div class="field-group">
                        <label>Year Level</label>
                        <input type="text" value="<?= htmlspecialchars($student['studentYear'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled>
                    </div>

                    <div class="field-group">
                        <label>Course</label>
                        <input type="text" value="<?= htmlspecialchars($student['studentCourse'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled>
                    </div>

                    <div class="field-group">
                        <label>Email</label>
                        <input type="text" value="<?= htmlspecialchars($student['studentEmail'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled>
                    </div>

                    <button type="button" class="delete-btn" onclick="sendOtp()">
    Delete My Account
</button>

                </form>
            </div>
        </div>
    </main>

</div>

<script>
// =============================
// MOBILE SIDEBAR BEHAVIOR
// =============================
document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) {

        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('show-sidebar');
            document.body.style.overflow =
                sidebar.classList.contains('show-sidebar') ? 'hidden' : '';
        });

        document.addEventListener('click', function (e) {
            if (!sidebar.classList.contains('show-sidebar')) return;
            const isInside = sidebar.contains(e.target) || toggleBtn.contains(e.target);
            if (!isInside) {
                sidebar.classList.remove('show-sidebar');
                document.body.style.overflow = '';
            }
        });

        document.querySelectorAll('.side-menu a').forEach(a => {
            a.addEventListener('click', function () {
                if (window.innerWidth <= 768) {
                    sidebar.classList.remove('show-sidebar');
                    document.body.style.overflow = '';
                }
            });
        });
    }
});

// =============================
// OTP MODAL FUNCTIONS
// =============================
function openOtpModal() {
    document.getElementById("otpModal").style.display = "flex";
}

function closeOtpModal() {
    document.getElementById("otpModal").style.display = "none";
}

// =============================
// SEND OTP
// =============================
function sendOtp() {
    document.getElementById("confirmOtpModal").style.display = "flex";
}

// Close modal
function closeConfirmOtp() {
    document.getElementById("confirmOtpModal").style.display = "none";
}

// If user confirms
function proceedSendOtp() {

    // Hide confirm modal
    closeConfirmOtp();

    // Continue with existing OTP sending…
    fetch("send_otp.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: "<?= $studentEmail ?>" })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "sent") {
            openOtpModal(); // your existing OTP modal
        } else {
            alert("Failed to send OTP: " + data.message);
        }
    });
}

// =============================
// VERIFY OTP
// =============================
document.addEventListener("DOMContentLoaded", function() {
    const verifyBtn = document.getElementById("verifyOtpBtn");

    verifyBtn.addEventListener("click", function() {
        let otpValue = document.getElementById("otpInput").value.trim();

        fetch("verify_otp_ajax.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ otp: otpValue })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                window.location.href = "delete_account.php";
            } else {
                document.getElementById("otpError").innerText = "Invalid OTP. Try again.";
            }
        });
    });
});
</script>
<!-- Beautiful Custom Confirmation Modal -->
<div id="confirmOtpModal" class="confirm-modal">
    <div class="confirm-modal-content">
        <div class="confirm-text">
            You will receive an OTP via email to proceed with account deletion. Continue?
        </div>

        <div class="confirm-buttons">
            <button class="confirm-btn-ok" onclick="proceedSendOtp()">Yes, Continue</button>
            <button class="confirm-btn-cancel" onclick="closeConfirmOtp()">Cancel</button>
        </div>
    </div>
</div>



<div id="otpModal" class="otp-modal">
    <div class="otp-modal-content">
        <h3>Enter OTP to Confirm Deletion</h3>
        <p>A 6-digit OTP was sent to your email.</p>

        <input type="text" id="otpInput" maxlength="6" placeholder="Enter OTP">

        <div class="otp-buttons">
            <button id="verifyOtpBtn" class="verify-btn">Verify OTP</button>
            <button onclick="closeOtpModal()" class="cancel-btn">Cancel</button>
        </div>

        <p id="otpError" class="otp-error"></p>
    </div>
</div>

</body>
</html>
