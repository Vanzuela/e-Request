<?php
include("php/config.php");

$studentNo = mysqli_real_escape_string($con, $_GET['studentNo']);

$query = "
    SELECT 
        r.requestID,
        ri.documentName,
        r.requestStatus
    FROM request r
    JOIN request_items ri ON r.requestID = ri.requestID
    WHERE r.studentNo = '$studentNo'
    AND r.requestStatus IN ('Pending','Processing')
";

$result = mysqli_query($con, $query);

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);
