<?php
include("../php/config.php");
session_start();

if (!isset($_SESSION['valid']) && !isset($_SESSION['adminID'])) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['error' => 'forbidden']);
    exit();
}

// Added 'status' to the SELECT query so the frontend knows if an account is archived
$query = "SELECT studentNo, studentName, studentEmail, studentCourse, studentYear, status 
          FROM login 
          ORDER BY studentName ASC";

$result = mysqli_query($con, $query);

if (!$result) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => mysqli_error($con)]);
    exit();
}

$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    // If status is empty/null in database, default it to 'active' 
    // to prevent the frontend filter from breaking
    if (empty($row['status'])) {
        $row['status'] = 'active';
    }
    $users[] = $row;
}

header("Content-Type: application/json");
echo json_encode($users);
?>