<?php
include("../php/config.php");

// Ensure fields exist
$action = $_POST['action'] ?? '';
$studentNo = $_POST['studentNo'] ?? '';
$name = $_POST['studentName'] ?? '';
$email = $_POST['studentEmail'] ?? '';
$course = $_POST['studentCourse'] ?? '';
$year = $_POST['studentYear'] ?? '';

if ($action === "add") {
    $pass = "12345"; // default password
    $hashedPass = password_hash($pass, PASSWORD_DEFAULT);

    $stmt = $con->prepare("INSERT INTO login 
        (studentNo, studentName, studentEmail, studentCourse, studentYear, studentPassword)
        VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $studentNo, $name, $email, $course, $year, $hashedPass);

} else {
    $original = $_POST['originalStudentNo'] ?? '';

    $stmt = $con->prepare("UPDATE login SET 
        studentNo=?, 
        studentName=?, 
        studentEmail=?, 
        studentCourse=?, 
        studentYear=?
        WHERE studentNo=?");

    $stmt->bind_param("ssssss", $studentNo, $name, $email, $course, $year, $original);
}

$stmt->execute();
$stmt->close();

header("Location: ../admindashboard.php");
exit();
?>
