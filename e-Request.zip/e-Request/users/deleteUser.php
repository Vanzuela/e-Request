<?php
include("../php/config.php");
header('Content-Type: application/json');

if (!isset($_GET['studentNo']) || empty($_GET['studentNo'])) {
    echo json_encode(['status' => 'error', 'message' => 'Missing studentNo']);
    exit();
}

$studentNo = $_GET['studentNo'];

$stmt = $con->prepare("DELETE FROM login WHERE studentNo = ?");
$stmt->bind_param("s", $studentNo);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(['status' => 'ok', 'deleted' => $studentNo]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Student not found']);
}

$stmt->close();
$con->close();
?>
