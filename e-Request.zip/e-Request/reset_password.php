<?php
session_start();
include("php/config.php");

if (!isset($_GET['token'])) {
    die("Invalid request.");
}

$token = mysqli_real_escape_string($con, $_GET['token']);
$result = mysqli_query($con, "SELECT * FROM login WHERE reset_token='$token' AND reset_expires > NOW()");

if (mysqli_num_rows($result) === 0) {
    die("Reset link is invalid or has expired.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newPassword = mysqli_real_escape_string($con, $_POST['password']);
    $confirmPassword = mysqli_real_escape_string($con, $_POST['confirm_password']);

    if ($newPassword !== $confirmPassword) {
        $error_message = "Passwords do not match!";
    } else {
        $updateQuery = "UPDATE login SET studentPassword='$newPassword', reset_token=NULL, reset_expires=NULL WHERE reset_token='$token'";
        if (mysqli_query($con, $updateQuery)) {
            $_SESSION['message'] = "Password successfully updated.";
            header("Location: login.php");
            exit();
        } else {
            $error_message = "Something went wrong.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Set New Password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="loginCSS.css?v=<?php echo time(); ?>">

    <style>
        .forgot-wrapper {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .forgot-card {
            width: 100%;
            max-width: 420px;
            background: #fff;
            padding: 32px 28px;
            border-radius: 6px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .forgot-title {
            text-align: center;
            font-size: 28px;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        .forgot-desc {
            text-align: center;
            font-size: 15px;
            color: #555;
            margin-bottom: 25px;
        }

        .forgot-form .input-group {
            margin-bottom: 15px;
        }

        .forgot-form input[type="password"], 
        .forgot-form input[type="text"] {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            border: 1.5px solid #000;
            border-radius: 4px;
            box-sizing: border-box;
            outline: none;
        }

        /* --- FIXED SHOW PASSWORD CSS --- */
        .show-pass-container {
            display: flex;
            align-items: center;
            margin-top: 10px;
            cursor: pointer;
            width: fit-content; /* Keeps checkbox and text close */
        }

        .show-pass-container input {
            width: 18px !important;
            height: 18px !important;
            margin: 0 8px 0 0 !important; /* Fixed 8px gap to the right */
            cursor: pointer;
        }

        .show-pass-container label {
            font-size: 14px;
            color: #000;
            cursor: pointer;
            user-select: none;
        }

        .forgot-form button {
            width: 100%;
            margin-top: 20px;
            padding: 14px;
            background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }

        .error-msg {
            color: #d9534f;
            background: #f2dede;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            text-align: center;
            font-size: 14px;
        }
    </style>
</head>
<body>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span>Pateros Technological College</span>
    </div>
</header>

<div class="forgot-wrapper">
    <div class="forgot-card">
        <div class="forgot-title">Create New<br>Password</div>
        <div class="forgot-desc">Please enter and confirm your new password below.</div>

        <?php if (isset($error_message)): ?>
            <div class="error-msg"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form method="POST" class="forgot-form" id="resetForm">
            <div class="input-group">
                <input type="password" name="password" id="pass" placeholder="New Password" required minlength="6">
            </div>

            <div class="input-group">
                <input type="password" name="confirm_password" id="confirm_pass" placeholder="Confirm New Password" required>
            </div>

            <div class="show-pass-container">
                <input type="checkbox" id="toggle">
                <label for="toggle">Show Passwords</label>
            </div>

            <button type="submit">Update Password</button>
        </form>
    </div>
</div>

<script>
    const toggle = document.getElementById('toggle');
    const pass = document.getElementById('pass');
    const confirmPass = document.getElementById('confirm_pass');

    // Function to toggle visibility
    toggle.addEventListener('change', function() {
        const type = this.checked ? 'text' : 'password';
        pass.type = type;
        confirmPass.type = type;
    });

    // Client-side match validation
    document.getElementById('resetForm').onsubmit = function() {
        if (pass.value !== confirmPass.value) {
            alert("Passwords do not match!");
            return false;
        }
        return true;
    };
</script>

</body>
</html>