<?php
session_start();

if (!isset($_SESSION['adminID'])) {
    header("Location: adminLogin.php");
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Users Management</title>
<link rel="stylesheet" href="adminCSS.css">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

<style>
/* ░░░░░░ USERS PAGE IMPROVED DESIGN ░░░░░░ */

/* Sidebar Sub-menu Styling - THEME MATCHED & ALIGNED */
.sub-menu {
    padding-left: 20px; 
    margin-left: 25px;   
    background: transparent; 
    overflow: hidden;
    border-left: 2px solid rgba(3, 140, 42, 0.4); /* Green vertical guide line */
    margin-bottom: 10px;
    display: flex;
    flex-direction: column;
}

.sub-menu a {
    font-size: 14px !important;
    padding: 10px 15px !important;
    display: block;
    text-decoration: none;
    transition: 0.3s;
    border-radius: 8px;
    margin: 2px 0;
    text-align: left; /* Ensures text alignment */
}

.sub-menu a:hover, .sub-menu a.active-sub {
    color: #038c2a;
    font-weight: bold;
    background: #e8f5e9; 
}

/* Status Badge Styling */
.status-badge {
    padding: 4px 8px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
}
.status-active { background: #e8f5e9; color: #038c2a; }
.status-archived { background: #ffebee; color: #c62828; }

/* Top bar */
.users-topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 10px 0 20px 0;
    padding: 0 5px;
}

.users-search {
    width: 260px;
    padding: 10px 14px;
    border: 1px solid #ccc;
    border-radius: 10px;
    background: #fff;
    font-size: 14px;
}

.topbar-actions {
    display: flex;
    gap: 10px;
}

.add-user-btn {
    padding: 10px 18px;
    background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
    border: none;
    border-radius: 10px;
    color: #fff;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    display: flex;
    align-items: center;
    gap: 5px;
}

.upload-csv-btn {
    background: #fff;
    color: #038c2a;
    border: 2px solid #038c2a;
}

.upload-csv-btn:hover {
    background: #f0fdf4;
}

/* Modern Table */
.users-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 5px;
}

.users-table thead th {
    background: #038c2a;
    color: white;
    padding: 12px;
    text-align: left;
    font-size: 14px;
}

.users-table tbody tr {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}

.users-table td {
    padding: 14px;
    font-size: 14px;
    text-align: left;
}

.table-actions {
    display: flex;
    gap: 6px;
}

.action-btn {
    width: 32px;
    height: 32px;
    display: grid;
    place-items: center;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    font-size: 18px;
}

.action-edit { background: #038c2a; color: white; }
.action-delete { background: #c62828; color: white; }
.action-restore { background: #1976d2; color: white; }

/* Modal redesign */
#userModal .modal-content {
    width: 400px !important;
    padding: 25px;
    background: #fff;
    border-radius: 16px;
}

#userModal input,
#userModal select {
    width: 100%;
    padding: 8px 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
}

.save-btn {
    padding: 8px 20px;
    background: #038c2a;
    color: #fff;
    border-radius: 8px;
    border: none;
    font-size: 14px;
    cursor: pointer;
}

.cancel-btn {
    padding: 8px 20px;
    background: #ccc;
    color: #000;
    border-radius: 8px;
    border: none;
    font-size: 14px;
    cursor: pointer;
}
</style>

</head>
<body>

<header>
  <div class="header-left">
    <img src="images/ptclogo.png" alt="PTC">
    <span>Pateros Technological College</span>
  </div>
</header>

<div class="container">
    <aside class="sidebar">
        <nav class="side-menu">
            <a href="admindashboard.php" class="side-btn <?= $current_page == 'admindashboard.php' ? 'active' : '' ?>">
                <span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard
            </a>
            <a href="manage_requests.php" class="side-btn">
                <span class="icon"><i class='bx bx-spreadsheet'></i></span> Manage Requests
            </a>
            <a href="transaction_history.php" class="side-btn">
                <span class="icon"><i class='bx bx-history'></i></span> Transaction History
            </a>
             <a href="transaction.php" class="side-btn">
                <span class="icon"><i class='bx bx-money'></i></span> Transaction Details
            </a>
            <a href="announcement.php" class="side-btn">
                <span class="icon"><i class='bx bxs-megaphone'></i></span> Announcement
            </a>
            <?php if (str_replace(' ', '', $_SESSION['adminRole']) === 'SuperAdmin') : ?>
                <a href="users.php" class="side-btn active"><span class="icon"><i class='bx bxs-user-detail'></i></span> Students</a>
                <div class="sub-menu">
                    <a href="#" onclick="filterView('active')" id="viewActive" class="active-sub">● Active Students</a>
                    <a href="#" onclick="filterView('archived')" id="viewArchived">● Archived Accounts</a>
                </div>
                <a href="manageAdmin.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Manage Users</a>
            <?php endif; ?>
        </nav>
        <div class="logout-container">
            <a href="php/logoutA.php" class="logout"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </div>
    </aside>

    <main style="padding-top:50px;">

    <div class="users-topbar">
        <h3 id="tableTitle" style="color: #038c2a; margin: 0;">Active Students</h3>
        <input type="text" id="searchInput" class="users-search" placeholder="Search student...">
        <div class="topbar-actions">
            <button class="add-user-btn upload-csv-btn" onclick="document.getElementById('csvInput').click()">
                <i class='bx bx-upload'></i> Upload CSV
            </button>
            <input type="file" id="csvInput" accept=".csv" style="display:none;" onchange="handleCSVUpload(this)">
            
            <button id="openAddUser" class="add-user-btn"><i class='bx bx-plus'></i> Add User</button>
        </div>
    </div>

    <table class="users-table">
        <thead>
            <tr>
                <th>Student No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Course</th>
                <th>Year</th>
                <th>Status</th>
                <th style="width: 80px;">Action</th>
            </tr>
        </thead>
        <tbody id="usersTableBody"></tbody>
    </table>

    <div style="margin-top:15px; display:flex; justify-content:center; gap:10px;">
        <button id="prevPage" class="add-user-btn" style="padding:6px 12px;">Prev</button>
        <span id="pageInfo" style="font-weight:bold; font-size:14px; align-self:center;"></span>
        <button id="nextPage" class="add-user-btn" style="padding:6px 12px;">Next</button>
    </div>

</main>

<div class="modal" id="userModal" style="display:none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.4); backdrop-filter: blur(2px);">
    <div class="modal-content" style="margin: 8% auto; background: #fff; width: 400px; padding: 25px; border-radius: 16px; position: relative;">
        <span class="close" onclick="closeUserModal()" style="position:absolute;right:15px;top:10px;font-size:24px;cursor:pointer;">&times;</span>
        <form id="userForm" method="POST" action="users/saveUser.php">
            <input type="hidden" name="action" id="userAction" value="add">
            <input type="hidden" name="originalStudentNo" id="originalStudentNo">
            <label>Student No</label>
            <input type="text" name="studentNo" id="studentNo" required>
            <label>Full Name</label>
            <input type="text" name="studentName" id="studentName" required>
            <label>Email</label>
            <input type="email" name="studentEmail" id="studentEmail" required>
            <label>Course</label>
            <select name="studentCourse" id="studentCourse" required>
                <option value="" disabled selected>Select Course</option>
                <option value="Bachelor of Science Information Technology">Bachelor of Science Information Technology</option>
                <option value="Certificate in Computer Sciences">Certificate in Computer Sciences</option>
                <option value="Bachelor of Science in Office Administration">Bachelor of Science in Office Administration</option>
                <option value="Certificate in Office Administration">Certificate in Office Administration</option>
                <option value="Associate in Accounting Information System">Associate in Accounting Information System</option>
                <option value="Associate in Human Resource Development">Associate in Human Resource Development</option>
                <option value="Associate in Hotel and Restaurant Technology">Associate in Hotel and Restaurant Technology</option>
            </select>
            <label>Year</label>
            <input type="text" name="studentYear" id="studentYear" required>
            <label>Password (leave blank to keep unchanged)</label>
            <input type="password" name="studentPass" id="studentPass">
            <div style="text-align:right; margin-top:10px;">
                <button type="button" class="cancel-btn" onclick="closeUserModal()">Cancel</button>
                <button type="submit" class="save-btn">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
let allUsers = [];
let filteredUsers = [];
let currentPage = 1;
const rowsPerPage = 10;
let currentView = 'active';

function fetchUsers() {
    fetch("users/getUsers.php")
        .then(res => res.json())
        .then(data => {
            allUsers = data.map(u => ({
                ...u,
                status: u.status || 'active'
            }));
            applyFilter();
        })
        .catch(err => console.error("Error fetching users:", err));
}

function handleCSVUpload(input) {
    const file = input.files[0];
    if (!file) return;

    if (confirm(`Upload students from ${file.name}?`)) {
        const formData = new FormData();
        formData.append('csvFile', file);

        fetch("uploadCSV.php", {
            method: "POST",
            body: formData
        })
        .then(res => res.json())
        .then(j => {
            if (j.status === "ok") {
                alert(j.message || "Upload successful!");
                fetchUsers();
            } else {
                alert("Upload failed: " + (j.message || "Unknown error"));
            }
            input.value = ""; 
        })
        .catch(err => {
            console.error(err);
            alert("An error occurred during upload.");
            input.value = "";
        });
    } else {
        input.value = "";
    }
}

function filterView(view) {
    currentView = view;
    document.getElementById('viewActive').classList.toggle('active-sub', view === 'active');
    document.getElementById('viewArchived').classList.toggle('active-sub', view === 'archived');
    document.getElementById('tableTitle').innerText = view === 'active' ? 'Active Students' : 'Archived Accounts';
    applyFilter();
}

function applyFilter() {
    let keyword = document.getElementById("searchInput").value.toLowerCase();
    filteredUsers = allUsers.filter(u => {
        const matchesSearch = 
            u.studentNo.toLowerCase().includes(keyword) || 
            u.studentName.toLowerCase().includes(keyword) ||
            u.studentEmail.toLowerCase().includes(keyword) ||
            u.studentCourse.toLowerCase().includes(keyword);
        const matchesStatus = (currentView === 'active') 
            ? (u.status !== 'archived') 
            : (u.status === 'archived');
        return matchesSearch && matchesStatus;
    });
    currentPage = 1;
    renderTable();
}

function renderTable() {
    const body = document.getElementById("usersTableBody");
    body.innerHTML = "";
    let start = (currentPage - 1) * rowsPerPage;
    let end = start + rowsPerPage;
    let pageUsers = filteredUsers.slice(start, end);

    if (pageUsers.length === 0) {
        body.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 20px;">No records found.</td></tr>`;
    }

    pageUsers.forEach(u => {
        const actionIcon = (currentView === 'active') ? 'bx-archive-in' : 'bx-refresh';
        const actionClass = (currentView === 'active') ? 'action-delete' : 'action-restore';
        const actionTitle = (currentView === 'active') ? 'Archive' : 'Restore';
        const statusClass = (u.status === 'archived') ? 'status-archived' : 'status-active';

        body.innerHTML += `
            <tr>
                <td>${u.studentNo}</td>
                <td>${u.studentName}</td>
                <td>${u.studentEmail}</td>
                <td>${u.studentCourse}</td>
                <td>${u.studentYear}</td>
                <td><span class="status-badge ${statusClass}">${u.status}</span></td>
                <td>
                    <div class="table-actions">
                        <button class="action-btn action-edit" title="Edit" onclick='editUser(${JSON.stringify(JSON.stringify(u))})'>
                            <i class='bx bx-edit'></i>
                        </button>
                        <button class="action-btn ${actionClass}" title="${actionTitle}" onclick='archiveUser("${u.studentNo}", "${currentView}")'>
                            <i class="bx ${actionIcon}"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });

    document.getElementById("pageInfo").innerText = `Page ${currentPage} of ${Math.max(1, Math.ceil(filteredUsers.length / rowsPerPage))}`;
}

function archiveUser(studentNo, view) {
    const actionText = view === 'active' ? "archive" : "restore";
    if (confirm(`Are you sure you want to ${actionText} student ${studentNo}? This will revoke their login access.`)) {
        fetch(`archiveUser.php?studentNo=${encodeURIComponent(studentNo)}&type=${view}`)
            .then(res => res.json())
            .then(j => {
                if (j.status === "ok") {
                    fetchUsers();
                } else {
                    alert("Action failed: " + (j.message || "Unknown error"));
                }
            })
            .catch(err => {
                console.error(err);
                alert("An error occurred. Check the console.");
            });
    }
}

document.getElementById("searchInput").addEventListener("input", applyFilter);
document.getElementById("prevPage").onclick = () => { if (currentPage > 1) { currentPage--; renderTable(); } };
document.getElementById("nextPage").onclick = () => { if (currentPage < Math.ceil(filteredUsers.length / rowsPerPage)) { currentPage++; renderTable(); } };

document.getElementById("openAddUser").addEventListener("click", () => {
    document.getElementById("userForm").reset();
    document.getElementById("userAction").value = "add";
    document.getElementById("studentNo").readOnly = false;
    document.getElementById("userModal").style.display = "block";
});

function closeUserModal() { document.getElementById("userModal").style.display = "none"; }

function editUser(encoded) {
    const u = JSON.parse(encoded);
    document.getElementById("userAction").value = "edit";
    document.getElementById("originalStudentNo").value = u.studentNo;
    document.getElementById("studentNo").value = u.studentNo;
    document.getElementById("studentNo").readOnly = true;
    document.getElementById("studentName").value = u.studentName;
    document.getElementById("studentEmail").value = u.studentEmail;
    document.getElementById("studentCourse").value = u.studentCourse;
    document.getElementById("studentYear").value = u.studentYear;
    document.getElementById("studentPass").value = "";
    document.getElementById("userModal").style.display = "block";
}

window.onclick = (e) => { if (e.target == document.getElementById("userModal")) closeUserModal(); };

fetchUsers();
</script>

</body>
</html>