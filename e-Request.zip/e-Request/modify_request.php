<?php
session_start();
include("php/config.php");

$studentNo = $_SESSION['studentNo'];
$oldName = $_POST['oldName'];       // "Certified True Copy (x5)"
$newQty  = intval($_POST['newQty']); // e.g. 2

// Build the new name
$newName = "Certified True Copy (x$newQty)";

// Update
$query = "
    UPDATE request 
    SET requestDocument = '$newName'
    WHERE studentNo = '$studentNo'
      AND requestDocument = '$oldName'
";

mysqli_query($con, $query);

// Redirect back to request.php step 2
header("Location: request.php");
exit();
?>
