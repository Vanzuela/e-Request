<?php
session_start();
include("php/config.php");

if (!isset($_SESSION['studentNo'])) {
    header("Location: login.php");
    exit();
}

$studentNo = $_SESSION['studentNo'];

// DELETE all *non-Done* requests of this student
$deleteQuery = "DELETE FROM request WHERE studentNo='$studentNo' AND requestStatus != 'Done'";
mysqli_query($con, $deleteQuery);

// Reset step to 1
$_SESSION['currentStep'] = 1;

header("Location: request.php");
exit();
?>
