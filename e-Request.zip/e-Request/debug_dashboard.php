<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include("php/config.php");

echo "<h1>Debugging admindashboard.php</h1>";

echo "<p>1) DB Connected OK</p>";

require __DIR__ . '/phpmailer/vendor/autoload.php';
echo "<p>2) Autoload OK</p>";

// NOW include admindashboard logic SAFELY
echo "<p>3) Including admindashboard.php...</p>";

include("admindashboard.php");

echo "<p>4) Finished including dashboard.</p>";
