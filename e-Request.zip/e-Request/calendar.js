// calendar.js – clean working calendar

document.addEventListener("DOMContentLoaded", () => {

    if (!window.bookedDates) {
        console.log("bookedDates not loaded yet… waiting...");
        setTimeout(() => location.reload(), 300);
        return;
    }

    const calendar = document.getElementById("calendar");
    const monthYear = document.getElementById("monthYear");

    const modal = document.getElementById("modal");
    const modalMsg = document.getElementById("modalMessage");
    const closeModal = document.getElementById("closeModal");

    const selectedDate = document.getElementById("selectedDate");
    const selectedSlot = document.getElementById("selectedTimeSlot");
    const slotSelect = document.getElementById("timeSlotSelect");

    let today = new Date();
    today.setHours(0,0,0,0);

    let curMonth = today.getMonth();
    let curYear = today.getFullYear();

    const MAX = 25;

    // Format YYYY-MM-DD
    function fmt(y,m,d){
        return y + "-" + String(m+1).padStart(2,"0") + "-" + String(d).padStart(2,"0");
    }

    function build(){
        calendar.innerHTML = "";

        const monthName = new Date(curYear, curMonth).toLocaleString("default",{month:"long"});
        monthYear.innerText = `${monthName} ${curYear}`;

        const firstDay = new Date(curYear, curMonth, 1).getDay();
        const daysInMonth = new Date(curYear, curMonth+1, 0).getDate();

        // Fill blanks
        for (let i=0; i<firstDay; i++){
            const blank = document.createElement("div");
            blank.style.visibility = "hidden";
            calendar.appendChild(blank);
        }

        for (let d=1; d<=daysInMonth; d++){
            const dateObj = new Date(curYear, curMonth, d);
            const iso = fmt(curYear, curMonth, d);

            if (dateObj.getDay() === 0 || dateObj.getDay() === 6) continue; // weekend

            if (dateObj < today) continue; // past

            let am = bookedDates[iso]?.AM || 0;
            let pm = bookedDates[iso]?.PM || 0;

            const box = document.createElement("div");
            box.className = "calendar-day";

            box.innerHTML = `
                <div>${d}</div>
                <div style="font-size:12px;">
                    AM: ${am}/${MAX}<br>
                    PM: ${pm}/${MAX}
                </div>
            `;

            // fully booked if BOTH >= 25
            const full = (am >= MAX && pm >= MAX);

            if (full){
                box.classList.add("booked");
            } 
            else {
                box.onclick = () => {
                    selectedDate.value = iso;
                    // choose available slot
                    if (am < MAX && pm < MAX){
                        slotSelect.value = "AM";
                        slotSelect.disabled = false;
                    } else if (am < MAX){
                        slotSelect.value = "AM";
                        slotSelect.disabled = true;
                    } else {
                        slotSelect.value = "PM";
                        slotSelect.disabled = true;
                    }

                    selectedSlot.value = slotSelect.value;
                    slotSelect.onchange = () => selectedSlot.value = slotSelect.value;

                    modalMsg.innerText = "Confirm booking for " + iso;
                    modal.style.display = "block";
                };
            }

            calendar.appendChild(box);
        }
    }

    document.getElementById("prevMonth").onclick = () => {
        curMonth--;
        if (curMonth < 0){ curMonth = 11; curYear--; }
        build();
    };

    document.getElementById("nextMonth").onclick = () => {
        curMonth++;
        if (curMonth > 11){ curMonth = 0; curYear++; }
        build();
    };

    closeModal.onclick = () => modal.style.display = "none";

    build();
});
