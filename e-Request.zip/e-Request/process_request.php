<?php
date_default_timezone_set('Asia/Manila');

header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
header("Pragma: no-cache"); 
session_start();

include("php/config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Capture standard student info
    $studentNo = $_POST['studentNo'];

    // Capture the arrays from the summary table
    $documents  = $_POST['documents'] ?? [];
    $quantities = $_POST['quantities'] ?? [];
    $details    = $_POST['details'] ?? [];
    $prices     = $_POST['prices'] ?? []; 
    $totalAmount = $_POST['totalAmount'] ?? 0;

    // FIX: Generate the Manila Timestamp here
    $manilaTime = date("Y-m-d H:i:s");

    // Basic validation
    if (empty($documents)) {
        $_SESSION['request_error'] = "Please select at least one document before submitting.";
        header("Location: request.php");
        exit();
    }

    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }

    // Loop through each document
    for ($i = 0; $i < count($documents); $i++) {
        
        $docName   = $documents[$i];
        $docQty    = intval($quantities[$i]);
        $docDetail = $details[$i];
        $docPrice  = floatval($prices[$i]) * $docQty; 

        // Format document string
        $finalDocumentString = $docName . " (x" . $docQty . ")";
        
        if ($docDetail !== "Standard Request") {
            $finalDocumentString .= " [" . $docDetail . "]";
        }

        // UPDATED SQL: Added requestDate to the columns and a '?' for the value
        $sql = "INSERT INTO request (studentNo, requestDocument, requestStatus, price, requestDate) 
                VALUES (?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $requestStatus = 'Pending';
        
        // UPDATED BIND: Added 's' for the date string and included $manilaTime
        // 'sssds' -> string, string, string, double, string
        $stmt->bind_param('sssds', $studentNo, $finalDocumentString, $requestStatus, $docPrice, $manilaTime);
        $stmt->execute();
        $stmt->close();
    }

    $conn->close();

    $_SESSION['last_request_total'] = $totalAmount;
    $_SESSION['currentStep'] = 2;
    session_write_close();
    header("Location: request.php");
    exit();
}
?>