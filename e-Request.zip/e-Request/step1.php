<div class="pos-container">
    <div style="margin-bottom: 20px; border-bottom: 2px solid #2e7d32; padding-bottom: 10px;">
        <h2 style="color: #2e7d32; margin: 0; font-size: 1.4rem;">Select Documents to Request</h2>
        <p style="color: #666; font-size: 13px;">Click on a document to add it to your list. You can specify copies in the table.</p>
    </div>

    <div class="request-main-wrapper">
        
        <div class="pos-selection-col">
            
            <h4 style="color: #444; margin: 0 0 12px 5px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Primary Documents</h4>
            <div class="pos-grid" style="margin-bottom: 30px;">
                <div class="pos-card" onclick="addToTable('Certified True Copy (CTC)', 'CTC', 50)">
                    <div class="pos-icon"><i class='bx bx-copy-alt'></i></div>
                    <div class="pos-label">Certified True Copy (CTC)</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱50.00</div>
                </div>
                <div class="pos-card" onclick="openCOGModal()">
                    <div class="pos-icon"><i class='bx bx-list-check'></i></div>
                    <div class="pos-label">Certificate of Grades (COG)</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱50.00</div>
                </div>
                <div class="pos-card" onclick="openTORModal()">
                    <div class="pos-icon"><i class='bx bx-file'></i></div>
                    <div class="pos-label">Transcript of Records (TOR)</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱150.00</div>
                </div>
            </div>

            <h4 style="color: #444; margin: 0 0 12px 5px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Certifications</h4>
            <div class="pos-grid">
                <div class="pos-card" onclick="addToTable('Certificate as Student', 'CERT_STUDENT', 100)">
                    <div class="pos-icon"><i class='bx bx-user-pin'></i></div>
                    <div class="pos-label">Certificate as Student</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱100.00</div>
                </div>
                <div class="pos-card" onclick="addToTable('Certificate of Non-Issuance of Special Order', 'CERT_SO', 100)">
                    <div class="pos-icon"><i class='bx bx-shield-x'></i></div>
                    <div class="pos-label">Non-Issuance of Special Order</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱100.00</div>
                </div>
                <div class="pos-card" onclick="addToTable('Certificate of Graduation', 'CERT_GRAD', 100)">
                    <div class="pos-icon"><i class='bx bxs-graduation'></i></div>
                    <div class="pos-label">Certificate of Graduation</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱100.00</div>
                </div>
                <div class="pos-card" onclick="addToTable('Certificate of Units Earned', 'CERT_UNITS', 100)">
                    <div class="pos-icon"><i class='bx bx-bar-chart-alt-2'></i></div>
                    <div class="pos-label">Certificate of Units Earned</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱100.00</div>
                </div>
                <div class="pos-card" onclick="addToTable('Certificate as Latin Honor', 'CERT_LATIN', 100)">
                    <div class="pos-icon"><i class='bx bxs-award'></i></div>
                    <div class="pos-label">Certificate as Latin Honor</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱100.00</div>
                </div>
                <div class="pos-card" onclick="openOtherPrompt()" style="border-style: dashed; background: #fafafa;">
                    <div class="pos-icon"><i class='bx bx-plus-circle'></i></div>
                    <div class="pos-label">Other Certificate</div>
                    <div style="font-size: 12px; color: #2e7d32; font-weight: bold;">₱100.00</div>
                </div>
            </div>
        </div>

        <div class="summary-table-col">
            <div class="selection-summary-container" id="summaryContainer" style="display:none;">
                <h3 style="margin-bottom:15px; font-size: 16px; color:#2e7d32; display: flex; align-items: center; gap: 10px;">
                    <i class='bx bx-task'></i> Selected List
                </h3>
                <table class="summary-table">
                    <thead>
                        <tr>
                            <th>Document</th>
                            <th style="text-align: center;">Copies</th>
                            <th style="text-align: right;">Price</th>
                            <th style="width: 20px;"></th>
                        </tr>
                    </thead>
                    <tbody id="summaryBody"></tbody>
                </table>

                <div style="margin-top: 20px; padding: 15px; background: #f1f8e9; border-radius: 8px; border: 1px solid #c8e6c9; display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: bold; color: #2e7d32;">Total Amount:</span>
                    <span id="totalDisplay" style="font-size: 1.2rem; font-weight: 800; color: #2e7d32;">₱0.00</span>
                </div>
                
                <form id="documentForm" action="process_request.php" method="POST" onsubmit="return showConfirmModal(event)">
                    <div id="hiddenInputsContainer"></div>
                    <input type="hidden" name="studentNo" value="<?php echo $_SESSION['studentNo']; ?>">
                    <input type="hidden" name="totalAmount" id="totalAmountInput">
                    <button type="submit" class="pos-submit-btn" style="width:100%; margin-top:15px; padding:14px; background:linear-gradient(0deg, #038c2a 0%, #20ba2d 100%); color:white; border:none; border-radius:10px; font-weight:bold; cursor:pointer; font-size: 15px; transition: 0.3s;">
                        Submit Request
                    </button>
                </form>
            </div>
            
            <div id="emptyState" style="text-align:center; padding: 50px 20px; border: 2px dashed #ccc; border-radius:15px; color:#999; background: #fff;">
                <p style="font-size:14px; margin-top:15px;">Your selection is empty.<br>Select from the list to continue.</p>
            </div>
        </div>
    </div>
</div>

<div id="cogModal" class="modal-overlay" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 10001; align-items: center; justify-content: center;">
    <div class="modal-box" style="max-width: 400px; width: 90%; background: white; border-radius: 12px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
        <h3 style="color: #2e7d32; margin-top: 0; border-bottom: 2px solid #eee; padding-bottom: 10px;">COG Details</h3>
        <p style="font-size: 13px; color: #666; margin-bottom: 20px;">Please specify the period for the Certificate of Grades (₱50.00).</p>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; font-size: 12px; font-weight: bold; margin-bottom: 5px;">ACADEMIC YEAR:</label>
            <input type="text" id="cogAY" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px;" placeholder="e.g. 2024-2025">
        </div>

        <div style="margin-bottom: 20px;">
            <label style="display: block; font-size: 12px; font-weight: bold; margin-bottom: 5px;">SEMESTER:</label>
            <select id="cogSem" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px;">
                <option value="">-- Select Semester --</option>
                <option value="1st Semester">1st Semester</option>
                <option value="2nd Semester">2nd Semester</option>
                <option value="Summer">Summer</option>
            </select>
        </div>

        <div style="display: flex; gap: 10px;">
            <button type="button" onclick="submitCOGToTable()" style="flex: 1; background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%); color: white; border: none; padding: 10px; border-radius: 6px; font-weight: bold; cursor: pointer;">Add to List</button>
            <button type="button" onclick="closeCOGModal()" style="flex: 1; background: #eee; border: none; padding: 10px; border-radius: 6px; cursor: pointer;">Cancel</button>
        </div>
    </div>
</div>

<div id="torModal" class="modal-overlay" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 10000; overflow-y: auto; align-items: flex-start; padding: 20px 0;">
    <div class="modal-box" style="max-width: 550px; width: 95%; margin: 50px auto; background: white; border-radius: 12px; padding: 20px; position: relative; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
        <h3 style="color: #2e7d32; border-bottom: 2px solid #eee; padding-bottom: 8px; margin: 0 0 15px 0; text-align: center; font-size: 1.1rem;">REQUEST FORM (TOR - ₱150.00)</h3>
        <form id="torDataForm">
            <div style="margin-bottom: 10px;">
                <label class="modal-label" style="font-weight: bold; font-size: 12px; color: #2e7d32;">PURPOSE:</label>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px; font-size: 12px; margin-top: 3px;">
                    <label><input type="radio" name="purpose" value="Employment" required> Employment</label>
                    <label><input type="radio" name="purpose" value="Evaluation"> Evaluation</label>
                    <label><input type="radio" name="purpose" value="Scholarship"> Scholarship</label>
                    <label><input type="radio" name="purpose" value="Others" id="purposeOthers"> Others, Specify:</label>
                </div>
                <input type="text" id="torPurposeOthers" class="modal-select" style="margin-top: 5px; padding: 6px; font-size: 12px;" placeholder="Specify purpose...">
            </div>
            <div style="margin-bottom: 10px;">
                <label class="modal-label" style="font-size: 12px;">ADDRESS:</label>
                <input type="text" id="torAddress" class="modal-select" style="padding: 6px; font-size: 12px;" placeholder="Current Address" required>
            </div>
            <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                <div style="flex: 1;">
                    <label class="modal-label" style="font-size: 12px;">CONTACT NUMBER:</label>
                    <input type="text" id="torContact" class="modal-select" style="padding: 6px; font-size: 12px;" required>
                </div>
                <div style="flex: 1;">
                    <label class="modal-label" style="font-size: 12px;">DATE OF BIRTH:</label>
                    <input type="date" id="torDOB" class="modal-select" style="padding: 6px; font-size: 12px;" required>
                </div>
            </div>
            <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                <div style="flex: 1;">
                    <label class="modal-label" style="font-size: 12px;">PLACE OF BIRTH:</label>
                    <input type="text" id="torPOB" class="modal-select" style="padding: 6px; font-size: 12px;" required>
                </div>
                <div style="flex: 1;">
                    <label class="modal-label" style="font-size: 12px;">YEAR GRADUATED:</label>
                    <input type="text" id="torYearGrad" class="modal-select" style="padding: 6px; font-size: 12px;" placeholder="If applicable">
                </div>
            </div>
            <div style="margin-bottom: 10px;">
                <label class="modal-label" style="font-size: 12px;">SH/JH SCHOOL:</label>
                <input type="text" id="torHighSchool" class="modal-select" style="padding: 6px; font-size: 12px;" required>
            </div>
            <div style="margin-bottom: 10px;">
                <label class="modal-label" style="font-size: 12px;">PREVIOUS SCHOOL (IF TRANSFEREE):</label>
                <input type="text" id="torPrevSchool" class="modal-select" style="padding: 6px; font-size: 12px;" placeholder="N/A if not transferee">
            </div>
            <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                <div style="flex: 1;">
                    <label class="modal-label" style="font-size: 12px;">DATE OF ADMISSION:</label>
                    <input type="date" id="torAdmissionDate" class="modal-select" style="padding: 6px; font-size: 12px;" required>
                </div>
                <div style="flex: 1;">
                    <label class="modal-label" style="font-size: 12px;">LAST YEAR ATTENDED:</label>
                    <input type="text" id="torLastYear" class="modal-select" style="padding: 6px; font-size: 12px;" placeholder="e.g. 2023-2024" required>
                </div>
            </div>
            <div style="margin-bottom: 12px;">
                <label class="modal-label" style="font-size: 12px;">STATUS:</label>
                <div style="display: flex; gap: 15px; font-size: 12px; margin-top: 2px;">
                    <label><input type="radio" name="status" value="Graduate" required> Graduate</label>
                    <label><input type="radio" name="status" value="Not Graduate"> Not Graduate</label>
                </div>
            </div>
            <div style="background: #fff8ef; padding: 10px; border-radius: 6px; border-left: 3px solid #ffa117; font-size: 11px; color: #663c00; margin-bottom: 15px;">
                <strong>REQUIREMENTS:</strong> 2pcs 2x2 picture (White background, Formal) & ID.
            </div>
            <div class="modal-actions" style="display: flex; gap: 8px;">
                <button type="button" class="modal-save-btn" onclick="submitTORToTable()" style="flex: 1; background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%); color: white; border: none; padding: 8px; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 13px;">Confirm & Add</button>
                <button type="button" class="modal-cancel-btn" onclick="closeTORModal()" style="flex: 1; background: #f5f5f5; border: 1px solid #ddd; padding: 8px; border-radius: 6px; cursor: pointer; font-size: 13px;">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="confirmSubmitModal" class="modal-overlay" style="display:none;">
    <div class="modal-box" style="max-width: 400px; width: 90%;">
        <div style="text-align: center; margin-bottom: 20px;">
             <i class='bx bx-help-circle' style="font-size: 50px; color: #2e7d32;"></i>
             <h3 style="margin: 10px 0 5px 0;">Is this request final?</h3>
             <p style="font-size: 13px; color: #666;">You cannot modify this once submitted.</p>
        </div>
        <ul id="finalConfirmList" style="list-style:none; padding: 10px 15px; margin: 0 0 20px 0; background: #f9f9f9; border-radius: 10px; border: 1px solid #eee;"></ul>
        <div style="text-align: right; margin-bottom: 15px; font-weight: bold; color: #2e7d32; font-size: 16px;">
            Total Payable: <span id="finalTotalDisplay">₱0.00</span>
        </div>
        <div class="modal-actions" style="display: flex; gap: 10px;">
            <button type="button" class="modal-save-btn" onclick="submitFinalForm()" 
                style="flex: 1; background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%); color: white; border: none; padding: 10px; border-radius: 20px; font-weight: 600; cursor: pointer;">
                Yes, Submit
            </button>
            <button type="button" class="modal-cancel-btn" onclick="closeConfirmModal()" style="flex: 1;">Review Again</button>
        </div>
    </div>
</div>

<script>
let selectedDocs = [];

// COG MODAL FUNCTIONS
function openCOGModal() {
    if (selectedDocs.find(d => d.code === 'COG')) {
        alert("Certificate of Grades is already in your selected list.");
        return;
    }
    document.getElementById('cogModal').style.display = 'flex';
}

function closeCOGModal() {
    document.getElementById('cogModal').style.display = 'none';
    document.getElementById('cogAY').value = "";
    document.getElementById('cogSem').value = "";
}

function submitCOGToTable() {
    const ay = document.getElementById('cogAY').value;
    const sem = document.getElementById('cogSem').value;

    if (!ay || !sem) {
        alert("Please provide both Academic Year and Semester.");
        return;
    }

    const details = "AY: " + ay + " | " + sem;
    selectedDocs.push({ 
        name: 'Certificate of Grades (COG)', 
        code: 'COG', 
        qty: 1, 
        price: 50,
        details: details 
    });
    
    renderTable();
    closeCOGModal();
}

// TOR MODAL FUNCTIONS
function openTORModal() {
    if (selectedDocs.find(d => d.code === 'TOR')) {
        alert("TOR is already in your selected list.");
        return;
    }
    document.getElementById('torModal').style.display = 'flex';
}

function closeTORModal() {
    document.getElementById('torModal').style.display = 'none';
    document.getElementById('torDataForm').reset();
}

function submitTORToTable() {
    const form = document.getElementById('torDataForm');
    let purpose = document.querySelector('input[name="purpose"]:checked')?.value;
    if(purpose === 'Others') {
        const othersVal = document.getElementById('torPurposeOthers').value;
        purpose = othersVal ? "Others: " + othersVal : "Others";
    }

    const status = document.querySelector('input[name="status"]:checked')?.value;
    const address = document.getElementById('torAddress').value;
    const contact = document.getElementById('torContact').value;
    const lastYear = document.getElementById('torLastYear').value;

    if (!purpose || !status || !address || !contact || !lastYear) {
        alert("Please fill in all required fields marked in the form.");
        return;
    }
    
    const details = `Purpose: ${purpose} | Address: ${address} | Contact: ${contact} | Last Year: ${lastYear} | Status: ${status}`;
    
    selectedDocs.push({ 
        name: 'Transcript of Records (TOR)', 
        code: 'TOR', 
        qty: 1, 
        price: 150,
        details: details 
    });
    
    renderTable();
    closeTORModal();
}

// CORE FUNCTIONS
function addToTable(name, code, price) {
    if (selectedDocs.find(d => d.code === code)) {
        alert("This document is already in your selected list.");
        return;
    }
    selectedDocs.push({ name: name, code: code, qty: 1, price: price, details: "Standard Request" });
    renderTable();
}

function openOtherPrompt() {
    let spec = prompt("Please specify the document you need:");
    if (spec) {
        let uniqueCode = 'OTHER_' + Date.now();
        selectedDocs.push({ name: spec, code: uniqueCode, qty: 1, price: 100, details: "Special Request" });
        renderTable();
    }
}

function updateQty(index, delta) {
    let newQty = selectedDocs[index].qty + delta;
    if (newQty >= 1 && newQty <= 10) {
        selectedDocs[index].qty = newQty;
        renderTable();
    }
}

function removeItem(index) {
    selectedDocs.splice(index, 1);
    renderTable();
}

function renderTable() {
    const body = document.getElementById('summaryBody');
    const container = document.getElementById('summaryContainer');
    const emptyState = document.getElementById('emptyState');
    const hiddenContainer = document.getElementById('hiddenInputsContainer');
    const totalDisplay = document.getElementById('totalDisplay');
    const totalInput = document.getElementById('totalAmountInput');
    
    body.innerHTML = "";
    hiddenContainer.innerHTML = "";

    if (selectedDocs.length === 0) {
        container.style.display = "none";
        emptyState.style.display = "block";
        return;
    }

    container.style.display = "block";
    emptyState.style.display = "none";

    let totalAmount = 0;

    selectedDocs.forEach((doc, index) => {
        let lineTotal = doc.price * doc.qty;
        totalAmount += lineTotal;

        body.innerHTML += `
            <tr>
                <td style="padding-right: 10px;">
                    <div style="font-weight:600; font-size:12.5px; color:#333;">${doc.name}</div>
                    <div style="font-size:11px; color:#888;">${doc.details}</div>
                </td>
                <td>
                    <div style="display:flex; align-items:center; justify-content:center; gap:8px;">
                        <button type="button" style="width:24px; height:24px; border:1px solid #ccc; background:#fff; cursor:pointer; border-radius:50%; display:flex; align-items:center; justify-content:center;" onclick="updateQty(${index}, -1)"><i class='bx bx-minus' style='font-size:12px;'></i></button>
                        <span style="font-weight:700; font-size:13px; min-width:15px; text-align:center;">${doc.qty}</span>
                        <button type="button" style="width:24px; height:24px; border:1px solid #ccc; background:#fff; cursor:pointer; border-radius:50%; display:flex; align-items:center; justify-content:center;" onclick="updateQty(${index}, 1)"><i class='bx bx-plus' style='font-size:12px;'></i></button>
                    </div>
                </td>
                <td style="text-align:right; font-weight:600; color:#2e7d32;">
                    ₱${lineTotal.toFixed(2)}
                </td>
                <td style="text-align:right;">
                    <i class='bx bx-x' style="color:#ff4d4d; cursor:pointer; font-size:20px;" onclick="removeItem(${index})"></i>
                </td>
            </tr>
        `;
        hiddenContainer.innerHTML += `
            <input type="hidden" name="documents[]" value="${doc.name}">
            <input type="hidden" name="quantities[]" value="${doc.qty}">
            <input type="hidden" name="prices[]" value="${doc.price}">
            <input type="hidden" name="details[]" value="${doc.details}">
        `;
    });

    totalDisplay.innerText = "₱" + totalAmount.toFixed(2);
    totalInput.value = totalAmount;
}

function showConfirmModal(e) {
    e.preventDefault();
    const list = document.getElementById('finalConfirmList');
    const finalTotal = document.getElementById('finalTotalDisplay');
    list.innerHTML = "";
    let total = 0;

    selectedDocs.forEach(doc => {
        let subtotal = doc.price * doc.qty;
        total += subtotal;
        list.innerHTML += `<li style="padding:8px 0; font-size:13px; border-bottom:1px solid #eee; display:flex; justify-content:space-between;">
            <span>${doc.name} (₱${doc.price} x ${doc.qty})</span>
            <strong style="color:#2e7d32;">₱${subtotal.toFixed(2)}</strong>
        </li>`;
    });

    finalTotal.innerText = "₱" + total.toFixed(2);
    document.getElementById('confirmSubmitModal').style.display = 'flex';
}

function closeConfirmModal() { document.getElementById('confirmSubmitModal').style.display = 'none'; }
function submitFinalForm() { document.getElementById('documentForm').submit(); }
</script>