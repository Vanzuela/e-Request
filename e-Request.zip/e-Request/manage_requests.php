<?php
date_default_timezone_set('Asia/Manila');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
include("php/config.php");

// FIX: Set the Database connection to Philippines Time
mysqli_query($con, "SET time_zone = '+08:00'");

// Validate session
if (!isset($_SESSION['adminID'])) {
    header("Location: adminLogin.php");
    exit();
}

// Handle admin logout
if (isset($_GET['logout']) && $_GET['logout'] === 'admin') {
    session_destroy();
    header("Location: adminLogin.php");
    exit();
}

// Get filter and tab status
$filterYear = $_GET['year'] ?? '';
$filterCourse = $_GET['course'] ?? '';
$currentTab = $_GET['tab'] ?? 'pending'; 
$yearCondition = "";
$courseCondition = "";

if (!empty($filterYear)) {
    $filterYear = mysqli_real_escape_string($con, $filterYear);
    $yearCondition = " AND TRIM(l.studentYear) LIKE '%$filterYear%'"; 
}

if (!empty($filterCourse)) {
    $filterCourse = mysqli_real_escape_string($con, $filterCourse);
    $courseCondition = " AND l.studentCourse LIKE '%$filterCourse%'"; 
}

// Logic for Different Tables based on Sub-menu/Tabs
if ($currentTab == 'pending') {
    $statusFilter = "'Pending'";
} elseif ($currentTab == 'processing') {
    $statusFilter = "'Processing'";
} else {
    $statusFilter = "'Ready to Pickup'";
}

// COUNTER FOR NOTIFICATION BELL
$notifQuery = mysqli_query($con, "SELECT COUNT(*) as total FROM request WHERE requestStatus = 'Pending'");
$notifData = mysqli_fetch_assoc($notifQuery);
$newRequestCount = $notifData['total'] ?? 0;

// Fetch Students (The initial load)
$requestQuery = "
    SELECT 
        r.studentNo,
        l.studentName,
        l.studentCourse,
        l.studentYear,
        COUNT(r.requestID) AS requestCount,
        MAX(r.requestDate) AS latestTimestamp
    FROM request r
    JOIN login l ON r.studentNo = l.studentNo
    WHERE r.requestStatus = $statusFilter $yearCondition $courseCondition
    GROUP BY r.studentNo, l.studentName, l.studentCourse, l.studentYear
    ORDER BY latestTimestamp ASC
";
$requestResult = mysqli_query($con, $requestQuery);

// Booking Query
$bookingQuery = "
    SELECT 
        b.bookingID,
        b.bookingDate,
        l.studentName,
        l.studentCourse,
        l.studentYear,
        COUNT(rb.requestID) AS docCount
    FROM booking b
    INNER JOIN login l ON b.studentNo = l.studentNo
    LEFT JOIN request_booking rb ON rb.bookingID = b.bookingID
    LEFT JOIN request r ON rb.requestID = r.requestID
    WHERE (r.requestStatus != 'Done' OR r.requestStatus IS NULL) 
    $yearCondition $courseCondition
    GROUP BY b.bookingID
    HAVING docCount > 0
    ORDER BY b.bookingID DESC
";
$bookingResult = mysqli_query($con, $bookingQuery);

require __DIR__ . '/phpmailer/vendor/autoload.php';
$adminName = $_SESSION['adminName'] ?? 'Unknown Admin'; 

// Form Actions
if (isset($_POST['markProcessing'])) {
    $requestID = mysqli_real_escape_string($con, $_POST['requestID']);
    mysqli_query($con, "UPDATE request SET requestStatus = 'Processing' WHERE requestID = '$requestID'");
    header("Location: manage_requests.php?tab=processing&" . http_build_query($_GET));
    exit();
}

if (isset($_POST['markReady'])) {
    $requestID = mysqli_real_escape_string($con, $_POST['requestID']);
    // Note: NOW() will now use the +08:00 timezone set above
    $updateStatusQuery = "UPDATE request SET requestStatus = 'Ready to Pickup', approvedBy = '$adminName', readyTime = NOW() WHERE requestID = '$requestID'";
    mysqli_query($con, $updateStatusQuery);
    header("Location: manage_requests.php?tab=ready&" . http_build_query($_GET));
    exit();
}

if (isset($_POST['markDone'])) {
    $requestID = mysqli_real_escape_string($con, $_POST['requestID']);
    mysqli_query($con, "UPDATE request SET requestStatus = 'Done', readyTime = NOW() WHERE requestID = '$requestID'");
    header("Location: manage_requests.php?tab=ready&" . http_build_query($_GET));
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Requests - Admin</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="adminCSS.css">
    <style>
        .container { margin-top: 80px; display: flex; }
        main { padding: 15px !important; flex: 1; display: flex; flex-direction: column; padding-top:50px !important; }
        .sub-menu { padding-left: 20px; margin-left: 25px; background: transparent; overflow: hidden; border-left: 2px solid rgba(3, 140, 42, 0.4); margin-bottom: 10px; display: flex; flex-direction: column; }
        .sub-menu a { font-size: 14px !important; padding: 10px 15px !important; display: block; text-decoration: none; transition: 0.3s; border-radius: 8px; margin: 2px 0; text-align: left; }
        .sub-menu a:hover, .sub-menu a.active-sub { color: #038c2a; font-weight: bold; background: #e8f5e9; }
        .requests-bookings-container { display: flex; flex-direction: column; gap: 20px; }
        .section-box { background: white; padding: 15px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); height: 450px; display: flex; flex-direction: column; }
        .section-title { font-size: 16px; font-weight: 600; margin-bottom: 12px; color: #038c2a; display: flex; align-items: center; gap: 8px; border-left: 4px solid #038c2a; padding-left: 10px; flex-shrink: 0; text-transform: capitalize; }
        .table-wrapper { flex-grow: 1; overflow-y: auto; border: 1px solid #eee; border-radius: 5px; background-color: #fff; }
        .styled-table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
        .styled-table thead { position: sticky; top: 0; z-index: 10; }
        .styled-table thead tr { background: #038c2a; color: #ffffff; }
        .styled-table th, .styled-table td { padding: 10px 12px; border: 1px solid #eee; }
        .ready-btn { padding: 5px 12px; font-size: 12px; border-radius: 4px; background-color: #038c2a; color: white; border: none; cursor: pointer; }
        .process-btn { padding: 5px 12px; font-size: 12px; border-radius: 4px; background-color: #f39c12; color: white; border: none; cursor: pointer; }
        .filter-section { background: #fff; padding: 12px; border-radius: 8px; margin-bottom: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; align-items: center; gap: 15px; }
        .modal { display:none; position:fixed; z-index:1000; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.5); backdrop-filter: blur(2px); }
        .modal-content { background:#fff; margin:5% auto; padding:20px; width:60%; border-radius:16px; position:relative; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .close { float:right; cursor:pointer; font-size:24px; font-weight:bold; }

        /* Notification Styling */
        .header-right { display: flex; align-items: center; margin-left: auto; }
        .notification-link { text-decoration: none; position: relative; display: flex; align-items: center; justify-content: center; width: 42px; height: 42px; background-color: #f0f7f7; border-radius: 12px; transition: all 0.3s ease; }
        .notification-link i { font-size: 24px; color: #038c2a; }
        #notificationCount { position: absolute; top: -5px; right: -5px; background: #ff4757; color: white; font-size: 11px; font-weight: bold; min-width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid #fff; }
        @keyframes pulse-red { 0% { transform: scale(1); } 50% { transform: scale(1.2); } 100% { transform: scale(1); } }
        .has-notif #notificationCount { animation: pulse-red 2s infinite; }
    </style>
</head>
<body>
<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span>Pateros Technological College</span>
    </div>
    <div class="header-right">
        <a id="notifBell" href="manage_requests.php?tab=pending" class="notification-link <?= $newRequestCount > 0 ? 'has-notif' : '' ?>">
            <i class='bx bx-bell'></i>
            <?php if ($newRequestCount > 0): ?>
                <span id="notificationCount"><?= $newRequestCount ?></span>
            <?php endif; ?>
        </a>
    </div>
</header>

<div class="container">
    <aside class="sidebar">
        <nav class="side-menu">
            <a href="admindashboard.php" class="side-btn">
                <span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard
            </a>
            <a href="manage_requests.php" class="side-btn active">
                <span class="icon"><i class='bx bx-spreadsheet'></i></span> Manage Requests
            </a>
            <div class="sub-menu">
                <a href="manage_requests.php?tab=pending" class="<?= $currentTab == 'pending' ? 'active-sub' : '' ?>">● Pending Requests</a>
                <a href="manage_requests.php?tab=processing" class="<?= $currentTab == 'processing' ? 'active-sub' : '' ?>">● Processing</a>
                <a href="manage_requests.php?tab=ready" class="<?= $currentTab == 'ready' ? 'active-sub' : '' ?>">● Ready to Pickup</a>
            </div>
            <a href="transaction_history.php" class="side-btn">
                <span class="icon"><i class='bx bx-history'></i></span> Transaction History
            </a>
            <a href="transaction.php" class="side-btn">
                <span class="icon"><i class='bx bx-money'></i></span> Transaction Details
            </a>
            <a href="announcement.php" class="side-btn">
                <span class="icon"><i class='bx bxs-megaphone'></i></span> Announcement
            </a>
            <?php if (isset($_SESSION['adminRole']) && str_replace(' ', '', $_SESSION['adminRole']) === 'SuperAdmin') : ?>
                <a href="users.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Students</a>
                <a href="manageAdmin.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Manage Users</a>
            <?php endif; ?>
        </nav>
        <div class="logout-container">
            <a href="php/logoutA.php" class="logout"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </div>
    </aside>

    <main>
        <div class="filter-section">
            <form method="get" id="filterForm" style="display:flex; align-items:center; gap:15px; flex-wrap: wrap;">
                <input type="hidden" name="tab" value="<?= htmlspecialchars($currentTab) ?>">
                <div>
                    <label style="font-weight:600; font-size:13px; color:#555;">Year Level:</label>
                    <select name="year" onchange="this.form.submit()">
                        <option value="">All Years</option>
                        <option value="1" <?= $filterYear == '1' ? 'selected' : '' ?>>1st Year</option>
                        <option value="2" <?= $filterYear == '2' ? 'selected' : '' ?>>2nd Year</option>
                        <option value="3" <?= $filterYear == '3' ? 'selected' : '' ?>>3rd Year</option>
                        <option value="4" <?= $filterYear == '4' ? 'selected' : '' ?>>4th Year</option>
                    </select>
                </div>
                <div>
                    <label style="font-weight:600; font-size:13px; color:#555;">Course:</label>
                    <select name="course" onchange="this.form.submit()">
                        <option value="">All Courses</option>
                        <option value="Bachelor of Science Information Technology" <?= $filterCourse == 'Bachelor of Science Information Technology' ? 'selected' : '' ?>>BSIT</option>
                        <option value="Certificate in Computer Sciences" <?= $filterCourse == 'Certificate in Computer Sciences' ? 'selected' : '' ?>>CCS</option>
                        <option value="Bachelor of Science in Office Administration" <?= $filterCourse == 'Bachelor of Science in Office Administration' ? 'selected' : '' ?>>BSOA</option>
                        </select>
                </div>
                <?php if(!empty($filterYear) || !empty($filterCourse)): ?>
                    <a href="manage_requests.php?tab=<?= $currentTab ?>" style="font-size:11px; color:#f44336; text-decoration:none; font-weight:bold;">[ Clear Filters ]</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="requests-bookings-container">
            <div class="section-box">
                <div class="section-title">
                    <i class='bx bx-list-ul'></i> <?= ucfirst($currentTab) ?> Requests
                </div>
                <div class="table-wrapper" id="live-request-table">
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th style="width: 55%;">Student Details</th>
                                <th style="width: 30%;">Activity Date</th>
                                <th style="width: 15%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        if (mysqli_num_rows($requestResult) > 0) {
                            while ($studentRow = mysqli_fetch_assoc($requestResult)) {
                                $formattedDate = date("M j, Y • g:i A", strtotime($studentRow['latestTimestamp']));
                                echo "<tr>
                                    <td>
                                        <div style='font-size: 14px;'><strong>" . htmlspecialchars($studentRow['studentName']) . "</strong></div>
                                        <div style='font-size: 11px; color: #777;'>" . htmlspecialchars($studentRow['studentCourse']) . " | Year " . htmlspecialchars($studentRow['studentYear']) . "</div>
                                    </td>
                                    <td style='text-align:center; font-size:12px;'>$formattedDate</td>
                                    <td style='text-align:center;'>
                                        <button onclick=\"openRequestModal('" . htmlspecialchars($studentRow['studentNo']) . "')\" class='ready-btn'>View</button>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' style='text-align:center; padding:50px; color:#999;'>No " . $currentTab . " requests found.</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if ($currentTab == 'ready'): ?>
            <div class="section-box">
                <div class="section-title"><i class='bx bx-calendar'></i> Scheduled Pickups</div>
                <div class="table-wrapper" id="live-booking-table">
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th style="width: 55%;">Student Details</th>
                                <th style="width: 30%;">Scheduled Date</th>
                                <th style="width: 15%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        if (mysqli_num_rows($bookingResult) > 0) {
                            while ($row = mysqli_fetch_assoc($bookingResult)) {
                                $bDate = date("M j, Y • g:i A", strtotime($row['bookingDate']));
                                echo "<tr>
                                    <td>
                                        <div style='font-size: 14px;'><strong>" . htmlspecialchars($row['studentName']) . "</strong></div>
                                        <div style='font-size: 11px; color: #777;'>" . htmlspecialchars($row['studentCourse']) . " • Yr " . htmlspecialchars($row['studentYear']) . "</div>
                                    </td>
                                    <td style='text-align:center; font-size:12px;'>$bDate</td>
                                    <td style='text-align:center;'>
                                        <button onclick=\"openBookingModal('" . htmlspecialchars($row['bookingID']) . "')\" class='ready-btn' style='background:#bfa181;'>Review</button>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' style='text-align:center; padding:20px; color:#999;'>No pickup schedules found.</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<div id="requestModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('requestModal')">&times;</span>
        <h3 id="modalStudentName" style="color:#038c2a;">Student Requests</h3>
        <div class="table-wrapper">
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Document</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="modalTableBody"></tbody>
            </table>
        </div>
    </div>
</div>

<div id="bookingModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('bookingModal')">&times;</span>
        <h3 style="color:#038c2a;">Pickup Review</h3>
        <div class="table-wrapper">
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Document</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="bookingModalBody"></tbody>
            </table>
        </div>
    </div>
</div>

<script>
// AUTO REFRESH LOGIC
function fetchLiveUpdates() {
    // Refresh Request Table and Notification count
    const params = new URLSearchParams(window.location.search);
    const tab = params.get('tab') || 'pending';
    const year = params.get('year') || '';
    const course = params.get('course') || '';

    // We fetch a special partial file to get fresh table HTML
    fetch(`refresh_requests_table.php?tab=${tab}&year=${year}&course=${course}`)
        .then(res => res.json())
        .then(data => {
            // Update the tables
            document.getElementById('live-request-table').innerHTML = data.requestTable;
            if(document.getElementById('live-booking-table')) {
                document.getElementById('live-booking-table').innerHTML = data.bookingTable;
            }

            // Update Notification Bell
            const bell = document.getElementById('notifBell');
            let badge = document.getElementById('notificationCount');
            if (data.pendingCount > 0) {
                bell.classList.add('has-notif');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.id = 'notificationCount';
                    bell.appendChild(badge);
                }
                badge.innerText = data.pendingCount;
            } else {
                bell.classList.remove('has-notif');
                if (badge) badge.remove();
            }
        });
}

// Start polling every 5 seconds
setInterval(fetchLiveUpdates, 5000);

// Modal functions
function openRequestModal(studentNo) {
    const modalBody = document.getElementById("modalTableBody");
    modalBody.innerHTML = "<tr><td colspan='3' style='text-align:center;'>Loading...</td></tr>";
    
    fetch("getStudentRequests.php?studentNo=" + studentNo)
        .then(response => response.json())
        .then(data => {
            modalBody.innerHTML = "";
            if (data.length === 0) {
                modalBody.innerHTML = "<tr><td colspan='3' style='text-align:center;'>No active requests.</td></tr>";
            } else {
                data.forEach(req => {
                    let actionBtn = "";
                    if(req.requestStatus === 'Pending') {
                        actionBtn = `<form method="POST"><input type="hidden" name="requestID" value="${req.requestID}"><button name="markProcessing" class="process-btn">Process</button></form>`;
                    } else if(req.requestStatus === 'Processing') {
                        actionBtn = `<form method="POST"><input type="hidden" name="requestID" value="${req.requestID}"><button name="markReady" class="ready-btn">Ready</button></form>`;
                    } else if(req.requestStatus === 'Ready to Pickup') {
                        actionBtn = `<form method="POST"><input type="hidden" name="requestID" value="${req.requestID}"><button name="markDone" class="ready-btn" style="background:#28a745;">Complete</button></form>`;
                    }

                    modalBody.innerHTML += `
                        <tr>
                            <td>${req.requestDocument}</td>
                            <td>${req.requestStatus}</td>
                            <td>${actionBtn}</td>
                        </tr>`;
                });
            }
            document.getElementById("requestModal").style.display = "block";
        });
}

function openBookingModal(bookingID) {
    const modalBody = document.getElementById("bookingModalBody");
    modalBody.innerHTML = "<tr><td colspan='2' style='text-align:center;'>Loading...</td></tr>";
    
    fetch("getBookingDetails.php?bookingID=" + bookingID)
        .then(response => response.json())
        .then(data => {
            modalBody.innerHTML = "";
            data.documents.forEach(doc => {
                modalBody.innerHTML += `
                    <tr>
                        <td>${doc.requestDocument}</td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="requestID" value="${doc.requestID}">
                                <button name="markDone" class="ready-btn" style="background:#28a745;">Complete</button>
                            </form>
                        </td>
                    </tr>`;
            });
            document.getElementById("bookingModal").style.display = "block";
        });
}

function closeModal(id) {
    document.getElementById(id).style.display = "none";
}

window.onclick = function(event) {
    if (event.target.className === 'modal') {
        event.target.style.display = "none";
    }
}
</script>
</body>
</html>