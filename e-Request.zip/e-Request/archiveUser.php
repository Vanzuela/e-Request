<?php
include("php/config.php"); // Path updated to reflect same-folder location as users.php
session_start();

// 1. Security Check: Only allow logged-in admins to perform this action
if (!isset($_SESSION['adminID'])) {
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit();
}

// 2. Capture parameters from the fetch request
// studentNo: The unique ID of the student
// type: The current view ('active' or 'archived')
$studentNo = isset($_GET['studentNo']) ? mysqli_real_escape_string($con, $_GET['studentNo']) : '';
$type = isset($_GET['type']) ? $_GET['type'] : ''; 

if (empty($studentNo)) {
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Missing Student Number']);
    exit();
}

// 3. Logic: Determine the target status
// If they are currently active, we archive them.
// If they are already archived, we restore them to active.
$newStatus = ($type === 'active') ? 'archived' : 'active';

// 4. Update the Database
// This query changes the status instead of deleting the record
$query = "UPDATE login SET status = '$newStatus' WHERE studentNo = '$studentNo'";

header('Content-Type: application/json');

if (mysqli_query($con, $query)) {
    // Return success to the JavaScript so the table refreshes automatically
    echo json_encode([
        'status' => 'ok', 
        'message' => 'Student status updated successfully',
        'newStatus' => $newStatus
    ]);
} else {
    // Return error message if the SQL fails
    echo json_encode([
        'status' => 'error', 
        'message' => 'Database error: ' . mysqli_error($con)
    ]);
}
?>