<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['studentID'])) {
    header("Location: login.php");
    exit();
}

include("php/config.php");

// ------------------ REQUEST STATUS LOGIC ------------------ //
$studentNo = $_SESSION['studentNo'];

$requestQuery = "
    SELECT requestStatus 
    FROM request 
    WHERE studentNo = '$studentNo'
";
$requestResult = mysqli_query($con, $requestQuery);

// Default trackers
$hasPending = false;
$hasProcessing = false;
$hasReady = false;
$hasBooked = false;
$allDone = true;

while ($row = mysqli_fetch_assoc($requestResult)) {

    $status = $row['requestStatus'];

    if ($status !== 'Done') {
        $allDone = false;
    }

    if ($status === 'Pending') $hasPending = true;
    if ($status === 'Processing') $hasProcessing = true;
    if ($status === 'Ready to Pickup') $hasReady = true;
    if ($status === 'Booked') $hasBooked = true;
}

// STEP DECISION LOGIC
if ($allDone) $_SESSION['currentStep'] = 1;
else if ($hasPending || $hasProcessing) $_SESSION['currentStep'] = 2;
else if ($hasReady) $_SESSION['currentStep'] = 3;
else if ($hasBooked) $_SESSION['currentStep'] = 4;
else $_SESSION['currentStep'] = 1;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>e-Request System</title>

<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="stylesheet" href="requestCSS.css?v=<?php echo time(); ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/main.min.css">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>

</head>
<body>
<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span class="school-name">Pateros Technological College</span>
    </div>
    <button id="mobileMenuBtn" class="mobile-menu-btn" aria-label="Open menu">
        <i class='bx bx-menu'></i>
    </button>
</header>

<?php if (isset($_SESSION['request_error'])): ?>
    <div style="background:#ffdddd; color:#a30000; padding:12px 16px; border-left:5px solid #d10000; border-radius:6px; margin-bottom:15px; font-size:15px;">
        <?= $_SESSION['request_error']; ?>
    </div>
    <?php unset($_SESSION['request_error']); ?>
<?php endif; ?>

<div class="container">
    <aside class="sidebar" id="sidebar">
        <div class="profile">
            <div class="name"><?php echo htmlspecialchars($_SESSION['studentName'] ?? 'Student', ENT_QUOTES, 'UTF-8'); ?></div>
            <div class="role">Student</div>
        </div>

       <nav class="side-menu" aria-label="Sidebar Navigation">
                <a href="dashboard.php"><span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard </a>
                <a href="history.php" id="historyLink"><span class="icon"><i class='bx bx-history'></i></span> Request History </a>
                <a href="request.php"><span class="icon"><i class='bx bx-task'></i></span> Request a Document </a>
                <a href="account.php" id="accountLink"><span class="icon"><i class='bx bx-user'></i></span> Account </a>
                <a href="php/logout.php" class="mobile-logout desktop-hide"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
            </nav>

            <div class="logout-container desktop-only">
                <a href="php/logout.php" class="logout">
                    <span class="icon"><i class='bx bx-log-out'></i></span>
                    Log Out
                </a>
            </div>
        </aside>

    <main>
        <div id="stepContent" class="step-content">
            <?php
                $step = (int)($_SESSION['currentStep'] ?? 1);
                if ($step === 1) include("step1.php");
                elseif ($step === 2) include("step2.php");
                elseif ($step === 3) include("step3.php");
                elseif ($step === 4) include("step4.php");
            ?>
        </div>
    </main>
</div>

<script src="JSDash.js"></script>
<script>
// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('show-sidebar');
            document.body.style.overflow = sidebar.classList.contains('show-sidebar') ? 'hidden' : '';
        });

        document.addEventListener('click', function (e) {
            if (!sidebar.classList.contains('show-sidebar')) return;
            const isInside = sidebar.contains(e.target) || toggleBtn.contains(e.target);
            if (!isInside) {
                sidebar.classList.remove('show-sidebar');
                document.body.style.overflow = '';
            }
        });
    }
});
</script>
</body>
</html>
