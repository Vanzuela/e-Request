<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['studentID'])) {
    header("Location: login.php");
    exit();
}

include("php/config.php");

// Get announcements
$query = "SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5";
$result = mysqli_query($con, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-Request: Online Document Request System</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="dashCSS.css?v=<?php echo time(); ?>">
</head>
<body>
    <header>
        <div class="header-left">
            <img src="images/ptclogo.png" alt="PTC Logo">
            <span class="school-name">Pateros Technological College</span>
        </div>

        <!-- Hamburger only visible on mobile (CSS controls) -->
        <button id="mobileMenuBtn" class="mobile-menu-btn" aria-label="Open menu">
            <i class='bx bx-menu'></i>
        </button>
    </header>

    <div class="container">
        <!-- Sidebar (desktop visible, mobile toggled by hamburger) -->
        <aside class="sidebar" id="sidebar">
            <div class="profile">
                <div class="name"><?php echo htmlspecialchars($_SESSION['studentName'] ?? 'Student', ENT_QUOTES, 'UTF-8'); ?></div>
                <div class="role">Student</div>
            </div>

            <nav class="side-menu" aria-label="Sidebar Navigation">
                <a href="dashboard.php"><span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard </a>
                <a href="history.php" id="historyLink"><span class="icon"><i class='bx bx-history'></i></span> Request History </a>
                <a href="request.php"><span class="icon"><i class='bx bx-task'></i></span> Request a Document </a>
                <a href="account.php" id="accountLink"><span class="icon"><i class='bx bx-user'></i></span> Account </a>
                <a href="php/logout.php" class="mobile-logout desktop-hide"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
            </nav>

            <div class="logout-container desktop-only">
                <a href="php/logout.php" class="logout">
                    <span class="icon"><i class='bx bx-log-out'></i></span>
                    Log Out
                </a>
            </div>
        </aside>

        <main>
    <div class="request-section">
        <h1>ONLINE DOCUMENT REQUEST AND SCHEDULING SYSTEM</h1>
        <button id="requestNowBtn" onclick="window.location.href='request.php'">Request Now</button>
    </div>

    <div class="dashboard-grid">
        <div class="announcement-column">
            <div class="announcement">
                <?php 
                mysqli_data_seek($result, 0); 
                while ($row = mysqli_fetch_assoc($result)) { ?>
                    <div class="box">
                        <div class="scroll-area">
                            <div class="content">
                                <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                                <p><?php echo nl2br(htmlspecialchars($row['message'])); ?></p>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>

        <div class="stats-column">
            <h2 class="section-title">Your Request Status</h2>
            <div class="stats-container-grid">
                <?php
                // Using the status names from your admin code
                $statuses = [
                    'Pending' => 'bx-time-five',
                    'Processing' => 'bx-loader-alt bx-spin',
                    'Ready to Pickup' => 'bx-envelope',
                    'Done' => 'bx-check-double'
                ];

                foreach ($statuses as $statusName => $iconClass) {
                    // Logic from your admin dashboard but filtered for the logged-in student
                    // Note: Ensure $_SESSION['studentID'] matches your 'studentNo' column
                    $stID = mysqli_real_escape_string($con, $_SESSION['studentID']);
                    $query = "SELECT COUNT(*) as count FROM request WHERE requestStatus = '$statusName' AND studentNo = '$stID'";
                    $res = mysqli_query($con, $query);
                    $count = ($res) ? mysqli_fetch_assoc($res)['count'] : 0;
                    
                    // Clean class name for CSS (e.g., "ready-to-pickup")
                    $classTag = strtolower(str_replace(' ', '-', $statusName));
                ?>
                    <div class="stat-card-item <?php echo $classTag; ?>">
                        <div class="stat-icon">
                            <i class='bx <?php echo $iconClass; ?>'></i>
                        </div>
                        <div class="stat-details">
                            <h3><?php echo $statusName; ?></h3>
                            <p><?php echo $count; ?></p>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</main>


<script>
// Mobile hamburger behavior
document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('sidebar');

    toggleBtn && toggleBtn.addEventListener('click', function (e) {
        sidebar.classList.toggle('show-sidebar');
        // lock body scroll when sidebar open on small screens
        if (sidebar.classList.contains('show-sidebar')) document.body.style.overflow = 'hidden';
        else document.body.style.overflow = '';
    });

    // close sidebar when clicking outside on mobile
    document.addEventListener('click', function (e) {
        if (!sidebar.classList.contains('show-sidebar')) return;
        const isClickInside = sidebar.contains(e.target) || toggleBtn.contains(e.target);
        if (!isClickInside) {
            sidebar.classList.remove('show-sidebar');
            document.body.style.overflow = '';
        }
    });

    // close on link click (mobile)
    document.querySelectorAll('.side-menu a').forEach(a => {
        a.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('show-sidebar');
                document.body.style.overflow = '';
            }
        });
    });
});
</script>
</body>
</html>
