<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Calendar Test</title>

    <!-- FullCalendar CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.css">

    <style>
        /* Stronger selector so Hostinger themes cannot override it */
        #calendar .fc-day-disabled {
            background: #ececec !important;
            color: #b3b3b3 !important;
            pointer-events: none !important;
            cursor: not-allowed !important;
            opacity: 0.6 !important;
        }

        /* make sure calendar has space to display */
        #calendar {
            max-width: 900px;
            margin: 40px auto;
        }
    </style>
</head>

<body>

<div id="calendar"></div>

<!-- FullCalendar JS -->
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const today = new Date();
    today.setHours(0,0,0,0);

    let calendarEl = document.getElementById("calendar");

    let calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        selectable: true,
        selectMirror: true,

        select: function() {},

        // prevent selecting past dates & weekends
        selectAllow: function(selectInfo) {
            let d = new Date(selectInfo.startStr);
            d.setHours(0,0,0,0);

            let isPast = d < today;
            let isWeekend = (d.getDay() === 0 || d.getDay() === 6);

            return !(isPast || isWeekend);
        },

        dateClick: function(info) {
            let d = new Date(info.dateStr);
            d.setHours(0,0,0,0);

            let isPast = d < today;
            let isWeekend = (d.getDay() === 0 || d.getDay() === 6);

            if (isPast || isWeekend) return;

            alert("Selected date: " + info.dateStr);
        },

        dayCellDidMount: function(info) {
            let d = new Date(info.date);
            d.setHours(0,0,0,0);

            if (d < today || d.getDay() === 0 || d.getDay() === 6) {
                info.el.classList.add("fc-day-disabled");
            }
        }
    });

    calendar.render();
});
</script>

</body>
</html>
