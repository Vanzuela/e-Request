<?php
session_start();
include("php/config.php");

// Must be logged in
if (!isset($_SESSION['valid'])) {
    header("Location: login.php");
    exit();
}

$studentEmail = $_SESSION['valid'];

// 1. Generate 6-digit OTP
$otp = rand(100000, 999999);

// 2. Store OTP in session (valid for 5 minutes)
$_SESSION['delete_otp'] = $otp;
$_SESSION['delete_otp_time'] = time();

// 3. Send OTP email
$subject = "PTC e-Request - Account Deletion Verification";
$message = "
Your OTP verification code is:

$otp

This code will expire in 5 minutes.
If you did not request account deletion, please ignore this email.
";

$headers = "From: ptc-noreply@school.edu.ph";

// send email
mail($studentEmail, $subject, $message, $headers);

// 4. Redirect to OTP input page
header("Location: verify_delete.php");
exit();
?>
