<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");

require_once 'php/config.php';
require_once 'vendor/autoload.php';

session_start();

$studentNo = $_SESSION['studentNo'];

$requestQuery = "SELECT requestDocument FROM request WHERE studentNo = '$studentNo'";
$requestResult = mysqli_query($con, $requestQuery);

$documents = [];
while ($row = mysqli_fetch_assoc($requestResult)) {
    $documents[] = $row['requestDocument'];
}

$bookingDate = $_POST['bookingDate'];

use Spipu\Html2Pdf\Html2Pdf;

try {
    $html2pdf = new Html2Pdf('P', 'A4', 'en', true, 'UTF-8', [10, 10, 10, 10]);

    $html = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt</title>
    <style>
        .styled-table, tr, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 10px;
        }
    </style>
</head>
<body>
    <h1>Receipt for Document Request</h1>
    <p>Student Number: ' . htmlspecialchars($studentNo) . '</p>
    <p>Booking Date: ' . htmlspecialchars ($bookingDate) . '</p>
    <h2>Requested Documents</h2>
    <table class="styled-table">
        <thead>
            <tr>
                <th>Document</th>
            </tr>
        </thead>
        <tbody>';
    
    foreach ($documents as $document) {
        $html .= '
            <tr>
                <td>' . htmlspecialchars($document) . '</td>
            </tr>';
    }

    $html .= '
        </tbody>
    </table>
</body>
</html>
';

    $html2pdf->writeHTML($html);

    $html2pdf->output('receipt.pdf');
} catch (Html2PdfException $e) {
    $html2pdf->clean();
}
?>