<?php
session_start();
include("php/config.php");

// Must be logged in
if (!isset($_SESSION['studentNo'])) {
    header("Location: login.php");
    exit();
}

$studentNo = $_SESSION['studentNo'];
$docName = mysqli_real_escape_string($con, $_POST['docName']);

// Change status instead of deleting the record
$query = "
    UPDATE request
    SET requestStatus = 'Cancelled'
    WHERE studentNo = '$studentNo'
      AND requestDocument = '$docName'
      AND requestStatus = 'Pending'
";

mysqli_query($con, $query);

// Check if the student still has any pending/active documents
$check = mysqli_query($con, 
    "SELECT * FROM request 
     WHERE studentNo='$studentNo' 
       AND requestStatus IN ('Pending', 'Ready to Pickup', 'Booked')"
);

// If no active requests left → go back to Step 1
if (mysqli_num_rows($check) === 0) {
    $_SESSION['currentStep'] = 1;
}

// Redirect back to request.php
header("Location: request.php");
exit();
?>
