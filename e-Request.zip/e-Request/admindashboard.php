<?php
date_default_timezone_set('Asia/Manila');
session_start();
require_once("php/config.php");

/* ======================
    SESSION VALIDATION
====================== */
if (!isset($_SESSION['adminID'])) {
    header("Location: adminLogin.php");
    exit();
}

if (isset($_GET['logout']) && $_GET['logout'] === 'admin') {
    session_destroy();
    header("Location: adminLogin.php");
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);

/* ======================
    DASHBOARD COUNTERS
====================== */
function getCount($con, $status = null) {
    if ($status) {
        $stmt = $con->prepare("SELECT COUNT(*) FROM request WHERE requestStatus = ?");
        $stmt->bind_param("s", $status);
    } else {
        $stmt = $con->prepare("SELECT COUNT(*) FROM request");
    }
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count ?? 0;
}

$totalRequestCount = getCount($con);
$pendingCount      = getCount($con, 'Pending');
$processingCount   = getCount($con, 'Processing');
$readyCount        = getCount($con, 'Ready to Pickup');
$doneCount         = getCount($con, 'Done');

/* ======================
    STUDENT COUNTER
====================== */
$totalActiveStudents = 0;
$studentQuery = "SELECT COUNT(*) as total FROM login WHERE status != 'archived' OR status IS NULL OR status = ''";
$studentResult = mysqli_query($con, $studentQuery);

if ($studentResult && $row = mysqli_fetch_assoc($studentResult)) {
    $totalActiveStudents = $row['total'];
}

/* ======================
    YEAR RANGE (STATS)
====================== */
$minYear = $maxYear = date('Y');
$yrRes = mysqli_query($con,"
    SELECT MIN(YEAR(readyTime)) AS minY,
            MAX(YEAR(readyTime)) AS maxY
    FROM request
    WHERE readyTime IS NOT NULL
");

if ($yrRes && $row = mysqli_fetch_assoc($yrRes)) {
    $minYear = $row['minY'] ?: $minYear;
    $maxYear = $row['maxY'] ?: $maxYear;
}

$newRequestCount = $pendingCount;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="adminCSS.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        header { display: flex; justify-content: space-between; align-items: center; width: 100%; padding: 10px 30px; box-sizing: border-box; }
        .header-left { display: flex; align-items: center; gap: 15px; }
        .header-right { display: flex; align-items: center; margin-left: auto; }
        .notification-link { text-decoration: none; position: relative; display: flex; align-items: center; justify-content: center; width: 42px; height: 42px; background-color: #f0f7f7; border-radius: 12px; transition: all 0.3s ease; }
        .notification-link i { font-size: 24px;}
        .notification-link:hover { background-color: #119116; color: #fff; }
        .notification-link:hover i { color: #fff; }
        
        #notificationCount { position: absolute; top: -5px; right: -5px; background: #ff4757; color: white; font-size: 11px; font-weight: bold; min-width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        @keyframes pulse-red { 0% { transform: scale(1); } 50% { transform: scale(1.2); } 100% { transform: scale(1); } }
        .has-notif #notificationCount { animation: pulse-red 2s infinite; }

        .stats-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
        .live-card { background: #fff; border-radius: 12px; padding: 20px; display: flex; align-items: center; gap: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.03); border: 1px solid #f0f0f0; transition: 0.3s ease; }
        .card-icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
        .live-card .info-text h3 { font-size: 13px; color: #888; margin: 0; font-weight: 600; text-transform: uppercase; }
        .live-card .info-text p { font-size: 26px; font-weight: 700; color: #333; margin: 2px 0 0 0; }
        
        .card-total .card-icon { background: rgba(26, 133, 129, 0.1); color: #1a8581; }
        .card-pending .card-icon { background: #fff3e0; color: #ef6c00; }
        .card-processing .card-icon { background: #e3f2fd; color: #1565c0; }
        .card-ready .card-icon { background: #e8f5e9; color: #2e7d32; }
        .card-done .card-icon { background: #eeeeee; color: #616161; }

        .analytics-grid { display: grid; grid-template-columns: 2.2fr 1fr; gap: 25px; margin-top: 30px; }
        .stats-wrapper { background: #fff; padding: 25px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid #eee; }
        .selectors { display: flex; gap: 10px; margin-bottom: 25px; border-bottom: 1px solid #f0f0f0; padding-bottom: 15px; }
        .selectors select { padding: 8px 15px; border-radius: 8px; border: 1px solid #dfe4ea; background: #f8f9fa; color: #2f3542; outline: none; }
        
        .stats-grid { display: flex; gap: 15px; margin-bottom: 25px; }
        .stat-card { flex: 1; background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid transparent; cursor: pointer; transition: 0.3s; }
        .stat-card.active { background: #fff; border-color: #1a8581; box-shadow: 0 4px 12px rgba(26, 133, 129, 0.15); }
        .chart-wrapper { height: 380px; width: 100%; position: relative; }

        .side-panel { display: flex; flex-direction: column; gap: 25px; }
        .panel-card { background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid #eee; }
        .panel-card h3 { font-size: 15px; font-weight: 700; color: #2f3542; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; }

        .student-display { text-align: center; padding: 15px 0; }
        .student-display .count-number { display: block; font-size: 48px; font-weight: 800; line-height: 1; margin-bottom: 5px; }
        .student-display .count-label { font-size: 14px; color: #7f8c8d; font-weight: 500; }
        .view-users-btn { display: block; margin-top: 20px; padding: 12px; background: #f0f9f1; color: #038c2a; text-decoration: none; border-radius: 10px; font-weight: 700; font-size: 13px; text-align: center; border: 1px solid #d4edda; transition: 0.3s; }
        .view-users-btn:hover { background: #038c2a; color: #fff; }
    </style>
</head>
<body>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png" alt="PTC Logo">
        <span>Pateros Technological College</span>
    </div>
    <div class="header-right">
        <a id="notifBell" href="manage_requests.php?filter=pending" class="notification-link <?= $newRequestCount > 0 ? 'has-notif' : '' ?>">
            <i class='bx bx-bell'></i>
            <?php if ($newRequestCount > 0): ?>
                <span id="notificationCount"><?= $newRequestCount ?></span>
            <?php endif; ?>
        </a>
    </div>
</header>

<div class="container">
    <aside class="sidebar">
        <nav class="side-menu">
            <a href="admindashboard.php" class="side-btn active"><span class="icon"><i class='bx bxs-dashboard'></i></span> Dashboard</a>
            <a href="manage_requests.php" class="side-btn"><span class="icon"><i class='bx bx-spreadsheet'></i></span> Manage Requests</a>
            <a href="transaction_history.php" class="side-btn"><span class="icon"><i class='bx bx-history'></i></span> Transaction History</a>
            <a href="transaction.php" class="side-btn"><span class="icon"><i class='bx bx-money'></i></span> Transaction Details</a>
            <a href="announcement.php" class="side-btn"><span class="icon"><i class='bx bxs-megaphone'></i></span> Announcement</a>
            <?php if (isset($_SESSION['adminRole']) && str_replace(' ', '', $_SESSION['adminRole']) === 'SuperAdmin') : ?>
                <a href="users.php" class="side-btn"><span class="icon"><i class='bx bxs-user-detail'></i></span> Students</a>
                <a href="manageAdmin.php" class="side-btn"><span class="icon"><i class='bx bxs-user-badge'></i></span> Manage Users</a>
            <?php endif; ?>
        </nav>
        <div class="logout-container">
            <a href="php/logoutA.php" class="logout"><span class="icon"><i class='bx bx-log-out'></i></span> Log Out</a>
        </div>
    </aside>

    <main style="padding: 30px;">
        <div class="stats-container">
            <div class="live-card card-total">
                <div class="card-icon"><i class='bx bx-list-ul'></i></div>
                <div class="info-text"><h3>Total Requests</h3><p id="live-total"><?= $totalRequestCount ?></p></div>
            </div>
            <div class="live-card card-pending">
                <div class="card-icon"><i class='bx bx-time-five'></i></div>
                <div class="info-text"><h3>Pending</h3><p id="live-pending"><?= $pendingCount ?></p></div>
            </div>
            <div class="live-card card-processing">
                <div class="card-icon"><i class='bx bx-loader-alt'></i></div>
                <div class="info-text"><h3>Processing</h3><p id="live-processing"><?= $processingCount ?></p></div>
            </div>
            <div class="live-card card-ready">
                <div class="card-icon"><i class='bx bx-check-circle'></i></div>
                <div class="info-text"><h3>Ready</h3><p id="live-ready"><?= $readyCount ?></p></div>
            </div>
            <div class="live-card card-done">
                <div class="card-icon"><i class='bx bxs-badge-check'></i></div>
                <div class="info-text"><h3>Done</h3><p id="live-done"><?= $doneCount ?></p></div>
            </div>
        </div>

        <div class="analytics-grid">
            <div class="stats-wrapper">
                <div class="selectors">
                    <div style="flex-grow: 1; display: flex; align-items: center; gap: 10px;">
                        
                        <span>Request Trends</span>
                    </div>
                    <select id="yearSelect">
                        <?php
                        $currentYear = date('Y');
                        for ($y = $minYear; $y <= max($maxYear, $currentYear); $y++) {
                            echo "<option value=\"$y\" ".($y == $currentYear ? 'selected' : '').">$y</option>";
                        }
                        ?>
                    </select>
                    <select id="monthSelect">
                        <?php
                        $months = [1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'];
                        foreach ($months as $num => $name) {
                            echo "<option value=\"$num\" ".(intval(date('n')) == $num ? 'selected' : '').">$name</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="stats-grid">
                    <div class="stat-card" id="dailyCard"><h3>Daily</h3><p id="dailyCompleted">0</p></div>
                    <div class="stat-card" id="weeklyCard"><h3>Weekly</h3><p id="weeklyCompleted">0</p></div>
                    <div class="stat-card active" id="monthlyCard"><h3>Monthly</h3><p id="monthlyCompleted">0</p></div>
                </div>

                <div class="chart-wrapper">
                    <canvas id="mainChart"></canvas>
                </div>
            </div>

            <div class="side-panel">
                <div class="panel-card">
                    <h3>Status Share</h3>
                    <div style="height: 200px;"><canvas id="statusPieChart"></canvas></div>
                </div>

                <div class="panel-card">
                    <h3> Registered Students</h3>
                    <div class="student-display">
                        <span class="count-number" id="live-students"><?= number_format($totalActiveStudents) ?></span>
                        <span class="count-label">Total Active Students</span>
                    </div>
                    <a href="users.php" class="view-users-btn">Manage Students</a>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
let mainChart = null;
let statusPieChart = null; // Store reference to update later
let currentMode = 'month';

window.onload = function() {
    loadStatistics();
    document.getElementById('dailyCard').onclick = () => { currentMode = 'daily'; updateActiveUI('daily'); loadStatistics(); };
    document.getElementById('weeklyCard').onclick = () => { currentMode = 'week'; updateActiveUI('week'); loadStatistics(); };
    document.getElementById('monthlyCard').onclick = () => { currentMode = 'month'; updateActiveUI('month'); loadStatistics(); };
    document.getElementById('yearSelect').onchange = loadStatistics;
    document.getElementById('monthSelect').onchange = loadStatistics;
    renderPieChart();

    // AUTO REFRESH LOGIC: Every 5 seconds
    setInterval(fetchLiveUpdates, 5000);
};

// Function to fetch latest numbers from server
function fetchLiveUpdates() {
    fetch('get_live_counts.php')
        .then(res => res.json())
        .then(data => {
            // 1. Update status cards
            document.getElementById('live-total').innerText = data.total;
            document.getElementById('live-pending').innerText = data.pending;
            document.getElementById('live-processing').innerText = data.processing;
            document.getElementById('live-ready').innerText = data.ready;
            document.getElementById('live-done').innerText = data.done;
            document.getElementById('live-students').innerText = data.students.toLocaleString();

            // 2. Update Notification Bell and Animation
            const bell = document.getElementById('notifBell');
            let badge = document.getElementById('notificationCount');
            
            if (data.pending > 0) {
                bell.classList.add('has-notif');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.id = 'notificationCount';
                    bell.appendChild(badge);
                }
                badge.innerText = data.pending;
            } else {
                bell.classList.remove('has-notif');
                if (badge) badge.remove();
            }

            // 3. Update Pie Chart live
            if(statusPieChart) {
                statusPieChart.data.datasets[0].data = [data.pending, data.processing, data.ready, data.done];
                statusPieChart.update();
            }
        })
        .catch(err => console.error("Auto-refresh error:", err));
}

function updateActiveUI(mode) {
    document.querySelectorAll('.stat-card').forEach(c => c.classList.remove('active'));
    let id = (mode === 'week') ? 'weeklyCard' : mode + 'Card';
    document.getElementById(id).classList.add('active');
}

function renderPieChart() {
    const pieCtx = document.getElementById('statusPieChart').getContext('2d');
    statusPieChart = new Chart(pieCtx, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'Processing', 'Ready', 'Done'],
            datasets: [{
                data: [<?= "$pendingCount, $processingCount, $readyCount, $doneCount" ?>],
                backgroundColor: ['#ef6c00', '#1565c0', '#2e7d32', '#616161'],
                borderWidth: 0
            }]
        },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, cutout: '70%' }
    });
}

function loadStatistics() {
    const year = document.getElementById('yearSelect').value;
    const month = document.getElementById('monthSelect').value;
    fetch(`getStats.php?mode=${currentMode}&year=${year}&month=${month}`)
        .then(res => res.json())
        .then(data => {
            document.getElementById('dailyCompleted').innerText = data.dailyCount || 0;
            document.getElementById('weeklyCompleted').innerText = data.weeklyCount || 0;
            document.getElementById('monthlyCompleted').innerText = data.monthlyCount || 0;
            if (mainChart) mainChart.destroy();
            const ctx = document.getElementById('mainChart').getContext('2d');
            mainChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.chart.labels,
                    datasets: [{
                        label: 'Requests Fulfilled',
                        data: data.chart.counts,
                        backgroundColor: '#119116',
                        borderRadius: 6
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } }
                }
            });
        });
}
</script>
</body>
</html>