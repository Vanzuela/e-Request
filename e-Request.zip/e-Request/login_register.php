<?php
header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
header("Pragma: no-cache"); 

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "erequestdb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

ob_start();

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action']; 

    if ($action === 'login') {
        $studentEmailOrNo = $_POST['studentEmailOrNo'];
        $studentPassword = $_POST['studentPassword'];

        $stmt = $conn->prepare("SELECT studentPassword FROM login WHERE (studentNo = ? OR studentEmail = ?)");
        $stmt->bind_param("ss", $studentEmailOrNo, $studentEmailOrNo);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($studentPassword, $row['studentPassword'])) {
                $message = "Login successful!";
            } else {
                $message = "Invalid credentials";
            }
        } else {
            $message = "No account found";
        }
        $stmt->close();
    } elseif ($action === 'register') {
        $studentNo = $_POST['studentNo'];
        $studentName = $_POST['studentName'];
        $studentEmail = $_POST['studentEmail'];
        $studentPassword = password_hash($_POST['studentPassword'], PASSWORD_BCRYPT);
        $studentCourse = $_POST['studentCourse'];
        $studentYear = $_POST['studentYear'];

        $stmt = $conn->prepare("INSERT INTO login (studentNo, studentName, studentEmail, studentPassword, studentCourse, studentYear) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $studentNo, $studentName, $studentEmail, $studentPassword, $studentCourse, $studentYear);

        if ($stmt->execute()) {
            $message = "Registered Successfully!";
        } else {
            $message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>e-Request</title>
</head>
<body>
    <?php if (!empty($message)): ?>
        <p style="color: green;"><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>
    <a href="javascript:history.back()">Go Back</a>
</body>
</html>
