<?php
session_start();
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$otpInput = $data["otp"] ?? "";

if (!isset($_SESSION["otp"])) {
    echo json_encode(["status" => "error"]);
    exit;
}

if (time() > $_SESSION["otp_expiration"]) {
    echo json_encode(["status" => "expired"]);
    exit;
}

if ($otpInput == $_SESSION["otp"]) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "invalid"]);
}
?>
