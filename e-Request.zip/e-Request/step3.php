<?php 
include("php/config.php"); 
if (!isset($_SESSION['valid'])) { 
    header("Location: request.php"); 
    exit; 
} 

$studentNo = $_SESSION['studentNo']; 

$requestQuery = "
    SELECT requestID, requestDocument 
    FROM request 
    WHERE studentNo = '$studentNo' 
    AND requestStatus = 'Ready to Pickup'
"; 

$requestResult = mysqli_query($con, $requestQuery); 

$readyRequestIDs = []; 
$onlyCOG = true;

while ($row = mysqli_fetch_assoc($requestResult)) { 
    $readyRequestIDs[] = $row['requestID']; 
    if (stripos($row['requestDocument'], 'Certificate of Grades') === false) {
        $onlyCOG = false;
    }
} 

$readyRequestIDsJSON = json_encode($readyRequestIDs); 
$autoBookToday = (!empty($readyRequestIDs) && $onlyCOG);
?> 

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/main.min.css"> 
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script> 

<style> 
    /* Desktop Width Limiter */
    .calendar-wrapper {
        max-width: 900px; /* Limits the width so it's not full screen on desktop */
        margin: 0 auto;   /* Centers the calendar */
        padding: 10px;
    }

    /* Calendar Card Styling */
    #calendar-container {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 4px 25px rgba(0,0,0,0.1);
        margin-top: 10px;
    }

    /* FullCalendar Custom Overrides */
    .fc { font-family: 'Poppins', sans-serif; font-size: 0.95rem; }
    .fc-header-toolbar { margin-bottom: 1.5em !important; }
    .fc-toolbar-title { font-size: 1.25em !important; font-weight: 700; color:linear-gradient(0deg, #038c2a 0%, #20ba2d 100%); }
    
    .fc-button-primary {
        background-color: #2e7d32 !important;
        border-color: #2e7d32 !important;
        text-transform: capitalize;
    }
    .fc-button-primary:hover { background-color: #1b5e20 !important; }

    /* Day Styles */
    .fc-day-disabled { 
        background: #f8f9fa !important; 
        pointer-events: none !important; 
        opacity: 0.6;
    }
    .fc-daygrid-day.fc-day-today { background-color: #e8f5e9 !important; }


    }
    .legend-item { display: flex; align-items: center; gap: 8px; }
    .dot { width: 12px; height: 12px; border-radius: 50%; }

    /* Modal Styling */
    .modal { 
        display: none; 
        position: fixed; 
        inset: 0; 
        background: rgba(0,0,0,.75); 
        justify-content: center; 
        align-items: center; 
        z-index: 99999; 
        backdrop-filter: blur(5px);
    }
    .modal-content { 
        background: #fff; 
        padding: 30px; 
        border-radius: 12px; 
        max-width: 400px; 
        width: 90%; 
        text-align: center;
        box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    }
    .modal-content h4 { color: #2e7d32; margin-bottom: 15px; font-weight: 700; font-size: 1.2rem; }
    
    #timeSlot {
        width: 100%;
        padding: 12px;
        margin: 15px 0 25px 0;
        border-radius: 8px;
        border: 1px solid #ddd;
        font-family: inherit;
        outline: none;
        background: #fafafa;
    }
    
    #confirmBtn {
        width: 100%;
        background: #2e7d32;
        color: white;
        border: none;
        padding: 14px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.3s;
        font-size: 1rem;
    }
    #confirmBtn:hover { background: #1b5e20; transform: translateY(-1px); }
    
    .close-modal {
        margin-top: 20px;
        display: block;
        color: #888;
        font-size: 13px;
        text-decoration: none;
        cursor: pointer;
    }
    .close-modal:hover { color: #d32f2f; }

    /* Mobile Adjustments */
    @media (max-width: 768px) {
        #calendar-container { padding: 15px; }
        .fc-toolbar-title { font-size: 1.1em !important; }
        .fc-button { padding: 4px 8px !important; font-size: 0.8em !important; }
    }
</style> 

<div class="calendar-wrapper">
    <div id="calendar-container">
        <div style="text-align:center; margin-bottom: 20px;">
            <h3 style="font-weight:700; color:#333; margin:0;">Select Pickup Date</h3>
            <p style="font-size:14px; color:#666; margin-top:5px;">Choose a weekday to claim your documents.</p>
        </div>
        <div id="calendar"></div> 
    </div>
</div>

<div id="confirmModal" class="modal"> 
    <div class="modal-content"> 
        <i class='bx bx-calendar-check' style="font-size: 54px; color: #2e7d32; margin-bottom: 10px; display: block;"></i>
        <h4>Confirm Pickup</h4>
        <p id="modalMsg" style="color: #555; font-size: 15px; line-height: 1.6;"></p> 

        <form method="POST" action="save_booking.php" id="bookingForm"> 
            <input type="hidden" name="bookingDate" id="selectedDate"> 
            <input type="hidden" name="readyRequestIDs" value='<?= htmlspecialchars($readyRequestIDsJSON) ?>'> 
            
            <div style="text-align: left; margin-top: 20px;">
                <label style="font-size: 11px; font-weight: 800; color: #777; letter-spacing: 0.5px;">PREFERRED TIME</label>
                <select name="timeSlot" id="timeSlot"> 
                    <option value="AM">Morning (8:00 AM - 12:00 PM)</option> 
                    <option value="PM">Afternoon (1:00 PM - 5:00 PM)</option> 
                </select> 
            </div>
            
            <button type="submit" id="confirmBtn">Confirm Schedule</button> 
        </form>
        <span class="close-modal" onclick="document.getElementById('confirmModal').style.display='none'">Cancel and Go Back</span>
    </div> 
</div> 

<script> 
document.addEventListener('DOMContentLoaded', function () { 
    const today = new Date(); 
    today.setHours(0,0,0,0); 

    let calendar = new FullCalendar.Calendar(document.getElementById('calendar'), { 
        initialView: 'dayGridMonth', 
        height: 'auto',
        headerToolbar: { left: 'prev', center: 'title', right: 'next' }, 
        
        dateClick(info) { 
            let d = new Date(info.date);
            if (d < today || d.getDay() === 0 || d.getDay() === 6) {
                return; 
            }
            openConfirm(info.dateStr, false); 
        }, 

        dayCellDidMount(info) { 
            let d = new Date(info.date); 
            d.setHours(0,0,0,0); 
            if (d < today || d.getDay() === 0 || d.getDay() === 6) { 
                info.el.classList.add("fc-day-disabled"); 
            } 
        } 
    }); 

    calendar.render(); 

    <?php if ($autoBookToday): ?>
        const todayStr = new Date().toISOString().split('T')[0];
        const dayOfWeek = new Date().getDay();
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
            openConfirm(todayStr, true);
        }
    <?php endif; ?>
}); 

function openConfirm(dateStr, autoSubmit) {
    document.getElementById('selectedDate').value = dateStr;

    const now = new Date();
    const hour = now.getHours();
    const slot = document.getElementById('timeSlot');

    slot.value = (hour >= 12) ? "PM" : "AM";

    if (autoSubmit) {
        document.getElementById('bookingForm').submit();
        return;
    }

    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = new Date(dateStr).toLocaleDateString(undefined, options);

    document.getElementById('modalMsg').innerHTML = "You are scheduling a pickup for:<br><b style='color:#333;'>" + formattedDate + "</b>";
    document.getElementById('confirmModal').style.display = "flex";
}

window.onclick = function(event) {
    let modal = document.getElementById('confirmModal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>