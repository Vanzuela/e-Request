<?php
include("php/config.php");

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$start = ($page - 1) * $limit;

// Filters
$search = $_GET["search"] ?? "";
$doc     = $_GET["document"] ?? "";
$admin   = $_GET["admin"] ?? "";
$from    = $_GET["from"] ?? "";
$to      = $_GET["to"] ?? "";

// Build WHERE conditions
$where = "WHERE r.requestStatus IN ('Ready to Pickup','Done') AND r.approvedBy IS NOT NULL";

if ($search !== "") {
    $s = mysqli_real_escape_string($con, $search);
    $where .= " AND (r.requestID LIKE '%$s%' 
                OR l.studentName LIKE '%$s%' 
                OR r.requestDocument LIKE '%$s%')";
}

if ($doc !== "") {
    $d = mysqli_real_escape_string($con, $doc);

    // Special logic for CTC with variable copies
    if ($d === "Certified True Copy (CTC)") {
        $where .= " AND r.requestDocument LIKE 'Certified True Copy (%'";
    }
    // Other certificates match exactly
    else {
        // Fix CTC dynamic copies (x1, x2, x3...)
if (strpos($d, "Certified True Copy") !== false) {
    $where .= " AND r.requestDocument LIKE 'Certified True Copy%'";
} else {
    $where .= " AND r.requestDocument = '$d'";
}

    }
}

if ($admin !== "") {
    $a = mysqli_real_escape_string($con, $admin);
    $where .= " AND r.approvedBy = '$a'";
}

if ($from !== "" && $to !== "") {
    $from = mysqli_real_escape_string($con, $from);
    $to = mysqli_real_escape_string($con, $to);
    $where .= " AND DATE(r.readyTime) BETWEEN '$from' AND '$to'";
}

// COUNT rows for pagination
$countQ = "SELECT COUNT(*) AS total
           FROM request r 
           LEFT JOIN login l ON r.studentNo = l.studentNo
           $where";
$countResult = mysqli_query($con, $countQ);
$totalRows = mysqli_fetch_assoc($countResult)['total'];
$totalPages = ceil($totalRows / $limit);

// MAIN QUERY
$query = "
    SELECT 
        r.requestID,
        r.requestDocument,
        COALESCE(l.studentName, 'Deleted Account') AS studentName,
        r.approvedBy,
        r.readyTime
    FROM request r
    LEFT JOIN login l ON r.studentNo = l.studentNo
    $where
    ORDER BY r.readyTime DESC
    LIMIT $start, $limit
";
$res = mysqli_query($con, $query);

$logs = [];
while ($row = mysqli_fetch_assoc($res)) {
    $logs[] = $row;
}

// Return response
echo json_encode([
    "logs" => $logs,
    "totalPages" => $totalPages
]);

?>
