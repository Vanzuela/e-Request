<?php
session_start();
header("Content-Type: application/json");

require __DIR__ . "/phpmailer/vendor/phpmailer/phpmailer/src/Exception.php";
require __DIR__ . "/phpmailer/vendor/phpmailer/phpmailer/src/PHPMailer.php";
require __DIR__ . "/phpmailer/vendor/phpmailer/phpmailer/src/SMTP.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$data = json_decode(file_get_contents("php://input"), true);

// Validate request
if (!$data || !isset($data["email"])) {
    echo json_encode(["status" => "error", "message" => "No email received"]);
    exit;
}

// JS already sends the FULL EMAIL → DO NOT add domain again
$studentEmail = $data["email"];

// GENERATE OTP
$otp = random_int(100000, 999999);

$_SESSION["otp"] = $otp;
$_SESSION["otp_email"] = $studentEmail;
$_SESSION["otp_expiration"] = time() + 300; // 5 min

$mail = new PHPMailer(true);

try {
    // SMTP SETTINGS
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;

    // MUST MATCH setFrom()
    $mail->Username = "paterosrequest@gmail.com";
    $mail->Password = "iuio hkyh yimn zckp";

    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;

    // MUST MATCH YOUR GMAIL USERNAME
    $mail->setFrom("paterosrequest@gmail.com", "PTC e-Request Verification");

    $mail->addAddress($studentEmail);

    // EMAIL CONTENT
    $mail->isHTML(true);
    $mail->Subject = "Your OTP Verification Code";

    $mail->Body = "
        <h2>PTC Email Verification</h2>
        <p>Your One-Time Password:</p>
        <h1 style='font-size:40px;'>$otp</h1>
        <p>This OTP is valid for <b>5 minutes</b>.</p>
    ";

    $mail->send();

    echo json_encode(["status" => "sent", "message" => "OTP sent"]);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $mail->ErrorInfo]);
}
?>
