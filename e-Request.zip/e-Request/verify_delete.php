<?php
session_start();
include("php/config.php");

// Must be logged in
if (!isset($_SESSION['valid'])) {
    header("Location: login.php");
    exit();
}

// OTP expired after 5 minutes
if (!isset($_SESSION['delete_otp']) || time() - $_SESSION['delete_otp_time'] > 300) {
    unset($_SESSION['delete_otp']);
    unset($_SESSION['delete_otp_time']);
    die("OTP expired. <a href='account.php'>Try again</a>");
}

// When user submits OTP
if (isset($_POST['verifyOTP'])) {
    $enteredOTP = $_POST['otp'];

    if ($enteredOTP == $_SESSION['delete_otp']) {

        // Correct OTP → Delete Account
        $email = $_SESSION['valid'];
        mysqli_query($con, "DELETE FROM login WHERE studentEmail='$email'");

        session_destroy();

        echo "<script>alert('Account deleted successfully'); window.location='login.php';</script>";
        exit();
    } else {
        $error = "Invalid OTP. Try again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Verify OTP</title>
</head>
<body>

<h2>Email Verification</h2>
<p>An OTP was sent to your email. Enter it below:</p>

<form method="POST">
    <input type="text" name="otp" placeholder="Enter 6-digit OTP" required maxlength="6">
    <button type="submit" name="verifyOTP">Verify</button>
</form>

<?php if (!empty($error)) echo "<p style='color:red'>$error</p>"; ?>

</body>
</html>
