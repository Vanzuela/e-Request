<?php
// ----------------------------------------------------------
// ENABLE ERROR LOGGING (but DISABLE showing errors to users)
// ----------------------------------------------------------
ini_set('display_errors', 0);                  // Users won't see errors
ini_set('log_errors', 1);                      // Log errors to a file
ini_set('error_log', __DIR__ . "/php-error.log"); // Error log file

// ----------------------------------------------------------
// SET DEFAULT TIMEZONE (VERY IMPORTANT FOR CORRECT TIMESTAMP)
// ----------------------------------------------------------
date_default_timezone_set('Asia/Manila');

// ----------------------------------------------------------
// DATABASE CONFIGURATION (HOSTINGER)
// ----------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_USER', 'u168664422_hrgtsgi');
define('DB_PASS', '._9P-v4x3v');
define('DB_NAME', 'u168664422_hrgtsgi');

// ----------------------------------------------------------
// DATABASE CONNECTION
// ----------------------------------------------------------
$con = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if (!$con) {
    error_log("DB Connection failed: " . mysqli_connect_error());
    die("A database error occurred. Please contact admin.");
}

// OPTIONAL: Force MySQL to use Philippine Time also
mysqli_query($con, "SET time_zone = '+08:00'");
?>
