<?php
include("config.php");
$count = mysqli_fetch_assoc(
    mysqli_query($con, "SELECT COUNT(*) as count FROM request WHERE requestStatus = 'Pending'")
)['count'] ?? 0;
echo json_encode(['count' => $count]);
