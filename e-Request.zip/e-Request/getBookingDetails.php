<?php
include("php/config.php");

if (!isset($_GET['bookingID'])) {
    echo json_encode(["error" => "Missing bookingID"]);
    exit;
}

$bookingID = mysqli_real_escape_string($con, $_GET['bookingID']);

/* Get student + booking info */
$infoQuery = "
    SELECT 
        booking.bookingID,
        booking.bookingDate,
        login.studentNo,
        login.studentName,
        login.studentCourse,
        login.studentYear
    FROM booking
    JOIN login ON booking.studentNo = login.studentNo
    WHERE booking.bookingID = '$bookingID'
";

$infoResult = mysqli_query($con, $infoQuery);

if (!$infoResult || mysqli_num_rows($infoResult) == 0) {
    echo json_encode(["error" => "Booking not found"]);
    exit;
}

$info = mysqli_fetch_assoc($infoResult);

/* Get related document requests - UPDATED to filter out 'Done' items */
$docsQuery = "
    SELECT 
        request.requestID,
        request.requestDocument,
        request.requestStatus,
        request.requestDate
    FROM request_booking
    JOIN request ON request_booking.requestID = request.requestID
    WHERE request_booking.bookingID = '$bookingID'
    AND request.requestStatus != 'Done'
";

$docsResult = mysqli_query($con, $docsQuery);

$documents = [];
while ($row = mysqli_fetch_assoc($docsResult)) {
    $documents[] = $row;
}

$info['documents'] = $documents;

echo json_encode($info);
?>