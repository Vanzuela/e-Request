<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");
session_start();
include("php/config.php");

/* Redirect if already logged in */
if (isset($_SESSION['studentID'])) {
    header("Location: dashboard.php");
    exit();
}

/* ======================= LOGIN PROCESS ======================= */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "login") {
    $studentEmailOrNo = mysqli_real_escape_string($con, $_POST['studentEmailOrNo']);
    $studentPassword  = mysqli_real_escape_string($con, $_POST['studentPassword']);

    $query = "SELECT * FROM login 
              WHERE (studentEmail='$studentEmailOrNo' OR studentNo='$studentEmailOrNo') 
              AND studentPassword='$studentPassword'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        /* --- NEW: CHECK IF ACCOUNT IS ARCHIVED --- */
        if (isset($row['status']) && $row['status'] == 'archived') {
            $_SESSION['message'] = "This account has been archived. Please contact the Registrar.";
            header("Location: login.php");
            exit();
        }

        $_SESSION['valid']        = $row['studentEmail'];
        $_SESSION['studentName']  = $row['studentName'];
        $_SESSION['studentCourse']= $row['studentCourse'];
        $_SESSION['studentYear']  = $row['studentYear'];
        $_SESSION['studentNo']    = $row['studentNo'];
        $_SESSION['studentID']    = $row['studentNo'];

        /* --- NEW: CHECK FOR FIRST LOGIN --- */
        if (isset($row['first_login']) && $row['first_login'] == 1) {
            header("Location: change_password.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    }

    $_SESSION['message'] = "Wrong Email/Student No. or Password";
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>e-Request - Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="loginCSS.css?v=<?php echo time(); ?>">

    <style>
        .forgot-wrapper {
            min-height: 100vh;
            padding: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .forgot-card {
            width: 100%;
            max-width: 420px;
            background: #fff;
            padding: 35px 80px;
            border-radius: 8px;
            box-sizing: border-box;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center; 
        }

        .login-icon {
            width: 80px; 
            height: auto;
            margin-bottom: 15px;
        }

        .login-title {
            text-align: center;
            font-size: 25px;
            font-weight: 800;
            line-height: 1.2;
            text-transform: uppercase;
            color: #000;
            margin-bottom: 30px;
        }

        .forgot-form .input-group {
            position: relative;
            margin-bottom: 20px;
            text-align: left; 
        }

        .forgot-form input {
            width: 100%;
            padding: 14px 14px;
            font-size: 16px;
            border: 1.5px solid #000;
            border-radius: 4px;
            outline: none;
            box-sizing: border-box;
        }

        .password-box i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            cursor: pointer;
            color: #555;
        }

        .forgot-form button {
            width: 100%;
            margin-top: 10px;
            padding: 14px;
            background: linear-gradient(0deg, #038c2a 0%, #20ba2d 100%);
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            text-transform: uppercase;
        }

        .forgot-form button:hover {
            opacity: 0.9;
        }

        .forgot-text {
            text-align: center;
            margin-top: 12px;
        }

        .forgot-text a {
            color: #038c2a;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
        }

        .forgot-text a:hover {
            text-decoration: underline;
        }

        .alert-box {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #333;
            color: #fff;
            padding: 15px 25px;
            border-radius: 4px;
            z-index: 1000;
            transition: opacity 0.5s ease;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .alert-close {
            cursor: pointer;
            font-size: 20px;
        }

        @media (max-width: 480px) {
            .forgot-wrapper { padding: 20px; }
        }
    </style>
</head>
<body>

<?php if (isset($_SESSION['message'])) : ?>
<div class="alert-box" id="alertBox">
    <span class="alert-text"><?= $_SESSION['message']; ?></span>
    <span class="alert-close" onclick="document.getElementById('alertBox').style.opacity='0'">&times;</span>
</div>

<script>
setTimeout(() => {
    const alert = document.getElementById("alertBox");
    if (alert) alert.style.opacity = "0";
}, 4000);
</script>
<?php unset($_SESSION['message']); endif; ?>

<header>
    <div class="header-left">
        <img src="images/ptclogo.png">
        <span>Pateros Technological College</span>
    </div>
</header>

<div class="forgot-wrapper">
    <div class="forgot-card">
        
        <img src="images/login_icon.png" alt="Login" class="login-icon">

        <form id="loginForm" method="POST" class="forgot-form">
            <div class="login-title">Student Login</div>
            <input type="hidden" name="action" value="login">

            <div class="input-group">
                <input type="text" name="studentEmailOrNo"
                       placeholder="Email or Student No."
                       required autocomplete="off">
            </div>

            <div class="input-group password-box">
                <input type="password" name="studentPassword"
                       id="studentPassword" placeholder="Password" required>
                <i class="bx bx-hide toggle-password" data-target="studentPassword"></i>
            </div>

            <button type="submit">Login</button>
            
            <p class="forgot-text">
                <a href="forgot_password.php">Forgot Password?</a>
            </p>
        </form>

    </div>
</div>

<script src="JSLogin.js"></script>

<script>
document.querySelectorAll(".toggle-password").forEach(icon => {
    icon.addEventListener("click", () => {
        const input = document.getElementById(icon.dataset.target);
        if (!input) return;

        if (input.type === "password") {
            input.type = "text";
            icon.classList.replace("bx-hide", "bx-show");
        } else {
            input.type = "password";
            icon.classList.replace("bx-show", "bx-hide");
        }
    });
});
</script>

</body>
</html>